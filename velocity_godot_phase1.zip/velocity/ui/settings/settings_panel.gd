class_name SettingsPanel
extends Control
## 设置面板（覆盖层）。只包含已经真正生效的选项。
## 其余设置（画质预设、陀螺仪、色盲、HUD 编辑器等）见 ROADMAP。

signal closed

const FPS_OPTIONS := [30, 45, 60, 90, 120]


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.72)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(dim)

    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(1000, 0)
    panel.add_theme_stylebox_override("panel", UITheme.box(UITheme.PANEL, UITheme.BORDER, 1, 32))
    center.add_child(panel)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 16)
    panel.add_child(col)

    col.add_child(UITheme.label("设置", 40, UITheme.TITANIUM))
    _add_slider(col, "视角灵敏度", "look_sens", 0.2, 3.0, 0.05)
    _add_slider(col, "视野 FOV", "fov", 70.0, 110.0, 1.0)
    _add_slider(col, "渲染分辨率", "render_scale", 0.5, 1.0, 0.05)
    _add_slider(col, "触控按键透明度", "touch_opacity", 0.2, 1.0, 0.05)
    _add_fps(col)
    _add_toggle(col, "显示 FPS", "show_fps")
    _add_toggle(col, "自动冲刺（触屏）", "auto_sprint")

    var close := Button.new()
    close.text = "保存并关闭"
    close.custom_minimum_size = Vector2(0, 76)
    close.pressed.connect(_close)
    col.add_child(close)


func _add_slider(parent: Control, text: String, prop: String, lo: float, hi: float, step: float) -> void:
    var row := HBoxContainer.new()
    var name_l := UITheme.label(text, 26, UITheme.TITANIUM)
    name_l.custom_minimum_size = Vector2(300, 0)
    var s := HSlider.new()
    s.min_value = lo
    s.max_value = hi
    s.step = step
    s.value = Settings.get(prop)
    s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    s.custom_minimum_size = Vector2(0, 48)
    var val_l := UITheme.label("%.2f" % s.value, 26, UITheme.ICE)
    val_l.custom_minimum_size = Vector2(100, 0)
    s.value_changed.connect(_on_slider.bind(val_l, prop))
    row.add_child(name_l)
    row.add_child(s)
    row.add_child(val_l)
    parent.add_child(row)


func _on_slider(v: float, val_l: Label, prop: String) -> void:
    val_l.text = "%.2f" % v
    Settings.set(prop, v)
    Settings.apply()


func _add_fps(parent: Control) -> void:
    var row := HBoxContainer.new()
    var name_l := UITheme.label("目标帧率", 26, UITheme.TITANIUM)
    name_l.custom_minimum_size = Vector2(300, 0)
    var ob := OptionButton.new()
    for f in FPS_OPTIONS:
        ob.add_item("%d FPS" % f)
    ob.select(maxi(FPS_OPTIONS.find(Settings.target_fps), 0))
    ob.custom_minimum_size = Vector2(240, 60)
    ob.item_selected.connect(_on_fps)
    row.add_child(name_l)
    row.add_child(ob)
    parent.add_child(row)


func _on_fps(idx: int) -> void:
    Settings.target_fps = FPS_OPTIONS[idx]
    Settings.apply()


func _add_toggle(parent: Control, text: String, prop: String) -> void:
    var c := CheckButton.new()
    c.text = text
    c.button_pressed = Settings.get(prop)
    c.custom_minimum_size = Vector2(0, 60)
    c.toggled.connect(_on_toggle.bind(prop))
    parent.add_child(c)


func _on_toggle(pressed: bool, prop: String) -> void:
    Settings.set(prop, pressed)


func _close() -> void:
    Settings.save_settings()
    Settings.apply()
    closed.emit()
    queue_free()
