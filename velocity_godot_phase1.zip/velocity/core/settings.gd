extends Node
## Autoload: Settings
## 玩家设置，存 user://settings.cfg。只放"已经真正生效"的选项。

const PATH := "user://settings.cfg"

var look_sens := 1.0          # 视角灵敏度倍率
var fov := 90.0               # 垂直 FOV 基准（Godot Camera3D 默认按垂直算）
var render_scale := 1.0       # 3D 渲染分辨率倍率
var target_fps := 60
var show_fps := true
var auto_sprint := true       # 触屏摇杆推满自动冲刺
var touch_opacity := 0.6


func _ready() -> void:
    load_settings()
    apply()


func load_settings() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(PATH) != OK:
        return
    look_sens = cfg.get_value("input", "look_sens", look_sens)
    auto_sprint = cfg.get_value("input", "auto_sprint", auto_sprint)
    touch_opacity = cfg.get_value("input", "touch_opacity", touch_opacity)
    fov = cfg.get_value("video", "fov", fov)
    render_scale = cfg.get_value("video", "render_scale", render_scale)
    target_fps = cfg.get_value("video", "target_fps", target_fps)
    show_fps = cfg.get_value("video", "show_fps", show_fps)


func save_settings() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("input", "look_sens", look_sens)
    cfg.set_value("input", "auto_sprint", auto_sprint)
    cfg.set_value("input", "touch_opacity", touch_opacity)
    cfg.set_value("video", "fov", fov)
    cfg.set_value("video", "render_scale", render_scale)
    cfg.set_value("video", "target_fps", target_fps)
    cfg.set_value("video", "show_fps", show_fps)
    cfg.save(PATH)


func apply() -> void:
    Engine.max_fps = target_fps
    var root := get_tree().root
    root.scaling_3d_scale = render_scale
    root.msaa_3d = Viewport.MSAA_DISABLED if Game.is_mobile else Viewport.MSAA_2X
