extends SceneTree
## 无头测试: godot --headless -s tests/ttk_check.gd
## 校验所有武器的理论 TTK，步枪胸部 TTK 须落在设计目标 180~300ms。
## 注意: 需要先用编辑器打开过一次工程（生成 class_name 缓存）。

const WEAPONS := [
    "res://data/weapons/vx1_rifle.tres",
    "res://data/weapons/vp9_smg.tres",
]


func _init() -> void:
    var ok := true
    for path in WEAPONS:
        var w := load(path) as WeaponData
        if w == null:
            printerr("FAIL load ", path)
            ok = false
            continue
        var chest := w.theoretical_ttk_ms()
        var head := w.theoretical_ttk_ms(100.0, true)
        var far := w.theoretical_ttk_ms(100.0, false, 60.0)
        print("%-12s chest %4.0f ms | head %4.0f ms | chest@60m %4.0f ms" % [w.display_name, chest, head, far])
        if w.display_name.contains("RIFLE") and (chest < 180.0 or chest > 300.0):
            printerr("FAIL rifle chest TTK out of 180-300ms: ", chest)
            ok = false
    print("RESULT: ", "PASS" if ok else "FAIL")
    quit(0 if ok else 1)
