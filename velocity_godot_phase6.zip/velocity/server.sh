#!/bin/sh
# 启动专用服务器（无界面）。需要先用编辑器打开过一次工程（生成 class_name 缓存）。
# 用法: ./server.sh [端口] [难度 0|1|2]
PORT=${1:-7777}
DIFF=${2:-1}
exec godot --headless --path "$(dirname "$0")" -- --server --port="$PORT" --difficulty="$DIFF"
