class_name SettingsPanel
extends Control
## 设置面板（覆盖层，可滚动）: 画面 / 操作 / 游戏 / 账号。
## 改动任何画面单项会自动切到"自定义"画质；选择画质预设会一次性设置一组参数。

signal closed


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.78)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(dim)
    _build()


func _build() -> void:
    var old := get_node_or_null("Center")
    if old != null:
        remove_child(old)
        old.queue_free()
    var center := CenterContainer.new()
    center.name = "Center"
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(1040, 0)
    panel.add_theme_stylebox_override("panel", UITheme.box(UITheme.PANEL, UITheme.BORDER, 1, 28))
    center.add_child(panel)
    var outer := VBoxContainer.new()
    outer.add_theme_constant_override("separation", 14)
    panel.add_child(outer)
    outer.add_child(UITheme.label("设置", 40, UITheme.TITANIUM))

    var scroll := ScrollContainer.new()
    scroll.custom_minimum_size = Vector2(0, 640)
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    outer.add_child(scroll)
    var col := VBoxContainer.new()
    col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    col.add_theme_constant_override("separation", 12)
    scroll.add_child(col)

    _section(col, "画面")
    var fps_vals := Settings.available_fps()
    _option(col, "画质预设", Settings.QUALITY_NAMES, Settings.quality, _on_quality)
    _option_prop(col, "目标帧率", fps_vals.map(func(f): return "%d FPS" % f), fps_vals, "target_fps")
    _slider(col, "渲染分辨率", "render_scale", 0.5, 1.0, 0.05)
    _slider(col, "视野 FOV", "fov", 70.0, 110.0, 1.0)
    _toggle(col, "阴影", "shadows", true)
    _option_prop(col, "抗锯齿", ["关闭", "MSAA 2x", "MSAA 4x"], [0, 2, 4], "msaa")
    _option_prop(col, "特效数量", ["低", "中", "高"], [0, 1, 2], "fx_quality")
    _toggle(col, "画面锐化（降低分辨率时用 FSR 放大）", "sharpen", true)
    _toggle(col, "动态分辨率（帧率不足时自动降）", "dynamic_res", true)
    _toggle(col, "倍镜镜内成像（更耗性能，下次进入对局生效）", "scope_pip", false)

    _section(col, "操作")
    _slider(col, "视角灵敏度", "look_sens", 0.2, 3.0, 0.05)
    _slider(col, "开镜灵敏度", "ads_sens", 0.2, 2.0, 0.05)
    _slider(col, "  1x 瞄具倍率", "ads_low", 0.4, 2.0, 0.05)
    _slider(col, "  2–3x 瞄具倍率", "ads_mid", 0.4, 2.0, 0.05)
    _slider(col, "  4x 及以上倍率", "ads_high", 0.4, 2.0, 0.05)
    _toggle(col, "陀螺仪瞄准（手机）", "gyro_enabled", false)
    _slider(col, "陀螺仪灵敏度", "gyro_sens", 0.2, 3.0, 0.05)
    _toggle(col, "陀螺仪上下反向", "gyro_invert_y", false)
    _slider(col, "辅助瞄准强度（触屏）", "aim_assist", 0.0, 1.0, 0.05)
    _slider(col, "手柄摇杆死区", "stick_deadzone", 0.05, 0.4, 0.01)
    _slider(col, "触控按键透明度", "touch_opacity", 0.2, 1.0, 0.05)
    _toggle(col, "自动冲刺（触屏推满摇杆）", "auto_sprint", false)
    _toggle(col, "左手模式（按键镜像）", "left_handed", false)
    var editor := Button.new()
    editor.text = "编辑按键布局（位置 / 大小）"
    editor.custom_minimum_size = Vector2(0, 64)
    editor.pressed.connect(_open_hud_editor)
    col.add_child(editor)

    _section(col, "游戏")
    _toggle(col, "显示 FPS / 延迟", "show_fps", false)
    _toggle(col, "显示伤害数字（训练场靶子）", "damage_numbers", false)

    _section(col, "账号与数据")
    var prof: Dictionary = AuthService.profile
    col.add_child(UITheme.label("当前账号: %s（%s）" % [prof.get("nickname", "—"), prof.get("provider", "none")], 22, UITheme.TEXT_DIM))
    var logout := Button.new()
    logout.text = "退出登录"
    logout.custom_minimum_size = Vector2(0, 64)
    logout.pressed.connect(_logout)
    col.add_child(logout)
    var wipe := Button.new()
    wipe.text = "清除本地数据（设置 / 配装 / 按键布局 / 游客账号）"
    wipe.custom_minimum_size = Vector2(0, 64)
    wipe.pressed.connect(_wipe)
    col.add_child(wipe)

    var close := Button.new()
    close.text = "保存并关闭"
    close.custom_minimum_size = Vector2(0, 76)
    UITheme.style_primary(close)
    close.pressed.connect(_close)
    outer.add_child(close)


# ---------- 控件工厂 ----------
func _section(parent: Control, text: String) -> void:
    var l := UITheme.label(text, 30, UITheme.ICE)
    parent.add_child(l)


func _slider(parent: Control, text: String, prop: String, lo: float, hi: float, step: float) -> void:
    var row := HBoxContainer.new()
    var name_l := UITheme.label(text, 24, UITheme.TITANIUM)
    name_l.custom_minimum_size = Vector2(360, 0)
    var s := HSlider.new()
    s.min_value = lo
    s.max_value = hi
    s.step = step
    s.value = float(Settings.get(prop))
    s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    s.custom_minimum_size = Vector2(0, 48)
    var val_l := UITheme.label("%.2f" % s.value, 24, UITheme.ICE)
    val_l.custom_minimum_size = Vector2(90, 0)
    s.value_changed.connect(_on_slider.bind(val_l, prop))
    row.add_child(name_l)
    row.add_child(s)
    row.add_child(val_l)
    parent.add_child(row)


func _on_slider(v: float, val_l: Label, prop: String) -> void:
    val_l.text = "%.2f" % v
    Settings.set(prop, v)
    _mark_custom(prop)
    Settings.apply()


func _toggle(parent: Control, text: String, prop: String, affects_quality: bool) -> void:
    var c := CheckButton.new()
    c.text = text
    c.button_pressed = bool(Settings.get(prop))
    c.custom_minimum_size = Vector2(0, 58)
    c.toggled.connect(_on_toggle.bind(prop, affects_quality))
    parent.add_child(c)


func _on_toggle(pressed: bool, prop: String, affects_quality: bool) -> void:
    Settings.set(prop, pressed)
    if affects_quality:
        Settings.quality = 5
    Settings.apply()


func _option(parent: Control, text: String, items: Array, selected: int, cb: Callable) -> void:
    var row := HBoxContainer.new()
    var name_l := UITheme.label(text, 24, UITheme.TITANIUM)
    name_l.custom_minimum_size = Vector2(360, 0)
    var ob := OptionButton.new()
    for it in items:
        ob.add_item(String(it))
    ob.select(selected)
    ob.custom_minimum_size = Vector2(300, 60)
    ob.item_selected.connect(cb)
    row.add_child(name_l)
    row.add_child(ob)
    parent.add_child(row)


func _option_prop(parent: Control, text: String, items: Array, values: Array, prop: String) -> void:
    var cur: Variant = Settings.get(prop)
    var sel := maxi(values.find(cur), 0)
    var row := HBoxContainer.new()
    var name_l := UITheme.label(text, 24, UITheme.TITANIUM)
    name_l.custom_minimum_size = Vector2(360, 0)
    var ob := OptionButton.new()
    for it in items:
        ob.add_item(String(it))
    ob.select(sel)
    ob.custom_minimum_size = Vector2(300, 60)
    ob.item_selected.connect(_on_option_prop.bind(values, prop))
    row.add_child(name_l)
    row.add_child(ob)
    parent.add_child(row)


func _on_option_prop(idx: int, values: Array, prop: String) -> void:
    Settings.set(prop, values[idx])
    _mark_custom(prop)
    Settings.apply()


func _mark_custom(prop: String) -> void:
    if prop in ["render_scale", "target_fps", "shadows", "msaa", "fx_quality", "sharpen"]:
        Settings.quality = 5


func _on_quality(idx: int) -> void:
    if idx < 5:
        Settings.apply_quality(idx)
        Settings.apply()
        _build()                      # 预设改了一批参数，重建界面刷新显示


# ---------- 按钮 ----------
func _open_hud_editor() -> void:
    Settings.save_settings()
    SceneRouter.goto("res://ui/hud_editor/hud_editor.tscn")


func _logout() -> void:
    Settings.save_settings()
    AuthService.logout()
    SceneRouter.goto("res://ui/login/login.tscn")


func _wipe() -> void:
    for f in ["settings.cfg", "loadout.cfg", "hud_layout.cfg", "account.cfg"]:
        if FileAccess.file_exists("user://" + f):
            DirAccess.remove_absolute("user://" + f)
    Settings.quality = 3
    HudLayout.reset()
    Loadout.reset_all()
    AuthService.logout()
    SceneRouter.goto("res://ui/login/login.tscn")


func _close() -> void:
    Settings.save_settings()
    Settings.apply()
    closed.emit()
    queue_free()
