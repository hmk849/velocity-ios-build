extends ScreenBase
## HUD 编辑器: 拖动按键改位置，滑块改大小，调整透明度，切换左手模式。保存后对局里立即使用。
## 画面里的按键位置 = 对局里的位置（共用 HudLayout.apply）。

var _canvas: Control
var _sel := ""
var _drag := ""
var _scale_slider: HSlider
var _sel_label: Label


func _build(root: MarginContainer) -> void:
    _canvas = Control.new()
    _canvas.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _canvas.mouse_filter = Control.MOUSE_FILTER_STOP
    _canvas.draw.connect(_draw_canvas)
    _canvas.gui_input.connect(_on_input)
    add_child(_canvas)
    move_child(_canvas, 1)                 # 背景之上、UI 控件之下
    _canvas.resized.connect(_canvas.queue_redraw)

    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 12)
    root.add_child(col)

    var top := HBoxContainer.new()
    top.add_theme_constant_override("separation", 16)
    top.add_child(UITheme.label("按键布局编辑", 36, UITheme.TITANIUM))
    var sp := Control.new()
    sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(sp)
    var reset := make_button("重置", false, Vector2(160, 64))
    reset.pressed.connect(_reset)
    top.add_child(reset)
    var save := make_button("保存并返回", true, Vector2(260, 64))
    save.pressed.connect(_save)
    top.add_child(save)
    col.add_child(top)

    var ctl := HBoxContainer.new()
    ctl.add_theme_constant_override("separation", 20)
    _sel_label = UITheme.label("点选一个按键，拖动移动，滑块调大小", 22, UITheme.ICE)
    ctl.add_child(_sel_label)
    _scale_slider = HSlider.new()
    _scale_slider.min_value = 0.6
    _scale_slider.max_value = 1.6
    _scale_slider.step = 0.05
    _scale_slider.value = 1.0
    _scale_slider.custom_minimum_size = Vector2(300, 48)
    _scale_slider.value_changed.connect(_on_scale)
    ctl.add_child(_scale_slider)
    ctl.add_child(UITheme.label("透明度", 22, UITheme.TEXT_DIM))
    var op := HSlider.new()
    op.min_value = 0.2
    op.max_value = 1.0
    op.step = 0.05
    op.value = Settings.touch_opacity
    op.custom_minimum_size = Vector2(220, 48)
    op.value_changed.connect(_on_opacity)
    ctl.add_child(op)
    var lh := CheckButton.new()
    lh.text = "左手模式"
    lh.button_pressed = Settings.left_handed
    lh.toggled.connect(_on_left)
    ctl.add_child(lh)
    col.add_child(ctl)


func _layout() -> Array:
    var vp := _canvas.size
    return HudLayout.apply(TouchControls.default_buttons(vp, SafeArea.margins(get_viewport())), vp)


func _draw_canvas() -> void:
    var vp := _canvas.size
    var m := SafeArea.margins(get_viewport())
    var a := Settings.touch_opacity
    # 摇杆示意
    var sx := m.x + 260.0
    if Settings.left_handed:
        sx = vp.x - sx
    _canvas.draw_arc(Vector2(sx, vp.y - m.w - 230.0), 120.0, 0.0, TAU, 48, Color(UITheme.TITANIUM, a * 0.6), 3.0, true)
    _canvas.draw_circle(Vector2(sx, vp.y - m.w - 230.0), 46.0, Color(UITheme.TITANIUM, a * 0.6))
    var font := get_theme_default_font()
    for b: Dictionary in _layout():
        var sel: bool = String(b.id) == _sel
        _canvas.draw_circle(b.pos, b.r, Color(UITheme.ICE, a * 0.5) if sel else Color(UITheme.GUNMETAL, a * 0.7))
        _canvas.draw_arc(b.pos, b.r, 0.0, TAU, 40, Color(UITheme.WARN if sel else UITheme.TITANIUM, minf(a + 0.3, 1.0)), 3.0, true)
        var fs := 26 if b.r > 60.0 else 20
        _canvas.draw_string(font, b.pos + Vector2(-b.r, fs * 0.35), b.label, HORIZONTAL_ALIGNMENT_CENTER, b.r * 2.0, fs, Color.WHITE)


func _on_input(event: InputEvent) -> void:
    if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            _drag = ""
            for b: Dictionary in _layout():
                if event.position.distance_to(b.pos) <= float(b.r) * 1.2:
                    _drag = String(b.id)
                    _sel = _drag
                    _scale_slider.set_value_no_signal(HudLayout.get_scale(_sel))
                    _sel_label.text = "选中: %s" % _sel.to_upper()
            _canvas.queue_redraw()
        else:
            _drag = ""
    elif event is InputEventMouseMotion and _drag != "" and (event.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0:
        var rel: Vector2 = event.relative
        if Settings.left_handed:
            rel.x = -rel.x
        HudLayout.set_offset(_drag, HudLayout.get_offset(_drag) + rel)
        _canvas.queue_redraw()


func _on_scale(v: float) -> void:
    if _sel != "":
        HudLayout.set_scale(_sel, v)
        _canvas.queue_redraw()


func _on_opacity(v: float) -> void:
    Settings.touch_opacity = v
    _canvas.queue_redraw()


func _on_left(on: bool) -> void:
    Settings.left_handed = on
    _canvas.queue_redraw()


func _reset() -> void:
    HudLayout.reset()
    _sel = ""
    _canvas.queue_redraw()
    show_toast("已恢复默认布局")


func _save() -> void:
    HudLayout.save()
    Settings.save_settings()
    SceneRouter.goto("res://ui/lobby/lobby.tscn")
