extends ScreenBase
## 干员选择: 12 名干员的定位、背景故事、被动/主动/终极技能说明，带角色预览。
## 选择后存入 Loadout，单机对战/训练场使用。技能目前未做网络同步。

var _cur := ""
var _preview: Puppet
var _name: Label
var _role: Label
var _story: Label
var _passive: Label
var _active: Label
var _ult: Label
var _pick: Button
var _t := 0.0


func _build(root: MarginContainer) -> void:
    _cur = Loadout.operator
    _build_preview()
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 14)
    root.add_child(col)

    var top := HBoxContainer.new()
    var title := UITheme.label("干员", 40, UITheme.TITANIUM)
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(title)
    var back := make_button("返回大厅", false, Vector2(240, 68))
    back.pressed.connect(func(): SceneRouter.goto("res://ui/lobby/lobby.tscn"))
    top.add_child(back)
    col.add_child(top)

    var main := HBoxContainer.new()
    main.size_flags_vertical = Control.SIZE_EXPAND_FILL
    main.add_theme_constant_override("separation", 24)
    col.add_child(main)

    var scroll := ScrollContainer.new()
    scroll.custom_minimum_size = Vector2(380, 0)
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    main.add_child(scroll)
    var list := VBoxContainer.new()
    list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    list.add_theme_constant_override("separation", 6)
    scroll.add_child(list)
    for o: Dictionary in Operators.LIST:
        var b := make_button("%s · %s" % [o["name"], o["role"]], false, Vector2(0, 60))
        b.alignment = HORIZONTAL_ALIGNMENT_LEFT
        b.pressed.connect(_select.bind(String(o["id"])))
        list.add_child(b)

    var spacer := Control.new()
    spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    main.add_child(spacer)

    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(560, 0)
    panel.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
    panel.add_theme_stylebox_override("panel", UITheme.box(Color(UITheme.PANEL, 0.9), UITheme.BORDER, 1, 24))
    main.add_child(panel)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 10)
    panel.add_child(v)
    _name = UITheme.label("", 44, UITheme.TITANIUM)
    _role = UITheme.label("", 24, UITheme.ICE)
    _story = UITheme.label("", 22, UITheme.TEXT_DIM)
    _story.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _passive = UITheme.label("", 22, UITheme.TITANIUM)
    _passive.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _active = UITheme.label("", 22, UITheme.TITANIUM)
    _active.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _ult = UITheme.label("", 22, UITheme.WARN)
    _ult.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    for l in [_name, _role, _story, _passive, _active, _ult]:
        v.add_child(l)
    _pick = make_button("选择该干员", true, Vector2(0, 72))
    _pick.pressed.connect(_choose)
    v.add_child(_pick)
    _select(_cur)


func _process(delta: float) -> void:
    _t += delta
    if _preview != null:
        _preview.rotation.y = PI + sin(_t * 0.5) * 0.4


func _build_preview() -> void:
    var svc := SubViewportContainer.new()
    svc.stretch = true
    svc.mouse_filter = Control.MOUSE_FILTER_IGNORE
    svc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(svc)
    move_child(svc, 1)
    var vp := SubViewport.new()
    vp.transparent_bg = true
    vp.own_world_3d = true
    vp.msaa_3d = Viewport.MSAA_DISABLED
    svc.add_child(vp)
    var we := WorldEnvironment.new()
    var env := Environment.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("8fa0b2")
    env.ambient_light_energy = 0.6
    we.environment = env
    vp.add_child(we)
    var cam := Camera3D.new()
    vp.add_child(cam)
    cam.look_at_from_position(Vector3(0, 1.25, 3.8), Vector3(0, 1.0, 0))
    var light := DirectionalLight3D.new()
    light.rotation_degrees = Vector3(-35, 35, 0)
    vp.add_child(light)
    _preview = Puppet.new()
    vp.add_child(_preview)
    var d := WeaponCatalog.load_weapon(Loadout.primary)
    if d != null:
        _preview.set_weapon(d, WeaponStats.equipped_attachments(d))
    _preview.rotation.y = PI


func _select(id: String) -> void:
    var o := Operators.get_by_id(id)
    _cur = String(o["id"])
    var p: Dictionary = o["passive"]
    var a: Dictionary = o["active"]
    var u: Dictionary = o["ult"]
    _name.text = String(o["name"])
    _role.text = "定位: %s" % o["role"]
    _story.text = String(o["story"])
    _passive.text = "被动 · %s\n%s" % [p["name"], p["desc"]]
    _active.text = "主动 · %s（冷却 %d 秒）\n%s" % [a["name"], int(a["cd"]), a["desc"]]
    _ult.text = "终极 · %s（需充能，命中/击杀/时间积累）\n%s" % [u["name"], u["desc"]]
    if _preview != null:
        _preview.set_team_color(Color(String(o["color"])))
    _pick.text = "已选择" if _cur == Loadout.operator else "选择该干员"
    _pick.disabled = _cur == Loadout.operator


func _choose() -> void:
    Loadout.operator = _cur
    Loadout.save()
    show_toast("已选择干员: %s" % Operators.get_by_id(_cur)["name"])
    _select(_cur)
