class_name MatchHud
extends Control
## 对局 HUD（Phase 4）: 比分/计时、击杀播报、血条、受击方向与屏幕泛红、连杀横幅、
## 开局倒计时、死亡/重生倒计时、赛后结算（计分板 + 再来一局/返回大厅）。
## 只订阅 EventBus，不引用 gameplay 类。位置在 _layout() 里按视口尺寸计算，适配不同屏幕比例。

signal rematch_requested
signal exit_requested

const TEAM_COL := [Color("7fd3ff"), Color("ff7a1a")]
const TEAM_NAME := ["ALPHA", "BRAVO"]

var _score0: Label
var _score1: Label
var _time: Label
var _limit: Label
var _hp_bar: ProgressBar
var _hp_lbl: Label
var _banner: Label
var _center: Label
var _death: Label
var _status: Label
var _feed: VBoxContainer
var _end_layer: Control

var _hits: Array = []          # {angle, t}
var _flash := 0.0
var _hp := 100.0
var _banner_t := 0.0
var _alive := true
var _death_base := ""
var online := false


func _ready() -> void:
    theme = Game.ui_theme
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    _score0 = _pill(TEAM_COL[0])
    _score1 = _pill(TEAM_COL[1])
    _time = _pill(Color("b9c2cc"))
    _limit = UITheme.label("", 20, UITheme.TEXT_DIM)
    _limit.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    add_child(_limit)

    _hp_bar = ProgressBar.new()
    _hp_bar.min_value = 0.0
    _hp_bar.max_value = 100.0
    _hp_bar.value = 100.0
    _hp_bar.show_percentage = false
    _hp_bar.add_theme_stylebox_override("background", UITheme.box(Color(0, 0, 0, 0.45), UITheme.BORDER, 1, 0))
    _hp_bar.add_theme_stylebox_override("fill", UITheme.box(UITheme.ICE, UITheme.ICE, 0, 0))
    add_child(_hp_bar)
    _hp_lbl = UITheme.label("100", 24, UITheme.TITANIUM)
    add_child(_hp_lbl)

    _banner = UITheme.label("", 56, UITheme.WARN)
    _banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    add_child(_banner)
    _center = UITheme.label("", 120, UITheme.TITANIUM)
    _center.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    add_child(_center)
    _death = UITheme.label("", 40, UITheme.WARN)
    _death.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    add_child(_death)
    _status = UITheme.label("", 32, UITheme.ICE)
    _status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    add_child(_status)

    _feed = VBoxContainer.new()
    _feed.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _feed.add_theme_constant_override("separation", 4)
    add_child(_feed)

    EventBus.player_health.connect(_on_health)
    EventBus.player_damaged.connect(_on_damaged)
    EventBus.player_died.connect(_on_died)
    EventBus.respawn_timer.connect(_on_respawn_timer)
    EventBus.match_phase.connect(_on_phase)
    EventBus.match_score.connect(_on_score)
    EventBus.match_time.connect(_on_time)
    EventBus.kill_feed.connect(_on_kill_feed)
    EventBus.streak_banner.connect(_on_banner)
    EventBus.match_ended.connect(_on_ended)
    resized.connect(_layout)
    _layout()


func _exit_tree() -> void:
    for pair in [[EventBus.player_health, _on_health], [EventBus.player_damaged, _on_damaged],
            [EventBus.player_died, _on_died], [EventBus.respawn_timer, _on_respawn_timer],
            [EventBus.match_phase, _on_phase], [EventBus.match_score, _on_score],
            [EventBus.match_time, _on_time], [EventBus.kill_feed, _on_kill_feed],
            [EventBus.streak_banner, _on_banner], [EventBus.match_ended, _on_ended]]:
        if pair[0].is_connected(pair[1]):
            pair[0].disconnect(pair[1])


func set_online(on: bool) -> void:
    online = on


func set_status(text: String) -> void:
    _status.text = text


func _pill(col: Color) -> Label:
    var l := UITheme.label("0", 34, col)
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    l.add_theme_stylebox_override("normal", UITheme.box(Color(0.04, 0.05, 0.06, 0.75), col, 1, 6))
    add_child(l)
    return l


func _layout() -> void:
    var m := SafeArea.margins(get_viewport())
    var w := size.x
    var h := size.y
    var cx := w * 0.5
    var top := maxf(m.y, 12.0) + 10.0
    _score0.position = Vector2(cx - 190, top)
    _score0.size = Vector2(90, 52)
    _time.position = Vector2(cx - 90, top)
    _time.size = Vector2(180, 52)
    _score1.position = Vector2(cx + 100, top)
    _score1.size = Vector2(90, 52)
    _limit.position = Vector2(cx - 150, top + 54)
    _limit.size = Vector2(300, 26)
    _hp_bar.position = Vector2(cx - 190, h - 178 - m.w)
    _hp_bar.size = Vector2(380, 14)
    _hp_lbl.position = Vector2(cx - 190, h - 212 - m.w)
    _banner.position = Vector2(0, h * 0.2)
    _banner.size = Vector2(w, 70)
    _center.position = Vector2(0, h * 0.3)
    _center.size = Vector2(w, 150)
    _death.position = Vector2(0, h * 0.4)
    _death.size = Vector2(w, 130)
    _status.position = Vector2(0, h * 0.45)
    _status.size = Vector2(w, 60)
    _feed.position = Vector2(w - 560 - m.z, top + 90)
    _feed.size = Vector2(540, 200)


func _process(delta: float) -> void:
    _flash = maxf(_flash - delta * 1.6, 0.0)
    _banner_t = maxf(_banner_t - delta, 0.0)
    if _banner_t <= 0.0:
        _banner.text = ""
    for i in range(_hits.size() - 1, -1, -1):
        _hits[i]["t"] = float(_hits[i]["t"]) - delta
        if float(_hits[i]["t"]) <= 0.0:
            _hits.remove_at(i)
    queue_redraw()


func _draw() -> void:
    var c := size * 0.5
    var vig := _flash * 0.35
    if _hp < 30.0 and _alive:
        vig = maxf(vig, 0.12 + 0.08 * sin(Time.get_ticks_msec() * 0.008))
    if vig > 0.0:
        draw_rect(Rect2(Vector2.ZERO, size), Color(0.8, 0.0, 0.0, vig))
    for h in _hits:
        var a := float(h["angle"]) - PI * 0.5
        draw_arc(c, minf(size.y * 0.22, 190.0), a - 0.32, a + 0.32, 14, Color(1.0, 0.2, 0.2, clampf(float(h["t"]), 0.0, 1.0)), 10.0, true)


# ---------- 事件 ----------
func _on_health(hp: float, max_hp: float) -> void:
    _hp = hp
    _hp_bar.max_value = max_hp
    _hp_bar.value = hp
    _hp_lbl.text = str(int(ceil(hp)))
    var col := UITheme.ICE if hp > 30.0 else UITheme.WARN
    _hp_bar.add_theme_stylebox_override("fill", UITheme.box(col, col, 0, 0))


func _on_damaged(angle: float) -> void:
    _hits.append({"angle": angle, "t": 1.0})
    _flash = 1.0


func _on_died(killer: String, weapon: String) -> void:
    _alive = false
    _death_base = ("被 %s 击杀  %s" % [killer, weapon]) if killer != "" else "你已阵亡"
    _death.text = _death_base


func _on_respawn_timer(seconds: float) -> void:
    if seconds > 0.0 and not _alive:
        _death.text = "%s\n重生 %.1f" % [_death_base, seconds]
    elif seconds <= 0.0:
        _alive = true
        _death.text = ""


func _on_phase(phase: String, seconds: float) -> void:
    match phase:
        "COUNTDOWN":
            _center.text = str(int(ceil(seconds)))
            if _end_layer != null:               # 服务器自动重开新一局
                _end_layer.queue_free()
                _end_layer = null
                _alive = true
                _death.text = ""
        "LIVE":
            _center.text = "GO"
            get_tree().create_timer(0.8).timeout.connect(_clear_center)
        "OVERTIME":
            _banner.text = "OVERTIME  下一个击杀决胜"
            _banner_t = 3.0
        "ENDED":
            _center.text = ""


func _clear_center() -> void:
    _center.text = ""


func _on_score(t0: int, t1: int, limit: int) -> void:
    _score0.text = str(t0)
    _score1.text = str(t1)
    _limit.text = "先到 %d 击杀获胜" % limit


func _on_time(seconds_left: float) -> void:
    var s := int(ceil(seconds_left))
    _time.text = "%d:%02d" % [s / 60, s % 60]


func _on_banner(text: String) -> void:
    _banner.text = text
    _banner_t = 2.2


func _on_kill_feed(killer: String, victim: String, weapon: String, headshot: bool, kt: int, vt: int) -> void:
    while _feed.get_child_count() >= 5:
        var old := _feed.get_child(0)
        _feed.remove_child(old)
        old.queue_free()
    var row := HBoxContainer.new()
    row.size_flags_horizontal = Control.SIZE_SHRINK_END
    row.add_theme_constant_override("separation", 10)
    row.mouse_filter = Control.MOUSE_FILTER_IGNORE
    if kt >= 0:
        row.add_child(UITheme.label(killer, 22, TEAM_COL[kt]))
    else:
        row.add_child(UITheme.label("—", 22, UITheme.TEXT_DIM))
    row.add_child(UITheme.label(("%s %s" % [weapon, "◆" if headshot else ""]).strip_edges(), 18, UITheme.TEXT_DIM))
    row.add_child(UITheme.label(victim, 22, TEAM_COL[vt]))
    _feed.add_child(row)
    var tw := row.create_tween()
    tw.tween_interval(6.0)
    tw.tween_property(row, "modulate:a", 0.0, 0.5)
    tw.tween_callback(row.queue_free)


# ---------- 赛后结算 ----------
func _on_ended(winner: int, rows: Array) -> void:
    if _end_layer != null:
        return
    _end_layer = Control.new()
    _end_layer.mouse_filter = Control.MOUSE_FILTER_STOP
    _end_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(_end_layer)
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.78)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _end_layer.add_child(dim)
    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _end_layer.add_child(center)
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(980, 0)
    panel.add_theme_stylebox_override("panel", UITheme.box(UITheme.PANEL, UITheme.BORDER, 1, 28))
    center.add_child(panel)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 10)
    panel.add_child(col)

    var mine := 0
    for r in rows:
        if r["is_player"]:
            mine = int(r["team"])
    var title := "平局"
    var tcol := UITheme.TITANIUM
    if winner >= 0:
        title = "胜利" if winner == mine else "失败"
        tcol = UITheme.ICE if winner == mine else UITheme.WARN
    var t := UITheme.label(title, 72, tcol)
    t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(t)
    var sc := UITheme.label("%s  %s : %s  %s" % [TEAM_NAME[0], _score0.text, _score1.text, TEAM_NAME[1]], 30, UITheme.TITANIUM)
    sc.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(sc)

    col.add_child(_row("玩家", "队伍", "击杀", "死亡", UITheme.TEXT_DIM, false))
    for r in rows:
        var tc: Color = TEAM_COL[int(r["team"])]
        col.add_child(_row(String(r["name"]), TEAM_NAME[int(r["team"])], str(r["kills"]), str(r["deaths"]), tc, bool(r["is_player"])))

    var btns := HBoxContainer.new()
    btns.add_theme_constant_override("separation", 16)
    var again := Button.new()
    again.text = "再来一局"
    again.custom_minimum_size = Vector2(0, 76)
    again.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    UITheme.style_primary(again)
    again.visible = not online
    again.pressed.connect(rematch_requested.emit)
    var exit := Button.new()
    exit.text = "返回大厅"
    exit.custom_minimum_size = Vector2(0, 76)
    exit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    exit.pressed.connect(exit_requested.emit)
    btns.add_child(again)
    btns.add_child(exit)
    col.add_child(btns)
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _row(a: String, b: String, c: String, d: String, col: Color, bold: bool) -> Control:
    var h := HBoxContainer.new()
    if bold:
        h.add_theme_constant_override("separation", 8)
    var sizes := [360.0, 160.0, 120.0, 120.0]
    var texts := [("▶ " + a) if bold else a, b, c, d]
    for i in 4:
        var l := UITheme.label(String(texts[i]), 24, col if (i < 2 or bold) else UITheme.TITANIUM)
        l.custom_minimum_size = Vector2(float(sizes[i]), 0)
        if i >= 2:
            l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
        h.add_child(l)
    return h
