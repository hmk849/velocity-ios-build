class_name TouchControls
extends Control
## 触屏控制: 左半屏浮动摇杆移动，右半屏拖动转视角，右下角按钮。
## 多指独立追踪；按钮判定范围比视觉半径大 30%。
## 开火键上拖动同时可以转视角（边开火边瞄）。
## ADS 为点按切换；HOOK=钩爪；SCOPE=切换瞄具。
## 未实现: 按键布局编辑器、陀螺仪、辅助瞄准、手柄（Phase 6）。

const STICK_R := 120.0
const DEADZONE := 0.12
const HIT_SCALE := 1.3

var move_vector := Vector2.ZERO    # x=右, y=前，长度 0~1
var fire_held := false

var _flags: Dictionary = {}        # 单次触发的按钮: id -> bool
var _look_delta := Vector2.ZERO
var _move_finger := -1
var _look_finger := -1
var _stick_origin := Vector2.ZERO
var _stick_pos := Vector2.ZERO
var _btn_fingers: Dictionary = {}  # 手指序号 -> 按钮 id
var _ab_ready := 1.0
var _ult_charge := 0.0


func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    EventBus.ability_state.connect(_on_ability)


func _exit_tree() -> void:
    if EventBus.ability_state.is_connected(_on_ability):
        EventBus.ability_state.disconnect(_on_ability)


func _on_ability(_an: String, ready_frac: float, _un: String, charge: float) -> void:
    _ab_ready = ready_frac
    _ult_charge = charge
    queue_redraw()


## 读取并清除一次性按钮（jump / slide / ads / grapple / reload / swap / scope / view / inspect）
func consume(id: String) -> bool:
    var v: bool = _flags.get(id, false)
    _flags[id] = false
    return v


func consume_look() -> Vector2:
    var d := _look_delta
    _look_delta = Vector2.ZERO
    return d


## 默认按键布局（视口坐标）。HudLayout 会叠加玩家自定义的偏移/缩放/左手镜像。
static func default_buttons(vp: Vector2, m: Vector4) -> Array:
    var r := vp.x - m.z - 70.0
    var b := vp.y - m.w - 70.0
    return [
        {"id": "fire", "label": "FIRE", "pos": Vector2(r - 110, b - 120), "r": 92.0},
        {"id": "jump", "label": "JUMP", "pos": Vector2(r - 350, b - 50), "r": 66.0},
        {"id": "slide", "label": "SLIDE", "pos": Vector2(r - 50, b - 360), "r": 58.0},
        {"id": "ads", "label": "ADS", "pos": Vector2(r - 250, b - 310), "r": 58.0},
        {"id": "grapple", "label": "HOOK", "pos": Vector2(r - 450, b - 210), "r": 48.0},
        {"id": "reload", "label": "R", "pos": Vector2(r - 550, b - 80), "r": 44.0},
        {"id": "swap", "label": "SWAP", "pos": Vector2(r - 600, b - 220), "r": 44.0},
        {"id": "scope", "label": "SCOPE", "pos": Vector2(r - 720, b - 150), "r": 44.0},
        {"id": "view", "label": "CAM", "pos": Vector2(r - 130, b - 560), "r": 38.0},
        {"id": "inspect", "label": "INSP", "pos": Vector2(r - 260, b - 520), "r": 38.0},
        {"id": "ability", "label": "ABIL", "pos": Vector2(r - 360, b - 430), "r": 50.0},
        {"id": "ultimate", "label": "ULT", "pos": Vector2(r - 500, b - 340), "r": 50.0},
    ]


func _buttons() -> Array:
    var vp := get_viewport_rect().size
    var m := SafeArea.margins(get_viewport())
    return HudLayout.apply(default_buttons(vp, m), vp)


func _button_at(pos: Vector2) -> String:
    for btn: Dictionary in _buttons():
        if pos.distance_to(btn.pos) <= btn.r * HIT_SCALE:
            return btn.id
    return ""


func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            _on_down(event.index, event.position)
        else:
            _on_up(event.index)
    elif event is InputEventScreenDrag:
        _on_drag(event.index, event.position, event.relative)


func _on_down(idx: int, pos: Vector2) -> void:
    var id := _button_at(pos)
    if id != "":
        _btn_fingers[idx] = id
        if id == "fire":
            fire_held = true
        else:
            _flags[id] = true
    elif (pos.x < get_viewport_rect().size.x * 0.5) != Settings.left_handed:
        if _move_finger == -1:
            _move_finger = idx
            _stick_origin = pos
            _stick_pos = pos
    elif _look_finger == -1:
        _look_finger = idx
    queue_redraw()


func _on_up(idx: int) -> void:
    if _btn_fingers.has(idx):
        if _btn_fingers[idx] == "fire":
            fire_held = false
        _btn_fingers.erase(idx)
        # 还有别的手指按着开火键
        if "fire" in _btn_fingers.values():
            fire_held = true
    if idx == _move_finger:
        _move_finger = -1
        move_vector = Vector2.ZERO
    if idx == _look_finger:
        _look_finger = -1
    queue_redraw()


func _on_drag(idx: int, pos: Vector2, rel: Vector2) -> void:
    if idx == _move_finger:
        var d := pos - _stick_origin
        if d.length() > STICK_R:
            _stick_origin = pos - d.normalized() * STICK_R   # 浮动摇杆跟随手指
            d = pos - _stick_origin
        _stick_pos = pos
        var v := Vector2(d.x, -d.y) / STICK_R
        move_vector = v.limit_length(1.0) if v.length() > DEADZONE else Vector2.ZERO
    elif idx == _look_finger or _btn_fingers.get(idx, "") == "fire":
        _look_delta += rel
    queue_redraw()


func _draw() -> void:
    var a := Settings.touch_opacity
    var col := Color(UITheme.TITANIUM, a)
    var vp := get_viewport_rect().size
    var m := SafeArea.margins(get_viewport())

    # 摇杆
    var base := _stick_origin
    var knob := _stick_pos
    if _move_finger == -1:
        base = Vector2(m.x + 260.0, vp.y - m.w - 230.0)
        if Settings.left_handed:
            base.x = vp.x - base.x
        knob = base
    knob = base + (knob - base).limit_length(STICK_R)
    draw_arc(base, STICK_R, 0.0, TAU, 48, Color(col, a * 0.6), 3.0, true)
    draw_circle(knob, 46.0, Color(col, a * 0.7))

    # 按钮
    var font := get_theme_default_font()
    var pressed_ids := _btn_fingers.values()
    for btn: Dictionary in _buttons():
        var down: bool = btn.id in pressed_ids
        var fill := Color(UITheme.ICE, a * 0.5) if down else Color(UITheme.GUNMETAL, a * 0.55)
        draw_circle(btn.pos, btn.r, fill)
        draw_arc(btn.pos, btn.r, 0.0, TAU, 40, col, 3.0, true)
        var fs := 26 if btn.r > 60.0 else 20
        draw_string(font, btn.pos + Vector2(-btn.r, fs * 0.35), btn.label,
            HORIZONTAL_ALIGNMENT_CENTER, btn.r * 2.0, fs, Color(1, 1, 1, minf(a + 0.3, 1.0)))
        if btn.id == "ability":
            draw_arc(btn.pos, btn.r + 7.0, -PI * 0.5, -PI * 0.5 + TAU * _ab_ready, 40, Color(UITheme.ICE, minf(a + 0.3, 1.0)), 5.0, true)
        elif btn.id == "ultimate":
            var full := _ult_charge >= 0.999
            draw_arc(btn.pos, btn.r + 7.0, -PI * 0.5, -PI * 0.5 + TAU * _ult_charge, 40, Color(UITheme.WARN, 1.0 if full else minf(a + 0.3, 1.0)), 6.0 if full else 5.0, true)
