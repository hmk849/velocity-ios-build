extends ScreenBase
## 大厅。中央是程序化角色 Puppet（占位模型，动画由代码生成: 呼吸、调整枪械、检查弹匣、环顾）。
## 持有当前主武器与配件。导航里「开始游戏」「武器」「设置」是真实功能，其余明确提示未实现。

const NAV := [
    ["开始游戏", ""],
    ["干员", ""],
    ["武器", ""],
    ["仓库", "第 6 阶段"],
    ["战斗通行证", "第 7 阶段之后"],
    ["任务", "第 7 阶段之后"],
    ["排行榜", "第 5 阶段之后"],
]

var _mannequin: Node3D
var _t := 0.0
var _mode_idx := 0
var _diff_idx := 1
var _diff_block: Control
var _go_btn: Button
var _addr_block: Control
var _addr_edit: LineEdit


func _build(root: MarginContainer) -> void:
    _build_preview()

    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 24)
    root.add_child(col)
    col.add_child(_build_top_bar())

    var mid := HBoxContainer.new()
    mid.size_flags_vertical = Control.SIZE_EXPAND_FILL
    col.add_child(mid)
    mid.add_child(_build_nav())
    var sp := Control.new()
    sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    mid.add_child(sp)
    mid.add_child(_build_right_panel())

    col.add_child(_build_bottom_bar())


func _process(delta: float) -> void:
    _t += delta
    if _mannequin:
        _mannequin.rotation.y = PI + sin(_t * 0.4) * 0.28      # 面向镜头，缓慢转动


# ---------- 区块 ----------
func _build_top_bar() -> Control:
    var p: Dictionary = AuthService.profile
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 20)

    var avatar := PanelContainer.new()
    avatar.custom_minimum_size = Vector2(76, 76)
    avatar.add_theme_stylebox_override("panel", UITheme.box(UITheme.GUNMETAL, UITheme.ICE, 1, 8))
    var ini := UITheme.label(String(p.nickname).substr(0, 1), 36, UITheme.ICE)
    ini.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    avatar.add_child(ini)
    row.add_child(avatar)

    var info := VBoxContainer.new()
    info.alignment = BoxContainer.ALIGNMENT_CENTER
    info.add_child(UITheme.label(p.nickname, 30, UITheme.TITANIUM))
    info.add_child(UITheme.label("Lv.%d" % p.level, 22, UITheme.TEXT_DIM))
    row.add_child(info)

    var sp := Control.new()
    sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_child(sp)

    var st := make_button("设置", false, Vector2(180, 76))
    st.pressed.connect(_open_settings)
    row.add_child(st)
    return row


func _build_nav() -> Control:
    var v := VBoxContainer.new()
    v.custom_minimum_size = Vector2(340, 0)
    v.add_theme_constant_override("separation", 12)
    for item in NAV:
        var title: String = item[0]
        var b := make_button(title, false, Vector2(0, 74))
        b.alignment = HORIZONTAL_ALIGNMENT_LEFT
        b.pressed.connect(_on_nav.bind(title, item[1]))
        v.add_child(b)
    return v


func _build_right_panel() -> Control:
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(440, 0)
    panel.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
    panel.add_theme_stylebox_override("panel", UITheme.box(Color(UITheme.PANEL, 0.85), UITheme.BORDER, 1, 24))
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 10)
    panel.add_child(v)
    v.add_child(UITheme.label("DEV BUILD  %s" % Game.VERSION, 26, UITheme.ICE))
    v.add_child(UITheme.label("已实现: 干员技能(单机)、武器工坊、训练场、NEON DISTRICT 团队死斗、联机(需服务器)", 22, UITheme.TITANIUM))
    v.add_child(UITheme.label("未实现: 音频、地图 2-8、正式匹配服务", 22, UITheme.TEXT_DIM))
    return panel


func _build_bottom_bar() -> Control:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 36)
    row.add_child(_option_block("模式", ["团队死斗 6V6（人机）", "训练场", "联机对战（连接服务器）"], _on_mode))
    row.add_child(_option_block("地图", ["NEON DISTRICT"], Callable()))
    _diff_block = _option_block("难度", ["简单", "普通", "困难"], _on_diff, 1)
    row.add_child(_diff_block)
    _addr_block = VBoxContainer.new()
    _addr_block.add_child(UITheme.label("服务器地址", 20, UITheme.TEXT_DIM))
    _addr_edit = LineEdit.new()
    _addr_edit.text = Settings.server_address
    _addr_edit.placeholder_text = "ip:端口"
    _addr_edit.custom_minimum_size = Vector2(320, 64)
    _addr_block.add_child(_addr_edit)
    _addr_block.visible = false
    row.add_child(_addr_block)
    var sp := Control.new()
    sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_child(sp)
    _go_btn = make_button("开始对局", true, Vector2(380, 92))
    _go_btn.pressed.connect(_start)
    row.add_child(_go_btn)
    return row


func _option_block(title: String, items: Array, cb: Callable, selected := 0) -> Control:
    var v := VBoxContainer.new()
    v.add_child(UITheme.label(title, 20, UITheme.TEXT_DIM))
    var ob := OptionButton.new()
    for it in items:
        ob.add_item(String(it))
    ob.select(selected)
    ob.custom_minimum_size = Vector2(300 if items.size() > 1 else 240, 64)
    if cb.is_valid():
        ob.item_selected.connect(cb)
    else:
        ob.disabled = items.size() < 2
    v.add_child(ob)
    return v


func _on_mode(idx: int) -> void:
    _mode_idx = idx
    _diff_block.visible = idx == 0
    _addr_block.visible = idx == 2
    _go_btn.text = ["开始对局", "进入训练场", "加入对局"][idx]


func _on_diff(idx: int) -> void:
    _diff_idx = idx


func _info_block(title: String, value: String) -> Control:
    var v := VBoxContainer.new()
    v.add_child(UITheme.label(title, 20, UITheme.TEXT_DIM))
    v.add_child(UITheme.label(value, 30, UITheme.TITANIUM))
    return v


# ---------- 行为 ----------
func _on_nav(title: String, phase: String) -> void:
    if title == "开始游戏":
        _start()
    elif title == "武器":
        SceneRouter.goto("res://ui/workshop/workshop.tscn")
    elif title == "干员":
        SceneRouter.goto("res://ui/operators/operator_select.tscn")
    else:
        show_toast("「%s」尚未实现（规划：%s）" % [title, phase], true)


func _start() -> void:
    if _mode_idx == 0:
        Game.match_config = {"mode": "tdm", "difficulty": _diff_idx}
        SceneRouter.goto_with_loading(
            "res://gameplay/maps/neon_district.tscn",
            {"map_name": "NEON DISTRICT", "mode": "团队死斗 6V6"})
    elif _mode_idx == 2:
        Settings.server_address = _addr_edit.text.strip_edges()
        Settings.save_settings()
        Game.match_config = {"mode": "tdm", "difficulty": 1, "net_role": "client", "net_address": Settings.server_address}
        SceneRouter.goto_with_loading(
            "res://gameplay/maps/neon_district.tscn",
            {"map_name": "NEON DISTRICT", "mode": "联机 · 团队死斗 6V6"})
    else:
        Game.match_config = {"mode": "range", "difficulty": 1}
        SceneRouter.goto_with_loading(
            "res://gameplay/maps/test_range.tscn",
            {"map_name": "TEST RANGE", "mode": "训练场"})


func _open_settings() -> void:
    add_child(SettingsPanel.new())


# ---------- 占位 3D 预览 ----------
func _build_preview() -> void:
    var svc := SubViewportContainer.new()
    svc.stretch = true
    svc.mouse_filter = Control.MOUSE_FILTER_IGNORE
    svc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(svc)
    move_child(svc, 1)   # 在背景之上、UI 之下

    var vp := SubViewport.new()
    vp.transparent_bg = true
    vp.own_world_3d = true
    vp.msaa_3d = Viewport.MSAA_DISABLED
    svc.add_child(vp)

    var we := WorldEnvironment.new()
    var env := Environment.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("8fa0b2")
    env.ambient_light_energy = 0.6
    we.environment = env
    vp.add_child(we)

    var cam := Camera3D.new()
    vp.add_child(cam)
    cam.look_at_from_position(Vector3(0, 1.25, 3.8), Vector3(0, 1.0, 0))

    var light := DirectionalLight3D.new()
    light.rotation_degrees = Vector3(-35, 35, 0)
    vp.add_child(light)

    var pup := Puppet.new()
    pup.idle_events = true
    vp.add_child(pup)
    var d := WeaponCatalog.load_weapon(Loadout.primary)
    if d != null:
        pup.set_weapon(d, WeaponStats.equipped_attachments(d))
    _mannequin = pup
    _mannequin.rotation.y = PI
