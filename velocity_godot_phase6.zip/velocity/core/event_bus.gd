extends Node
## Autoload: EventBus
## 全局信号总线。规则: gameplay 层只发信号，不引用 ui；ui 订阅信号。

signal ammo_changed(current: int, magazine: int, reloading: bool)
signal weapon_changed(display_name: String, ttk_ms: float, sight_name: String)
signal hit_confirmed(is_head: bool, killed: bool)
## 开镜状态，每帧发出: ads_amount 0~1，倍率，分划样式
signal sight_state(ads_amount: float, zoom: float, reticle: String, pip: bool)
## 移动调试信息（约 10Hz）
signal movement_debug(speed: float, state_name: String)

# ---- 对局（Phase 4）----
signal player_health(hp: float, max_hp: float)
## 受击方向: 弧度，0=正前方，正值=右侧
signal player_damaged(angle: float)
signal player_died(killer_name: String, weapon_name: String)
signal respawn_timer(seconds: float)
## phase: COUNTDOWN / LIVE / OVERTIME / ENDED
signal match_phase(phase: String, seconds: float)
signal match_score(team0: int, team1: int, limit: int)
signal match_time(seconds_left: float)
signal kill_feed(killer: String, victim: String, weapon: String, headshot: bool, killer_team: int, victim_team: int)
signal streak_banner(text: String)
## rows: Array[Dictionary] {name, team, kills, deaths, is_player}
signal match_ended(winner_team: int, rows: Array)

## 联网: 往返时延（毫秒）
signal net_stats(rtt_ms: float)

## 技能状态（约 10Hz）: 主动名, 主动就绪度 0~1, 终极名, 终极充能 0~1
signal ability_state(active_name: String, active_ready: float, ult_name: String, ult_charge: float)
