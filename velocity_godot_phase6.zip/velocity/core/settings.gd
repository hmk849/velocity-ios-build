extends Node
## Autoload: Settings
## 玩家设置，存 user://settings.cfg。只放"已经真正生效"的选项。
## 画质预设 = 一组参数的快捷方式；改动任何单项会自动切到"自定义"。
## 没有做: 音频音量（还没有音频）、环境光遮蔽/动态模糊/景深（Mobile 渲染器不提供）、语言切换、字幕、色盲模式。

const PATH := "user://settings.cfg"
const QUALITY_NAMES := ["极低", "低", "中", "高", "极高", "自定义"]
const PRESETS := [
    {"scale": 0.5, "fps": 30, "shadows": false, "msaa": 0, "fx": 0, "sharpen": true},
    {"scale": 0.67, "fps": 45, "shadows": false, "msaa": 0, "fx": 1, "sharpen": true},
    {"scale": 0.85, "fps": 60, "shadows": true, "msaa": 0, "fx": 1, "sharpen": true},
    {"scale": 1.0, "fps": 60, "shadows": true, "msaa": 0, "fx": 2, "sharpen": false},
    {"scale": 1.0, "fps": 90, "shadows": true, "msaa": 2, "fx": 2, "sharpen": false},
]

# ---- 画面 ----
var quality := 3
var render_scale := 1.0
var target_fps := 60
var fov := 90.0
var shadows := true
var msaa := 0                 # 0 关 / 2 / 4
var fx_quality := 2           # 0 低 / 1 中 / 2 高（粒子数量）
var sharpen := false          # 降低分辨率时用 FSR 放大并锐化
var dynamic_res := false      # 帧率不够时自动降 3D 分辨率
var scope_pip := false        # 倍镜镜内成像（双画面，更耗性能）
var show_fps := true
var damage_numbers := true

# ---- 操作 ----
var look_sens := 1.0
var ads_sens := 0.8
var ads_low := 1.0            # 1x 瞄具灵敏度倍率
var ads_mid := 1.0            # 2x–3x
var ads_high := 1.0           # 4x 及以上
var auto_sprint := true
var touch_opacity := 0.6
var left_handed := false
var gyro_enabled := false
var gyro_sens := 1.0
var gyro_invert_y := false
var aim_assist := 0.5         # 触屏辅助瞄准强度 0~1
var stick_deadzone := 0.15    # 手柄右摇杆死区

# ---- 联网 ----
var server_address := "127.0.0.1:7777"

var _dyn_t := 0.0
var _dyn_scale := 1.0


func _ready() -> void:
    load_settings()
    apply()


func _process(delta: float) -> void:
    if not dynamic_res:
        return
    _dyn_t += delta
    if _dyn_t < 1.0:
        return
    _dyn_t = 0.0
    var fps := float(Engine.get_frames_per_second())
    var tgt := float(target_fps)
    if fps < tgt * 0.85 and _dyn_scale > 0.55:
        _dyn_scale = maxf(_dyn_scale - 0.05, 0.55)
    elif fps > tgt * 0.97 and _dyn_scale < render_scale:
        _dyn_scale = minf(_dyn_scale + 0.025, render_scale)
    get_tree().root.scaling_3d_scale = _dyn_scale


func ads_zoom_mult(zoom: float) -> float:
    if zoom < 1.5:
        return ads_low
    if zoom < 3.5:
        return ads_mid
    return ads_high


## 设备屏幕刷新率允许的帧率选项（"根据设备能力动态开放"）
func available_fps() -> Array:
    var hz := int(round(DisplayServer.screen_get_refresh_rate()))
    if hz <= 0:
        hz = 60
    var out: Array = []
    for f in [30, 45, 60, 90, 120]:
        if f <= maxi(hz, 60):
            out.append(f)
    return out


func fx_mult() -> float:
    return [0.4, 0.7, 1.0][clampi(fx_quality, 0, 2)]


func apply_quality(q: int) -> void:
    quality = q
    if q < 0 or q >= PRESETS.size():
        quality = 5
        return
    var p: Dictionary = PRESETS[q]
    render_scale = float(p["scale"])
    target_fps = int(p["fps"])
    shadows = bool(p["shadows"])
    msaa = int(p["msaa"])
    fx_quality = int(p["fx"])
    sharpen = bool(p["sharpen"])


func load_settings() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(PATH) != OK:
        if Game.is_mobile:
            apply_quality(2)          # 手机首次启动默认"中"
        return
    for key in _keys():
        var sec := String(key[0])
        var pname := String(key[1])
        set(pname, cfg.get_value(sec, pname, get(pname)))


func save_settings() -> void:
    var cfg := ConfigFile.new()
    for key in _keys():
        cfg.set_value(String(key[0]), String(key[1]), get(String(key[1])))
    cfg.save(PATH)


func _keys() -> Array:
    return [
        ["video", "quality"], ["video", "render_scale"], ["video", "target_fps"], ["video", "fov"],
        ["video", "shadows"], ["video", "msaa"], ["video", "fx_quality"], ["video", "sharpen"],
        ["video", "dynamic_res"], ["video", "scope_pip"], ["video", "show_fps"], ["video", "damage_numbers"],
        ["input", "look_sens"], ["input", "ads_sens"], ["input", "ads_low"], ["input", "ads_mid"], ["input", "ads_high"],
        ["input", "auto_sprint"], ["input", "touch_opacity"], ["input", "left_handed"], ["input", "gyro_enabled"],
        ["input", "gyro_sens"], ["input", "gyro_invert_y"], ["input", "aim_assist"], ["input", "stick_deadzone"],
        ["net", "server_address"],
    ]


func apply() -> void:
    Engine.max_fps = target_fps
    var root := get_tree().root
    _dyn_scale = render_scale
    root.scaling_3d_scale = render_scale
    root.scaling_3d_mode = Viewport.SCALING_3D_MODE_FSR if (sharpen and render_scale < 0.99) else Viewport.SCALING_3D_MODE_BILINEAR
    root.fsr_sharpness = 0.4
    match msaa:
        2:
            root.msaa_3d = Viewport.MSAA_2X
        4:
            root.msaa_3d = Viewport.MSAA_4X
        _:
            root.msaa_3d = Viewport.MSAA_DISABLED
