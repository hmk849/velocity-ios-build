class_name HudLayout
extends RefCounted
## 触屏按键的自定义布局: 每个按键的位置偏移 + 缩放，加上"左手模式"镜像。存 user://hud_layout.cfg。
## TouchControls 和 HUD 编辑器共用 apply()，保证编辑器里看到的就是对局里的位置。

const PATH := "user://hud_layout.cfg"

static var _data: Dictionary = {}     # id -> {"dx", "dy", "s"}
static var _loaded := false


static func _ensure() -> void:
    if _loaded:
        return
    _loaded = true
    var cfg := ConfigFile.new()
    if cfg.load(PATH) == OK:
        _data = cfg.get_value("layout", "buttons", {})


static func save() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("layout", "buttons", _data)
    cfg.save(PATH)


static func reset() -> void:
    _ensure()
    _data.clear()


static func get_offset(id: String) -> Vector2:
    _ensure()
    var o: Dictionary = _data.get(id, {})
    return Vector2(float(o.get("dx", 0.0)), float(o.get("dy", 0.0)))


static func set_offset(id: String, v: Vector2) -> void:
    _ensure()
    var o: Dictionary = _data.get(id, {})
    o["dx"] = v.x
    o["dy"] = v.y
    _data[id] = o


static func get_scale(id: String) -> float:
    _ensure()
    return float((_data.get(id, {}) as Dictionary).get("s", 1.0))


static func set_scale(id: String, s: float) -> void:
    _ensure()
    var o: Dictionary = _data.get(id, {})
    o["s"] = s
    _data[id] = o


## 在默认布局上叠加偏移/缩放/左手镜像
static func apply(list: Array, vp: Vector2) -> Array:
    _ensure()
    var out: Array = []
    for b in list:
        var d: Dictionary = (b as Dictionary).duplicate()
        var pos: Vector2 = d["pos"] + get_offset(String(d["id"]))
        d["r"] = float(d["r"]) * get_scale(String(d["id"]))
        if Settings.left_handed:
            pos.x = vp.x - pos.x
        d["pos"] = pos
        out.append(d)
    return out
