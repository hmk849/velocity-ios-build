extends Node
## Autoload: Game
## 职责: 版本号、平台判断、UI 主题、跨场景传参。不放具体玩法逻辑。

const GAME_NAME := "PROJECT VELOCITY"
const VERSION := "0.1.0-phase1"

var is_mobile := false
var is_server := false       # 专用服务器（--server）: 不渲染界面/特效
var ui_theme: Theme
## 传给 loading 场景的参数: { "path": String, "info": Dictionary }
var pending_load: Dictionary = {}
## 对局配置: { mode: "tdm"|"range", difficulty: 0|1|2 }
var match_config: Dictionary = {"mode": "tdm", "difficulty": 1}


func _ready() -> void:
    is_mobile = OS.has_feature("mobile")
    InputSetup.register_actions()
    ui_theme = UITheme.build()
    # 专用服务器: godot --headless --path . -- --server --port=7777 --difficulty=1
    var args := OS.get_cmdline_user_args()
    if "--server" in args:
        var port := 7777
        var diff := 1
        for a in args:
            if a.begins_with("--port="):
                port = int(a.substr(7))
            elif a.begins_with("--difficulty="):
                diff = int(a.substr(13))
        is_server = true
        match_config = {"mode": "tdm", "difficulty": diff, "net_role": "server", "port": port}
        get_tree().change_scene_to_file.call_deferred("res://gameplay/maps/neon_district.tscn")
