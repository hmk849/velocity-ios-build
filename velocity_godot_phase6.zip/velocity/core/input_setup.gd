class_name InputSetup
extends RefCounted
## 运行时注册输入动作。
## 桌面: 键鼠调试用。手机: 触屏由 TouchControls 直接处理。
## 注意: 手机上不绑定鼠标键，否则触摸模拟出的鼠标点击会误触发 fire。

static func register_actions() -> void:
    _key("move_forward", KEY_W)
    _key("move_back", KEY_S)
    _key("move_left", KEY_A)
    _key("move_right", KEY_D)
    _key("jump", KEY_SPACE)
    _key("sprint", KEY_SHIFT)
    _key("slide", KEY_C)
    _key("slide", KEY_CTRL)
    _key("reload", KEY_R)
    _key("swap", KEY_Q)
    _key("grapple", KEY_E)
    _key("scope", KEY_V)
    _key("use", KEY_F)
    _key("view", KEY_P)
    _key("inspect", KEY_T)
    _key("ability", KEY_G)
    _key("ultimate", KEY_X)
    _ensure("fire")
    _ensure("ads")
    _register_gamepad()
    if not OS.has_feature("mobile"):
        _mouse("fire", MOUSE_BUTTON_LEFT)
        _mouse("ads", MOUSE_BUTTON_RIGHT)


static func _ensure(action: StringName) -> void:
    if not InputMap.has_action(action):
        InputMap.add_action(action)


static func _key(action: StringName, keycode: Key) -> void:
    _ensure(action)
    var ev := InputEventKey.new()
    ev.physical_keycode = keycode
    InputMap.action_add_event(action, ev)


static func _mouse(action: StringName, button: MouseButton) -> void:
    _ensure(action)
    var ev := InputEventMouseButton.new()
    ev.button_index = button
    InputMap.action_add_event(action, ev)


## 手柄（外接，手机和桌面都可用）: 左摇杆移动、右摇杆视角、RT 开火、LT 开镜
static func _register_gamepad() -> void:
    for a in ["look_left", "look_right", "look_up", "look_down"]:
        _ensure(a)
    _axis("move_left", JOY_AXIS_LEFT_X, -1.0)
    _axis("move_right", JOY_AXIS_LEFT_X, 1.0)
    _axis("move_forward", JOY_AXIS_LEFT_Y, -1.0)
    _axis("move_back", JOY_AXIS_LEFT_Y, 1.0)
    _axis("look_left", JOY_AXIS_RIGHT_X, -1.0)
    _axis("look_right", JOY_AXIS_RIGHT_X, 1.0)
    _axis("look_up", JOY_AXIS_RIGHT_Y, -1.0)
    _axis("look_down", JOY_AXIS_RIGHT_Y, 1.0)
    _axis("fire", JOY_AXIS_TRIGGER_RIGHT, 1.0)
    _axis("ads", JOY_AXIS_TRIGGER_LEFT, 1.0)
    _pad("jump", JOY_BUTTON_A)
    _pad("slide", JOY_BUTTON_B)
    _pad("reload", JOY_BUTTON_X)
    _pad("swap", JOY_BUTTON_Y)
    _pad("sprint", JOY_BUTTON_LEFT_STICK)
    _pad("use", JOY_BUTTON_RIGHT_STICK)
    _pad("grapple", JOY_BUTTON_RIGHT_SHOULDER)
    _pad("scope", JOY_BUTTON_LEFT_SHOULDER)
    _pad("ability", JOY_BUTTON_DPAD_UP)
    _pad("ultimate", JOY_BUTTON_DPAD_DOWN)
    _pad("view", JOY_BUTTON_DPAD_LEFT)
    _pad("inspect", JOY_BUTTON_DPAD_RIGHT)
    for a in ["move_left", "move_right", "move_forward", "move_back", "look_left", "look_right", "look_up", "look_down"]:
        InputMap.action_set_deadzone(a, 0.2)


static func _axis(action: StringName, axis: JoyAxis, value: float) -> void:
    _ensure(action)
    var ev := InputEventJoypadMotion.new()
    ev.axis = axis
    ev.axis_value = value
    InputMap.action_add_event(action, ev)


static func _pad(action: StringName, button: JoyButton) -> void:
    _ensure(action)
    var ev := InputEventJoypadButton.new()
    ev.button_index = button
    InputMap.action_add_event(action, ev)
