#!/usr/bin/env python3
"""生成 gameplay/maps/neon_layout.gd（NEON DISTRICT 的几何/出生点/兴趣点数据），并做布局校验。
用法: python3 tools/gen_neon_district.py   （在工程根目录运行）

坐标: x 东西, z 南北(北半区 z<0, 南半区由镜像得到), y 向上。世界范围 x,z ∈ [-80, 80]。
布局关于 z=0 镜像对称，保证两队公平。校验内容: 建筑不重叠、出生点在场内且不在墙里、
双方出生点地面连通、封住主干道/外侧街道后仍有绕行路线（多条侧翼）。"""
import math, itertools

K_GROUND, K_BUILDING, K_PANEL, K_COVER, K_TUNNEL = 0, 1, 2, 3, 4
boxes = []     # [cx,cy,cz, sx,sy,sz, rx,ry,rz, kind]
neon = []      # [cx,cy,cz, sx,sy,sz, color]  0=ice 1=orange
screens = []   # [x,y,z, w,h, yaw_deg, style]
lights = []    # [x,y,z, color, range]
zips = []      # [ax,ay,az, bx,by,bz]
pois = []      # [x,y,z]
spawns = {0: [], 1: []}   # team -> [x,z,yaw_rad]

def r(v): return round(v, 3)

def B(x0, x1, z0, z1, y0, y1, kind):
    za, zb = min(z0, z1), max(z0, z1)
    boxes.append([r((x0+x1)/2), r((y0+y1)/2), r((za+zb)/2), r(x1-x0), r(y1-y0), r(zb-za), 0, 0, 0, kind])

def ramp_x(x0, y0, x1, y1, z0, z1, kind=K_PANEL, t=0.5):
    dx, dy = x1-x0, y1-y0
    L = math.hypot(dx, dy); th = math.atan(dy/dx)
    nx, ny = -math.sin(th), math.cos(th)
    mx, my = (x0+x1)/2, (y0+y1)/2
    boxes.append([r(mx-nx*t/2), r(my-ny*t/2), r((z0+z1)/2), r(L), t, r(abs(z1-z0)), 0, 0, r(math.degrees(th)), kind])

def ramp_z(z0, y0, z1, y1, x0, x1, kind=K_PANEL, t=0.5):
    dz, dy = z1-z0, y1-y0
    L = math.hypot(dz, dy); th = math.atan(-dy/dz)
    ny, nz = math.cos(th), math.sin(th)
    mz, my = (z0+z1)/2, (y0+y1)/2
    boxes.append([r((x0+x1)/2), r(my-ny*t/2), r(mz-nz*t/2), r(abs(x1-x0)), t, r(L), r(math.degrees(th)), 0, 0, kind])

# ---------------- 中央（不镜像）----------------
B(-80, 80, -80, -6, -6, 0, K_GROUND)                  # 北半区地面
B(-80, 80, 6, 80, -6, 0, K_GROUND)                    # 南半区地面
B(-80, -50, -6, 6, -6, 0, K_GROUND)                   # 外侧通道地面
B(50, 80, -6, 6, -6, 0, K_GROUND)
B(-50, 50, -6, 6, -6, -5, K_TUNNEL)                   # 地下通道底板
B(-22, 22, -6, 6, -1, 0, K_TUNNEL)                    # 通道顶板（上方即地面）
ramp_x(31, -5, 50, 0, -6, 6, K_TUNNEL)                # 东侧坡道
ramp_x(-31, -5, -50, 0, -6, 6, K_TUNNEL)              # 西侧坡道
B(-3, 3, -3, 3, 0, 1.4, K_COVER)                      # 中央矮台（通道顶板上）
# 周界墙
B(-82, -80, -82, 82, 0, 30, K_BUILDING); B(80, 82, -82, 82, 0, 30, K_BUILDING)
B(-82, 82, -82, -80, 0, 30, K_BUILDING); B(-82, 82, 80, 82, 0, 30, K_BUILDING)
# 沟槽里的掩体
for (x, z) in [(-36, -2), (-36, 2), (40, -2), (40, 2)]:
    B(x-1, x+1, z-1, z+1, -5, -3.4, K_COVER)
neon += [[0, -1.15, -5.6, 44, 0.15, 0.2, 0], [0, -1.15, 5.6, 44, 0.15, 0.2, 0]]
lights += [[0, -2.2, 0, 0, 20], [-36, -3, 0, 1, 14], [36, -3, 0, 1, 14]]
pois += [[0, -5, 0], [-36, -5, 0], [36, -5, 0]]

# ---------------- 北半区，按 m 镜像到南半区 ----------------
def half(m):
    def Z(a, b): return (a*m, b*m)
    def box(x0, x1, z0, z1, y0, y1, kind):
        a, b = Z(z0, z1); B(x0, x1, a, b, y0, y1, kind)
    # 建筑
    box(-60, -32, -50, -16, 0, 34, K_BUILDING)       # 西塔楼（高墙面，适合蹬墙跑）
    box(32, 60, -50, -16, 0, 26, K_BUILDING)         # 东塔楼
    box(-24, -10, -50, -16, 0, 10, K_BUILDING)       # 主干道西侧低层
    box(10, 24, -50, -16, 0, 10, K_BUILDING)         # 主干道东侧低层
    # 通往低层屋顶的坡道 + 平台，以及跨越主干道的天桥
    for sx in (-1, 1):
        xa, xb = (-28, -24) if sx < 0 else (24, 28)
        ramp_z(-16*m, 0, -34*m, 10, xa, xb)
        box(xa, xb, -38, -34, 9.5, 10, K_PANEL)
    box(-10, 10, -36, -32, 9.5, 10, K_PANEL)         # 天桥
    # 外侧街道的集装箱/墙
    for (x, z, w, d, h) in [(-68, -30, 2.4, 6, 2.6), (-72, -44, 6, 2.4, 2.6), (-66, -22, 4, 2, 1.4),
                            (68, -34, 2.4, 6, 2.6), (64, -24, 4, 2, 1.4), (72, -46, 6, 2.4, 2.6)]:
        box(x-w/2, x+w/2, z-d/2, z+d/2, 0, h, K_COVER)
    box(-64.3, -63.7, -40, -26, 0, 8, K_PANEL)       # 蹬墙跑独立墙
    box(63.7, 64.3, -40, -26, 0, 8, K_PANEL)
    # 主干道掩体与广告柱
    for (x, z) in [(-6, -24), (6, -28), (-4, -42), (4, -46)]:
        box(x-1.5, x+1.5, z-1, z+1, 0, 1.5, K_COVER)
    for (x, z) in [(-9, -20), (9, -20), (-9, -46), (9, -46)]:
        box(x-.5, x+.5, z-.5, z+.5, 0, 9, K_PANEL)
    # 小巷与前街掩体
    for (x, z) in [(-30, -44), (-30, -26), (30, -42), (30, -28)]:
        box(x-1, x+1, z-1, z+1, 0, 1.2, K_COVER)
    for (x, z, w) in [(-20, -54, 4), (20, -54, 4), (-40, -55, 4), (40, -55, 4), (0, -54, 3)]:
        box(x-w/2, x+w/2, z-.5, z+.5, 0, 1.3, K_COVER)
    # 中央十字路口掩体与立柱
    for (x, z, w, d) in [(-14, -11, 4, 2), (14, -11, 4, 2), (-26, -11, 3, 2), (26, -11, 3, 2)]:
        box(x-w/2, x+w/2, z-d/2, z+d/2, 0, 1.4, K_COVER)
    for (x, z) in [(-12, -12), (12, -12)]:
        box(x-.75, x+.75, z-.75, z+.75, 0, 6, K_PANEL)
    # 出生庭院: 前墙(留两个正门+中间挡视线的墙)、侧墙(留侧门)
    box(-30, -14, -61, -59, 0, 7, K_BUILDING); box(-6, 6, -61, -59, 0, 8, K_BUILDING); box(14, 30, -61, -59, 0, 7, K_BUILDING)
    for sx in (-1, 1):
        xa, xb = (29, 31) if sx > 0 else (-31, -29)
        box(xa, xb, -80, -72, 0, 7, K_BUILDING); box(xa, xb, -64, -61, 0, 7, K_BUILDING)
    for x in (-10, 10):
        box(x-1, x+1, -71, -69, 0, 1.2, K_COVER)
    # 出生点（面朝对面）
    team = 0 if m == 1 else 1
    yaw = math.pi if m == 1 else 0.0
    for (x, z) in [(-18, -74), (-12, -70), (-6, -76), (0, -72), (6, -76), (12, -70), (18, -74), (0, -66)]:
        spawns[team].append([x, z*m, r(yaw)])
    # 霓虹条 / 广告屏 / 灯 / 滑索 / 兴趣点
    c = 0 if m == 1 else 1
    for (x, face) in [(-31.9, 1), (31.9, -1), (-9.9, -1), (9.9, 1)]:
        pass
    neon.extend([[-31.9, 6, -33*m, 0.1, 0.3, 30, 0], [-31.9, 12, -33*m, 0.1, 0.3, 30, 1],
                 [31.9, 6, -33*m, 0.1, 0.3, 30, 1], [31.9, 12, -33*m, 0.1, 0.3, 30, 0],
                 [-9.9, 5, -33*m, 0.1, 0.25, 30, 0], [9.9, 5, -33*m, 0.1, 0.25, 30, 1],
                 [-14, 7.9, -60*m, 16, 0.2, 0.2, c], [14, 7.9, -60*m, 16, 0.2, 0.2, c]])
    screens.extend([[-31.85, 14, -33*m, 14, 8, 90, 0], [31.85, 12, -33*m, 14, 8, -90, 1],
                    [-9.85, 6, -26*m, 10, 5, 90, 2], [9.85, 6, -42*m, 10, 5, -90, 0]])
    lights.extend([[0, 8, -30*m, 0, 24], [0, 8, -10*m, 1, 22], [-28, 6, -30*m, 0, 14], [28, 6, -30*m, 1, 14], [0, 6, -54*m, c, 18]])
    for sx in (-1, 1):
        zips.append([17*sx, 12.0, -17.5*m, 17*sx, 3.6, -4*m])
    pois.extend([[-17, 10, -44*m], [17, 10, -44*m], [0, 10, -34*m], [0, 0, -24*m], [0, 0, -42*m], [0, 0, -12*m],
                 [-28, 0, -44*m], [28, 0, -44*m], [-68, 0, -36*m], [68, 0, -40*m], [-68, 0, -20*m], [68, 0, -20*m],
                 [-30, 0, -55*m], [30, 0, -55*m], [0, 0, -55*m], [-14, 0, -9*m], [14, 0, -9*m]])

half(1); half(-1)

# ---------------- 校验 ----------------
def aabb(b):
    cx, cy, cz, sx, sy, sz = b[:6]
    return (cx-sx/2, cx+sx/2, cy-sy/2, cy+sy/2, cz-sz/2, cz+sz/2)

solid = [b for b in boxes if b[6] == 0 and b[7] == 0 and b[8] == 0 and b[9] == K_BUILDING and aabb(b)[3] > 5
         and abs(b[0]) < 80 and abs(b[2]) < 80]      # 周界墙在场外，不参与检查
for a, b in itertools.combinations(solid, 2):
    A, Bb = aabb(a), aabb(b)
    ov = A[0] < Bb[1] and Bb[0] < A[1] and A[4] < Bb[5] and Bb[4] < A[5]
    # 周界墙与其它不算重叠检查（周界在场外）
    assert not ov, f"建筑重叠: {a} {b}"

# 2D 栅格连通（地面层，1 米网格，墙/高于 2.4 的实体挡路；沟槽/坡道视为可通行）
N = 164
def idx(x, z): return int(round(x+82)), int(round(z+82))
blocked = [[False]*N for _ in range(N)]
for b in boxes:
    x0, x1, y0, y1, z0, z1 = aabb(b)
    if b[6] or b[7] or b[8]: continue
    if b[9] in (K_GROUND, K_TUNNEL, K_PANEL): continue
    if y0 < 0.5 and y1 > 2.4 or (b[9] == K_COVER and y1 - y0 > 1.0 and y0 < 0.5):
        for xi in range(int(x0)+82, int(x1)+82+1):
            for zi in range(int(z0)+82, int(z1)+82+1):
                if 0 <= xi < N and 0 <= zi < N: blocked[xi][zi] = True
for k in range(N):  # 周界
    blocked[0][k] = blocked[1][k] = blocked[N-1][k] = blocked[N-2][k] = True
    blocked[k][0] = blocked[k][1] = blocked[k][N-1] = blocked[k][N-2] = True

def reach(extra_block=lambda x, z: False):
    sx, sz = idx(0, -66); tx, tz = idx(0, 66)
    seen = {(sx, sz)}; q = [(sx, sz)]
    while q:
        x, z = q.pop()
        for dx, dz in ((1,0),(-1,0),(0,1),(0,-1)):
            nx, nz = x+dx, z+dz
            if (nx, nz) in seen or not (0 <= nx < N and 0 <= nz < N): continue
            if blocked[nx][nz] or extra_block(nx-82, nz-82): continue
            seen.add((nx, nz)); q.append((nx, nz))
    return (tx, tz) in seen

assert reach(), "双方出生点不连通"
assert reach(lambda x, z: abs(x) <= 10 and abs(z) <= 56), "封住主干道后无法绕行"
assert reach(lambda x, z: abs(x) <= 36 and abs(z) <= 56), "封住中路与小巷后外侧街道不通"
assert reach(lambda x, z: -14 <= z <= 14 and abs(x) <= 36), "封住中央十字路口后无法绕行"
for t in (0, 1):
    for x, z, yaw in spawns[t]:
        xi, zi = idx(x, z)
        assert not blocked[xi][zi], f"出生点在墙里: {x},{z}"
        assert abs(x) < 78 and abs(z) < 78
# 对称性: 北半区每个盒子在南半区有镜像
def key(b): return (r(b[0]), r(abs(b[2]) if b[2] else 0), r(b[3]), r(b[4]), r(b[5]), b[9])
north = sorted(key(b) for b in boxes if b[2] < -0.01); south = sorted(key(b) for b in boxes if b[2] > 0.01)
assert north == south, "布局不对称"
print("OK  boxes=%d neon=%d screens=%d lights=%d zips=%d pois=%d spawns=%d/%d" % (
    len(boxes), len(neon), len(screens), len(lights), len(zips), len(pois), len(spawns[0]), len(spawns[1])))

# ---------------- 输出 GDScript ----------------
def arr(rows):
    return "[\n" + "".join("    " + str([ (x if isinstance(x, int) else float(x)) for x in row]) + ",\n" for row in rows) + "]"
with open("gameplay/maps/neon_layout.gd", "w") as fh:
    fh.write("class_name NeonLayout\nextends RefCounted\n## 由 tools/gen_neon_district.py 生成，请勿手改。改布局请改生成器后重新运行。\n")
    fh.write("## BOXES: [cx,cy,cz, sx,sy,sz, rx,ry,rz(度), kind]  kind: 0 地面 1 建筑 2 面板 3 掩体(金属) 4 通道\n\n")
    fh.write("const BOXES := " + arr(boxes) + "\n\n")
    fh.write("## NEON: [cx,cy,cz, sx,sy,sz, color]  color 0=冰蓝 1=橙\nconst NEON := " + arr(neon) + "\n\n")
    fh.write("## SCREENS: [x,y,z, 宽,高, 朝向yaw(度), 样式]\nconst SCREENS := " + arr(screens) + "\n\n")
    fh.write("## LIGHTS: [x,y,z, color, range]\nconst LIGHTS := " + arr(lights) + "\n\n")
    fh.write("## ZIPLINES: [ax,ay,az, bx,by,bz]\nconst ZIPLINES := " + arr(zips) + "\n\n")
    fh.write("## POIS: 机器人巡逻兴趣点 [x,y,z]\nconst POIS := " + arr(pois) + "\n\n")
    fh.write("## 出生点 [x, z, yaw(弧度)]\nconst SPAWNS_A := " + arr(spawns[0]) + "\n\nconst SPAWNS_B := " + arr(spawns[1]) + "\n")
