class_name NetWorld
extends Node
## 联网层（Phase 5）: 服务器权威 + 客户端预测/服务器校正 + 远端插值 + 延迟补偿 + 断线重连。
##
## 拓扑: 一个专用服务器进程 = 一场 6V6 团队死斗（真人替换机器人，空位由机器人补齐）。
##   godot --headless --path . -- --server --port=7777 [--difficulty=1]
## 客户端在大厅选「联机对战」输入地址加入。
##
## 数据流:
##   客户端每个物理帧 → rpc_input(最近 3 帧输入，冗余防丢包) → 服务器按序号消费，驱动该玩家的服务器替身(Player, net_ctl)
##   服务器每 3 个物理帧(20Hz) → rpc_snapshot(服务器时间, 已确认输入序号, 所有单位状态) → 客户端
##   客户端: 本机玩家 = 预测；收到确认状态后对比，误差大就回滚到服务器状态并重放未确认输入；
##           其他单位 = 放进缓冲，按 (服务器时间 - 100ms) 插值显示
##   射击: 服务器用替身自己的武器逻辑判定；判定前把其他单位倒回到射手"看到"的时刻（延迟补偿，最多 250ms）
##   事件(击杀播报/比分/阶段/受击/死亡/命中确认): 服务器可靠 RPC → 客户端再 emit 到 EventBus，UI 不用改
##
## 基础反作弊: 伤害/位置/弹药全部服务器说了算；输入帧校验(有限数、范围、转向速率)；
##   每秒包数限制；非法武器/配件被丢弃；超限踢出。
## 重要限制见 ARCHITECTURE.md（没有真正的匹配服务/好友组队/加密；未在真实网络环境验证）。

const DEFAULT_PORT := 7777
const MAX_CLIENTS := 12
const SNAP_EVERY := 3
const INTERP_DELAY := 0.1
const RECONNECT_GRACE := 30.0
const MAX_REWIND := 0.25
const STRIDE := 13
const MAX_YAW_STEP := 2.0
const EDGE_MASK := 1 | 2 | 16 | 32 | 64 | 128 | 256 | 512
const CLIENT_EVENTS := ["kill_feed", "match_score", "match_time", "match_phase", "streak_banner", "match_ended",
    "player_damaged", "player_died", "respawn_timer", "hit_confirmed"]

signal status(text: String)
signal welcomed(my_id: int, team: int)
signal failed(reason: String)

var role_server := false
var map: Node
var mode: Node
var address := "127.0.0.1"
var port := DEFAULT_PORT
var player_name := "PLAYER"
var token := ""

# ---- 服务器 ----
var _sessions: Dictionary = {}      # peer_id -> session
var _tokens: Dictionary = {}        # token -> session
var _entities: Dictionary = {}      # net_id -> Node3D
var _hist: Dictionary = {}          # net_id -> [[t, pos], ...]
var _next_id := 1
var _tick := 0
var _lc_saved: Dictionary = {}

# ---- 客户端 ----
var _my_id := -1
var _local: Player
var _remote: Dictionary = {}
var _seq := 0
var _hist_c: Array = []
var _recent: Array = []
var _clock_off := 0.0
var _clock_init := false
var _ping_acc := 0.0
var _connected := false
var _tries := 0
var _last_hp := -1
var _signals_bound := false


func _now() -> float:
    return Time.get_ticks_msec() / 1000.0


# =====================================================================
#  服务器
# =====================================================================
func start_server(p: int) -> bool:
    role_server = true
    port = p
    process_physics_priority = -100       # 先于玩家替身执行: 先喂输入，再让替身模拟
    var peer := ENetMultiplayerPeer.new()
    var err := peer.create_server(port, MAX_CLIENTS)
    if err != OK:
        push_error("服务器启动失败 (端口 %d): %d" % [port, err])
        return false
    multiplayer.multiplayer_peer = peer
    multiplayer.peer_connected.connect(_on_peer_connected)
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    EventBus.kill_feed.connect(_fwd_kill_feed)
    EventBus.match_score.connect(_fwd_match_score)
    EventBus.match_time.connect(_fwd_match_time)
    EventBus.match_phase.connect(_fwd_match_phase)
    EventBus.match_ended.connect(_fwd_match_ended)
    print("[NET] server listening on :%d" % port)
    return true


func _fwd_kill_feed(a: String, b: String, c: String, d: bool, e: int, f: int) -> void:
    _broadcast("kill_feed", [a, b, c, d, e, f])


func _fwd_match_score(a: int, b: int, c: int) -> void:
    _broadcast("match_score", [a, b, c])


func _fwd_match_time(a: float) -> void:
    _broadcast("match_time", [a])


func _fwd_match_phase(a: String, b: float) -> void:
    _broadcast("match_phase", [a, b])


func _fwd_match_ended(a: int, b: Array) -> void:
    _broadcast("match_ended", [a, b])


func _broadcast(ev: String, args: Array) -> void:
    for pid in _sessions.keys():
        var s: Dictionary = _sessions[pid]
        if float(s["disc_at"]) < 0.0:
            rpc_id(int(pid), "rpc_event", ev, args)


func _on_peer_connected(pid: int) -> void:
    print("[NET] peer connected: %d" % pid)


func _on_peer_disconnected(pid: int) -> void:
    if _sessions.has(pid):
        var s: Dictionary = _sessions[pid]
        s["disc_at"] = _now()                 # 保留替身 30 秒，等待同一令牌重连
        print("[NET] peer %d disconnected, holding slot %.0fs" % [pid, RECONNECT_GRACE])


func _kick(pid: int, reason: String) -> void:
    print("[NET] kick %d: %s" % [pid, reason])
    rpc_id(pid, "rpc_kicked", reason)
    if multiplayer.multiplayer_peer != null:
        multiplayer.multiplayer_peer.disconnect_peer(pid)


func register_entity(node: Node3D) -> int:
    var id := _next_id
    _next_id += 1
    node.set_meta("net_id", id)
    _entities[id] = node
    _hist[id] = []
    var info := _ent_info(id, node)
    for pid in _sessions.keys():
        rpc_id(int(pid), "rpc_ent_add", info)
    return id


func unregister_entity(node: Node) -> void:
    var id := int(node.get_meta("net_id", -1))
    if id < 0:
        return
    _entities.erase(id)
    _hist.erase(id)
    for pid in _sessions.keys():
        rpc_id(int(pid), "rpc_ent_remove", id)


func _ent_info(id: int, node: Node) -> Dictionary:
    var wid := ""
    if node is Player and (node as Player).weapon != null and (node as Player).weapon.data != null:
        wid = (node as Player).weapon.data.id
    elif node is Bot and (node as Bot).data != null:
        wid = (node as Bot).data.id
    return {"id": id, "kind": "player" if node is Player else "bot",
        "team": int(node.get("team")), "name": String(node.get("display_name")), "weapon": wid}


func _pick_team() -> int:
    var humans := [0, 0]
    for s in _sessions.values():
        humans[int(s["team"])] += 1
    if humans[0] != humans[1]:
        return 0 if humans[0] < humans[1] else 1
    var total := [0, 0]
    for p in mode.players:
        total[int(p.get("team"))] += 1
    return 0 if total[0] <= total[1] else 1


func _replace_bot(team: int) -> void:
    for p in mode.players:
        if p is Bot and int((p as Bot).team) == team:
            mode.call("remove_combatant", p)
            unregister_entity(p)
            (p as Bot).queue_free()
            return


func _sanitize_attachments(raw: Variant, ids: Array) -> Dictionary:
    var allowed := {}
    for aid in WeaponCatalog.ATTACHMENT_IDS:
        allowed[WeaponCatalog.attachment_path(aid)] = true
    var out := {}
    if not (raw is Dictionary):
        return out
    for wid in (raw as Dictionary).keys():
        if not ids.has(String(wid)) or not ((raw as Dictionary)[wid] is Dictionary):
            continue
        var m := {}
        for k in ((raw as Dictionary)[wid] as Dictionary).keys():
            var slot := int(k)
            var path := String(((raw as Dictionary)[wid] as Dictionary)[k])
            if slot >= 0 and slot <= 6 and (path == "" or allowed.has(path)):
                m[slot] = path
        out[String(wid)] = m
    return out


@rpc("any_peer", "call_remote", "reliable")
func rpc_join(info: Dictionary) -> void:
    if not role_server:
        return
    var pid := multiplayer.get_remote_sender_id()
    var tk := String(info.get("token", ""))
    if tk != "" and _tokens.has(tk):                     # 断线重连
        var old: Dictionary = _tokens[tk]
        _sessions.erase(int(old["peer"]))
        old["peer"] = pid
        old["disc_at"] = -1.0
        old["queue"] = {}
        _sessions[pid] = old
        _send_welcome(pid, old)
        print("[NET] peer %d reconnected with token" % pid)
        return
    if _sessions.size() >= MAX_CLIENTS:
        _kick(pid, "server full")
        return
    var pname := String(info.get("name", "PLAYER")).strip_edges().substr(0, 16)
    if pname == "":
        pname = "PLAYER"
    var pri := String(info.get("primary", "vx1_rifle"))
    var sec := String(info.get("secondary", "px1_pistol"))
    if not WeaponCatalog.WEAPON_IDS.has(pri):
        pri = "vx1_rifle"
    if not WeaponCatalog.WEAPON_IDS.has(sec):
        sec = "px1_pistol"

    var av := Player.new()
    av.net_role = "server"
    av.net_ctl = true
    av.loadout.append(WeaponCatalog.load_weapon(pri))
    av.loadout.append(WeaponCatalog.load_weapon(sec))
    av.attach_override = _sanitize_attachments(info.get("atts", {}), [pri, sec])
    var s := {"peer": pid, "token": "%08x%08x" % [randi(), randi()], "avatar": av, "name": pname,
        "team": 0, "queue": {}, "last_seq": 0, "acked": 0, "repeat": [], "yaw": 0.0,
        "win_t": _now(), "win_n": 0, "disc_at": -1.0, "net_id": 0}
    av.net_notify = Callable(self, "_notify_session").bind(s)
    av.lagcomp_begin = Callable(self, "_lc_begin").bind(av)
    av.lagcomp_end = Callable(self, "_lc_end")
    map.add_child(av)
    var team := _pick_team()
    s["team"] = team
    _replace_bot(team)
    mode.call("add_late", av, team, pname)
    s["net_id"] = register_entity(av)          # 此时 _sessions 里还没有新玩家，所以不会给自己发 ent_add
    _sessions[pid] = s
    _tokens[String(s["token"])] = s
    _send_welcome(pid, s)
    print("[NET] %s joined as team %d (peer %d)" % [pname, team, pid])


func _send_welcome(pid: int, s: Dictionary) -> void:
    var ents: Array = []
    for id in _entities.keys():
        if is_instance_valid(_entities[id]):
            ents.append(_ent_info(int(id), _entities[id]))
    var av: Player = s["avatar"]
    rpc_id(pid, "rpc_welcome", int(s["net_id"]), int(s["team"]), ents, _now(), String(s["token"]),
        av.global_position, av.yaw)


func _notify_session(sig: String, args: Array, s: Dictionary) -> void:
    if float(s["disc_at"]) >= 0.0:
        return
    var pid := int(s["peer"])
    match sig:
        "player_health":
            return                          # 血量由快照驱动
        "respawn":
            rpc_id(pid, "rpc_respawn", args[0], args[1])
        _:
            if CLIENT_EVENTS.has(sig):
                rpc_id(pid, "rpc_event", sig, args)


@rpc("any_peer", "call_remote", "unreliable_ordered")
func rpc_input(packed: PackedFloat64Array) -> void:
    if not role_server:
        return
    var pid := multiplayer.get_remote_sender_id()
    if not _sessions.has(pid):
        return
    var s: Dictionary = _sessions[pid]
    var now := _now()
    if now - float(s["win_t"]) > 1.0:
        s["win_t"] = now
        s["win_n"] = 0
    s["win_n"] = int(s["win_n"]) + 1
    if int(s["win_n"]) > 150:                # 正常是 60/秒
        _kick(pid, "packet flood")
        return
    if packed.size() == 0 or packed.size() % 7 != 0 or packed.size() > 7 * 4:
        return
    var q: Dictionary = s["queue"]
    for i in range(0, packed.size(), 7):
        var f: Array = []
        var ok := true
        for k in 7:
            var v := packed[i + k]
            if is_nan(v) or is_inf(v):
                ok = false
            f.append(v)
        if not ok:
            continue
        var seq := int(f[0])
        if seq <= int(s["last_seq"]) or q.has(seq):
            continue
        f[1] = clampf(float(f[1]), -1.0, 1.0)
        f[2] = clampf(float(f[2]), -1.0, 1.0)
        var prev_yaw := float(s["yaw"])
        var dy := angle_difference(prev_yaw, float(f[3]))
        if absf(dy) > MAX_YAW_STEP:                     # 转向速率上限，防瞬转外挂
            f[3] = prev_yaw + signf(dy) * MAX_YAW_STEP
        s["yaw"] = float(f[3])
        f[4] = clampf(float(f[4]), -1.5359, 1.5359)
        f[5] = int(f[5]) & 4095
        q[seq] = f


func _next_frame(s: Dictionary) -> Array:
    var q: Dictionary = s["queue"]
    while q.size() > 6:                       # 积压太多就丢最老的，保持低延迟（客户端会被校正）
        var ks := q.keys()
        ks.sort()
        q.erase(ks[0])
    if q.is_empty():
        var r: Array = (s["repeat"] as Array).duplicate()
        if r.size() >= 7:
            r[5] = int(r[5]) & ~EDGE_MASK     # 重复帧不重复触发"按下"类动作
        return r
    var keys := q.keys()
    keys.sort()
    var seq: int = keys[0]
    var f: Array = q[seq]
    q.erase(seq)
    s["last_seq"] = seq
    s["repeat"] = f
    return f


func _server_tick(_delta: float) -> void:
    _tick += 1
    var t := _now()
    for pid in _sessions.keys():
        var s: Dictionary = _sessions[pid]
        var av = s["avatar"]
        if not is_instance_valid(av):
            continue
        s["acked"] = s["last_seq"]          # 快照里的状态 = 上一帧处理完的结果
        if float(s["disc_at"]) >= 0.0:
            av.apply_net_frame([])
            if t - float(s["disc_at"]) > RECONNECT_GRACE:
                _drop_session(int(pid))
            continue
        av.apply_net_frame(_next_frame(s))
    for id in _entities.keys():
        var n = _entities[id]
        if not is_instance_valid(n):
            continue
        var h: Array = _hist[id]
        h.append([t, n.global_position])
        while h.size() > 0 and t - float(h[0][0]) > 1.2:
            h.pop_front()
    if _tick % SNAP_EVERY == 0:
        _send_snapshots(t)


func _drop_session(pid: int) -> void:
    var s: Dictionary = _sessions[pid]
    var av = s["avatar"]
    var team := int(s["team"])
    if is_instance_valid(av):
        mode.call("remove_combatant", av)
        unregister_entity(av)
        av.queue_free()
    _sessions.erase(pid)
    _tokens.erase(String(s["token"]))
    var bot: Node = map.call("net_add_bot", team)       # 空位由机器人补上
    if bot != null:
        register_entity(bot)
    print("[NET] session %d dropped, replaced by bot" % pid)


func _pack_entities() -> PackedFloat64Array:
    var out := PackedFloat64Array()
    for id in _entities.keys():
        var n = _entities[id]
        if not is_instance_valid(n):
            continue
        var yaw: float = n.rotation.y
        var pitch := 0.0
        var st := 0
        if n is Player:
            yaw = (n as Player).yaw
            pitch = (n as Player).pitch
            st = int((n as Player).state)
        elif n is Bot:
            pitch = (n as Bot).net_pitch()
        var vel: Vector3 = (n as CharacterBody3D).velocity
        out.append_array(PackedFloat64Array([
            id, n.global_position.x, n.global_position.y, n.global_position.z, yaw, pitch,
            vel.x, vel.y, vel.z, st, float(n.get("health")), 1.0 if bool(n.get("alive")) else 0.0, float(n.get("team"))]))
    return out


func _send_snapshots(t: float) -> void:
    var data := _pack_entities()
    for pid in _sessions.keys():
        var s: Dictionary = _sessions[pid]
        if float(s["disc_at"]) < 0.0:
            rpc_id(int(pid), "rpc_snapshot", t, int(s["acked"]), data)


@rpc("any_peer", "call_remote", "unreliable")
func rpc_ping(t: float) -> void:
    if role_server:
        rpc_id(multiplayer.get_remote_sender_id(), "rpc_pong", t)


# ---- 延迟补偿: 把其他单位倒回到射手看到的时刻 ----
func _sample_hist(id: int, t: float) -> Variant:
    var h: Array = _hist.get(id, [])
    if h.size() == 0:
        return null
    if t <= float(h[0][0]):
        return h[0][1]
    for i in range(h.size() - 1, 0, -1):
        if float(h[i - 1][0]) <= t:
            var a: Array = h[i - 1]
            var b: Array = h[i]
            var k := clampf((t - float(a[0])) / maxf(float(b[0]) - float(a[0]), 0.0001), 0.0, 1.0)
            return (a[1] as Vector3).lerp(b[1], k)
    return h[h.size() - 1][1]


func _lc_begin(av: Player) -> void:
    _lc_saved.clear()
    var now := _now()
    var t := clampf(av.net_render_time, now - MAX_REWIND, now)
    for id in _entities.keys():
        var n = _entities[id]
        if not is_instance_valid(n) or n == av:
            continue
        var p: Variant = _sample_hist(int(id), t)
        if p == null:
            continue
        _lc_saved[id] = n.global_position
        n.global_position = p
        _force_update(n)


func _lc_end() -> void:
    for id in _lc_saved.keys():
        var n = _entities.get(id)
        if is_instance_valid(n):
            n.global_position = _lc_saved[id]
            _force_update(n)
    _lc_saved.clear()


func _force_update(n: Node3D) -> void:
    n.force_update_transform()          # 物理形体的位置更新默认是延后的，这里强制立即生效
    var zones: Variant = n.get("_zones")
    if zones is Array:
        for z in zones:
            if is_instance_valid(z):
                (z as Node3D).force_update_transform()


# =====================================================================
#  客户端
# =====================================================================
func connect_to(addr: String, p: int) -> void:
    role_server = false
    address = addr
    port = p
    process_physics_priority = 100        # 晚于本机玩家: 读取本帧输入与结果
    _tries = 0
    _open_client()


func _open_client() -> void:
    var peer := ENetMultiplayerPeer.new()
    var err := peer.create_client(address, port)
    if err != OK:
        failed.emit("无法创建连接 (%d)" % err)
        return
    multiplayer.multiplayer_peer = peer
    if not _signals_bound:
        _signals_bound = true
        multiplayer.connected_to_server.connect(_on_connected)
        multiplayer.connection_failed.connect(_on_conn_failed)
        multiplayer.server_disconnected.connect(_on_server_lost)
    status.emit("正在连接 %s:%d …" % [address, port])


func _on_connected() -> void:
    _connected = true
    _tries = 0
    var info := {"name": player_name, "token": token, "primary": Loadout.primary,
        "secondary": Loadout.secondary, "atts": Loadout.export_for_join()}
    rpc_id(1, "rpc_join", info)
    status.emit("已连接，正在加入对局…")


func _on_conn_failed() -> void:
    _connected = false
    _schedule_reconnect("连接失败")


func _on_server_lost() -> void:
    _connected = false
    _schedule_reconnect("连接断开")


func _schedule_reconnect(reason: String) -> void:
    _tries += 1
    if _tries > 10:
        failed.emit("%s，重连失败" % reason)
        return
    status.emit("%s，正在重连 (%d/10)…" % [reason, _tries])
    get_tree().create_timer(2.0).timeout.connect(_reopen)


func _reopen() -> void:
    multiplayer.multiplayer_peer = null
    _open_client()


@rpc("authority", "call_remote", "reliable")
func rpc_welcome(my_id: int, team: int, ents: Array, server_time: float, tk: String, spawn_pos: Vector3, spawn_yaw: float) -> void:
    if role_server:
        return
    token = tk
    _my_id = my_id
    _clock_off = server_time - _now()
    _clock_init = true
    for ra in _remote.values():
        if is_instance_valid(ra):
            ra.queue_free()
    _remote.clear()
    for info in ents:
        _add_remote(info)
    if _local == null:
        _local = map.call("net_spawn_local", my_id, team, player_name)
        _local.respawn_at(Transform3D(Basis(Vector3.UP, spawn_yaw), spawn_pos), 0.0)
    _hist_c.clear()
    _recent.clear()
    status.emit("")
    welcomed.emit(my_id, team)


func _add_remote(info: Dictionary) -> void:
    var id := int(info["id"])
    if id == _my_id or _remote.has(id):
        return
    var ra := RemoteAvatar.new()
    ra.setup(info)
    add_child(ra)
    _remote[id] = ra


@rpc("authority", "call_remote", "reliable")
func rpc_ent_add(info: Dictionary) -> void:
    if not role_server:
        _add_remote(info)


@rpc("authority", "call_remote", "reliable")
func rpc_ent_remove(id: int) -> void:
    if role_server or not _remote.has(id):
        return
    (_remote[id] as Node).queue_free()
    _remote.erase(id)


@rpc("authority", "call_remote", "unreliable")
func rpc_snapshot(server_time: float, ack_seq: int, data: PackedFloat64Array) -> void:
    if role_server:
        return
    var off := server_time - _now()
    _clock_off = lerpf(_clock_off, off, 0.1) if _clock_init else off
    _clock_init = true
    for i in range(0, data.size() - STRIDE + 1, STRIDE):
        var id := int(data[i])
        var pos := Vector3(data[i + 1], data[i + 2], data[i + 3])
        var vel := Vector3(data[i + 6], data[i + 7], data[i + 8])
        var alive := data[i + 11] > 0.5
        if id == _my_id:
            _reconcile(ack_seq, pos, vel, data[i + 10], alive)
        elif _remote.has(id):
            (_remote[id] as RemoteAvatar).push(server_time, pos, data[i + 4], data[i + 5], vel, int(data[i + 9]), alive)


func _reconcile(ack: int, spos: Vector3, svel: Vector3, hp: float, alive: bool) -> void:
    if _local == null:
        return
    if int(hp) != _last_hp:
        _last_hp = int(hp)
        EventBus.player_health.emit(hp, 100.0)
    if not alive and _local.alive:
        _local.net_set_dead()
    while _hist_c.size() > 0 and int(_hist_c[0]["seq"]) < ack:
        _hist_c.pop_front()
    if _hist_c.is_empty() or int(_hist_c[0]["seq"]) != ack:
        return
    var h: Dictionary = _hist_c.pop_front()
    if (h["pos"] as Vector3).distance_to(spos) <= 0.12:
        return                                   # 预测准确，不用动
    _local.net_apply_state(spos, svel)           # 回滚到服务器状态，重放尚未确认的输入
    var dt := get_physics_process_delta_time()
    for e in _hist_c:
        _local.net_replay(e["frame"], dt)
        e["pos"] = _local.global_position
        e["vel"] = _local.velocity


@rpc("authority", "call_remote", "reliable")
func rpc_event(ev: String, args: Array) -> void:
    if role_server or not CLIENT_EVENTS.has(ev):
        return
    if ev == "match_ended" and args.size() >= 2:
        for r in (args[1] as Array):
            r["is_player"] = (String(r["name"]) == player_name)
    elif ev == "player_died" and _local != null:
        _local.net_set_dead()
    elif ev == "match_phase" and _local != null and args.size() >= 1:
        _local.controls_enabled = String(args[0]) == "LIVE" or String(args[0]) == "OVERTIME"
    EventBus.callv("emit_signal", [ev] + args)


@rpc("authority", "call_remote", "reliable")
func rpc_respawn(pos: Vector3, yaw: float) -> void:
    if role_server or _local == null:
        return
    _local.respawn_at(Transform3D(Basis(Vector3.UP, yaw), pos), 0.0)
    _hist_c.clear()
    _recent.clear()


@rpc("authority", "call_remote", "unreliable")
func rpc_pong(t: float) -> void:
    if not role_server:
        EventBus.net_stats.emit((_now() - t) * 1000.0)


@rpc("authority", "call_remote", "reliable")
func rpc_kicked(reason: String) -> void:
    if not role_server:
        failed.emit("被服务器断开: %s" % reason)


func _client_tick(delta: float) -> void:
    if _local == null or not _connected:
        return
    var f := _local.get_last_frame().duplicate()
    if f.size() < 7:
        return
    _seq += 1
    f[0] = _seq
    f[6] = _now() + _clock_off - INTERP_DELAY      # 我这一刻在屏幕上看到的"服务器时间"（延迟补偿用）
    _hist_c.append({"seq": _seq, "frame": f, "pos": _local.global_position, "vel": _local.velocity})
    if _hist_c.size() > 120:
        _hist_c.pop_front()
    _recent.append(f)
    if _recent.size() > 3:
        _recent.pop_front()
    var packed := PackedFloat64Array()
    for fr in _recent:
        packed.append_array(PackedFloat64Array(fr))
    rpc_id(1, "rpc_input", packed)
    _ping_acc += delta
    if _ping_acc >= 1.0:
        _ping_acc = 0.0
        rpc_id(1, "rpc_ping", _now())


func _process(_delta: float) -> void:
    if role_server or not _clock_init:
        return
    var rt := _now() + _clock_off - INTERP_DELAY
    for ra in _remote.values():
        if is_instance_valid(ra):
            (ra as RemoteAvatar).render(rt)


func _physics_process(delta: float) -> void:
    if role_server:
        _server_tick(delta)
    else:
        _client_tick(delta)
