class_name RemoteAvatar
extends Node3D
## 客户端上的"别人"（真人或服务器上的机器人）: 只有外观，没有碰撞/逻辑。
## 收到服务器快照后放进缓冲，按「当前服务器时间 - 100ms」做插值；缓冲不够时最多外推 0.15 秒。

const POSE_BY_STATE := ["move", "air", "slide", "wall_run", "mantle", "grapple", "zipline"]   # 下标 = Player.State
const TEAM_COLORS := [Color("7fd3ff"), Color("ff7a1a")]

var net_id := 0
var team := 0
var display_name := ""
var alive := true
var puppet: Puppet

var _buf: Array = []
var _weapon_id := ""


func setup(info: Dictionary) -> void:
    net_id = int(info.get("id", 0))
    team = int(info.get("team", 0))
    display_name = String(info.get("name", ""))
    _weapon_id = String(info.get("weapon", ""))


func _ready() -> void:
    puppet = Puppet.new()
    add_child(puppet)
    puppet.set_team_color(TEAM_COLORS[clampi(team, 0, 1)])
    var d := WeaponCatalog.load_weapon(_weapon_id)
    if d != null:
        puppet.set_weapon(d, WeaponStats.default_attachments(d))


func push(t: float, pos: Vector3, yaw: float, pitch: float, vel: Vector3, st: int, is_alive: bool) -> void:
    _buf.append({"t": t, "pos": pos, "yaw": yaw, "pitch": pitch, "vel": vel, "st": st})
    while _buf.size() > 40:
        _buf.pop_front()
    if is_alive != alive:
        alive = is_alive
        if alive:
            puppet.revive()
        else:
            puppet.pose = "idle"
            puppet.die()


func render(rt: float) -> void:
    if _buf.is_empty():
        return
    var a: Dictionary = _buf[0]
    var b: Dictionary = _buf[0]
    var pos: Vector3
    var yaw: float
    var pitch: float
    var vel: Vector3
    var st: int
    if rt <= float(_buf[0]["t"]):
        pos = a["pos"]; yaw = a["yaw"]; pitch = a["pitch"]; vel = a["vel"]; st = a["st"]
    elif rt >= float(_buf[_buf.size() - 1]["t"]):
        var last: Dictionary = _buf[_buf.size() - 1]
        var dt := minf(rt - float(last["t"]), 0.15)
        pos = (last["pos"] as Vector3) + (last["vel"] as Vector3) * dt
        yaw = last["yaw"]; pitch = last["pitch"]; vel = last["vel"]; st = last["st"]
    else:
        for i in range(_buf.size() - 1):
            if float(_buf[i]["t"]) <= rt and rt <= float(_buf[i + 1]["t"]):
                a = _buf[i]
                b = _buf[i + 1]
                break
        var span := maxf(float(b["t"]) - float(a["t"]), 0.0001)
        var k := clampf((rt - float(a["t"])) / span, 0.0, 1.0)
        pos = (a["pos"] as Vector3).lerp(b["pos"], k)
        yaw = lerp_angle(float(a["yaw"]), float(b["yaw"]), k)
        pitch = lerpf(float(a["pitch"]), float(b["pitch"]), k)
        vel = (a["vel"] as Vector3).lerp(b["vel"], k)
        st = int(a["st"])
    global_position = pos
    rotation.y = yaw
    if puppet == null:
        return
    var spd := Vector2(vel.x, vel.z).length()
    puppet.speed = spd
    puppet.vel_local = global_transform.basis.inverse() * vel
    puppet.aim_pitch = pitch
    if st <= 0:
        puppet.pose = "move" if spd > 0.5 else "idle"
    else:
        puppet.pose = POSE_BY_STATE[clampi(st, 0, POSE_BY_STATE.size() - 1)]
