class_name Operators
extends RefCounted
## 12 名原创干员的数据（定位: 突击/侦察/防御/支援/机动）。每人 1 被动 + 1 主动 + 1 终极。
## 被动 mods 键: move 移速倍率 · jump 跳跃倍率 · air_jumps 额外空中跳 · wallrun_speed/wallrun_time 蹬墙跑 ·
##   slide_boost 滑铲初速加成 · max_health 额外生命 · regen_delay 回血延迟(秒) · reload 换弹时间倍率 ·
##   ads_time 开镜时间倍率 · headshot 爆头倍率加成 · dmg_reduction 减伤
## 主动 type: dash boost scan shield heal smoke frag mine slow jumppad
## 终极 type: overdrive scan_all barrage fortress nova blackout
## 外观: 目前只有强调色不同（程序化角色）；独立外观/配音/技能特效需要美术资产。
## 联网: 技能目前只在单机/训练场生效，未做网络同步（见 ARCHITECTURE.md）。

const ROLES := ["突击", "侦察", "防御", "支援", "机动"]
const ULT_CHARGE_MAX := 100.0

const LIST := [
    {"id": "ghost", "name": "GHOST", "role": "机动", "color": "7fd3ff",
     "story": "前轨道伞兵，习惯在城市立面之间连续位移。",
     "passive": {"name": "贴墙惯性", "desc": "蹬墙跑速度 +25%，墙跑时间 +0.6 秒", "mods": {"wallrun_speed": 1.25, "wallrun_time": 0.6}},
     "active": {"name": "疾冲", "desc": "朝移动方向高速冲刺", "type": "dash", "cd": 8.0, "power": 15.0},
     "ult": {"name": "幽灵时刻", "desc": "8 秒内移速 +20%，跳跃 +15%", "type": "overdrive", "dur": 8.0, "move": 1.2, "jump": 1.15, "dmg": 1.0, "reload": 1.0}},
    {"id": "warden", "name": "WARDEN", "role": "防御", "color": "9fb4c8",
     "story": "前基地警卫队长，靠厚重装甲守住阵地。",
     "passive": {"name": "加固护甲", "desc": "最大生命 +20", "mods": {"max_health": 20.0}},
     "active": {"name": "偏转力场", "desc": "4 秒内受到的伤害 -60%", "type": "shield", "cd": 20.0, "reduction": 0.6, "dur": 4.0},
     "ult": {"name": "堡垒协议", "desc": "8 秒内减伤 80%，持续回血", "type": "fortress", "dur": 8.0, "reduction": 0.8, "regen": 15.0}},
    {"id": "rivet", "name": "RIVET", "role": "支援", "color": "8fd8a8",
     "story": "战地工程师，随身带着纳米修复剂。",
     "passive": {"name": "快速自愈", "desc": "脱战 2 秒后开始回血", "mods": {"regen_delay": 2.0}},
     "active": {"name": "修复脉冲", "desc": "3 秒内恢复 40 生命", "type": "heal", "cd": 18.0, "amount": 40.0, "dur": 3.0},
     "ult": {"name": "纳米风暴", "desc": "范围爆发: 对周围敌人造成伤害并为自己回血", "type": "nova", "radius": 10.0, "damage": 60.0, "heal": 60.0}},
    {"id": "specter", "name": "SPECTER", "role": "侦察", "color": "c9a6ff",
     "story": "情报部门的观察员，从不打无准备的仗。",
     "passive": {"name": "稳定呼吸", "desc": "开镜时间 -15%", "mods": {"ads_time": 0.85}},
     "active": {"name": "声呐脉冲", "desc": "4 秒内透视 40 米内的敌人（烟雾内除外）", "type": "scan", "cd": 16.0, "radius": 40.0, "dur": 4.0},
     "ult": {"name": "全域扫描", "desc": "8 秒内透视全场敌人，伤害 +15%", "type": "scan_all", "dur": 8.0, "dmg": 1.15}},
    {"id": "breaker", "name": "BREAKER", "role": "突击", "color": "ff9a5a",
     "story": "拆迁队出身，擅长近距离破局。",
     "passive": {"name": "熟练装填", "desc": "换弹时间 -15%", "mods": {"reload": 0.85}},
     "active": {"name": "破片手雷", "desc": "投出手雷，1.8 秒后爆炸", "type": "frag", "cd": 14.0, "damage": 90.0, "radius": 5.0},
     "ult": {"name": "饱和轰炸", "desc": "瞄准点附近连续落下 5 枚炸弹", "type": "barrage", "count": 5, "damage": 80.0, "radius": 5.0}},
    {"id": "veil", "name": "VEIL", "role": "侦察", "color": "b8c8e0",
     "story": "擅长制造混乱，让敌人看不见真相。",
     "passive": {"name": "精准要害", "desc": "爆头伤害倍率 +0.15", "mods": {"headshot": 0.15}},
     "active": {"name": "烟幕弹", "desc": "在准星处生成 8 秒烟幕，阻挡视线与扫描", "type": "smoke", "cd": 18.0, "radius": 6.0, "dur": 8.0},
     "ult": {"name": "全面熄灯", "desc": "大范围烟幕并减速其中的敌人", "type": "blackout", "radius": 14.0, "dur": 8.0, "factor": 0.6}},
    {"id": "trek", "name": "TREK", "role": "机动", "color": "ffd27a",
     "story": "攀岩运动员，空中永远有第二次机会。",
     "passive": {"name": "轻盈", "desc": "跳跃高度 +10%，多一段空中跳", "mods": {"jump": 1.1, "air_jumps": 1}},
     "active": {"name": "弹跳垫", "desc": "在脚下放置弹跳垫（15 秒）", "type": "jumppad", "cd": 12.0, "power": 16.0, "dur": 15.0},
     "ult": {"name": "极限冲刺", "desc": "7 秒内移速 +15%，跳跃 +20%", "type": "overdrive", "dur": 7.0, "move": 1.15, "jump": 1.2, "dmg": 1.0, "reload": 1.0}},
    {"id": "anvil", "name": "ANVIL", "role": "防御", "color": "7a8794",
     "story": "守门人，擅长布设陷阱。",
     "passive": {"name": "钢铁意志", "desc": "所有伤害 -10%", "mods": {"dmg_reduction": 0.1}},
     "active": {"name": "感应地雷", "desc": "放置地雷，敌人靠近时爆炸；可被射击摧毁", "type": "mine", "cd": 15.0, "damage": 100.0, "radius": 4.0},
     "ult": {"name": "不动如山", "desc": "7 秒内减伤 75%，持续回血", "type": "fortress", "dur": 7.0, "reduction": 0.75, "regen": 10.0}},
    {"id": "flux", "name": "FLUX", "role": "机动", "color": "ff7a1a",
     "story": "赛道出身的突击手，把速度当武器。",
     "passive": {"name": "惯性大师", "desc": "滑铲初速 +2", "mods": {"slide_boost": 2.0}},
     "active": {"name": "过载", "desc": "6 秒内移速 +25%", "type": "boost", "cd": 14.0, "mult": 1.25, "dur": 6.0},
     "ult": {"name": "弹幕风暴", "desc": "瞄准点附近连续落下 4 枚炸弹", "type": "barrage", "count": 4, "damage": 70.0, "radius": 6.0}},
    {"id": "halo", "name": "HALO", "role": "支援", "color": "a0e8ff",
     "story": "战地医师，永远站在最后一个倒下的人身边。",
     "passive": {"name": "战地医疗", "desc": "最大生命 +10，脱战 3 秒后回血", "mods": {"max_health": 10.0, "regen_delay": 3.0}},
     "active": {"name": "医疗注射", "desc": "4 秒内恢复 50 生命", "type": "heal", "cd": 20.0, "amount": 50.0, "dur": 4.0},
     "ult": {"name": "生命光环", "desc": "范围爆发: 伤害周围敌人并大幅回血", "type": "nova", "radius": 12.0, "damage": 50.0, "heal": 80.0}},
    {"id": "noctis", "name": "NOCTIS", "role": "侦察", "color": "6a7cff",
     "story": "夜战专家，追踪目标的最后一个脚印。",
     "passive": {"name": "轻步", "desc": "移速 +5%", "mods": {"move": 1.05}},
     "active": {"name": "红外探测", "desc": "6 秒内透视 30 米内的敌人", "type": "scan", "cd": 14.0, "radius": 30.0, "dur": 6.0},
     "ult": {"name": "夜视协议", "desc": "10 秒内透视全场敌人，伤害 +10%", "type": "scan_all", "dur": 10.0, "dmg": 1.1}},
    {"id": "cinder", "name": "CINDER", "role": "突击", "color": "ff5a3a",
     "story": "火线上的老兵，擅长压制与控场。",
     "passive": {"name": "灼热意志", "desc": "换弹时间 -10%，爆头伤害 +0.1", "mods": {"reload": 0.9, "headshot": 0.1}},
     "active": {"name": "迟滞力场", "desc": "在准星处生成 6 秒减速区，范围内敌人移速 -50%", "type": "slow", "cd": 16.0, "radius": 8.0, "dur": 6.0, "factor": 0.5},
     "ult": {"name": "暗域", "desc": "大范围烟幕并减速其中的敌人", "type": "blackout", "radius": 12.0, "dur": 7.0, "factor": 0.5}},
]


static func get_by_id(id: String) -> Dictionary:
    for o in LIST:
        if o["id"] == id:
            return o
    return LIST[0]
