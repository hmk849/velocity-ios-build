extends Node
## 技能控制器（挂在 Player 下，只在单机/训练场启用，未做网络同步）。
## 负责: 被动属性 → player.ability_mods；主动技能冷却与效果；终极技能充能（命中/击杀/时间）与效果。
## 干员数据见 Operators。键位: 主动 G / 终极 X（触屏 ABIL / ULT，手柄 十字键上/下）。

var player: Player
var op: Dictionary

var _cd := 0.0
var _cd_total := 1.0
var _charge := 0.0
var _boost_t := 0.0
var _boost_mult := 1.0
var _shield_t := 0.0
var _shield_red := 0.0
var _heal_left := 0.0
var _heal_rate := 0.0
var _ov_t := 0.0
var _ov := {}
var _dmg_t := 0.0
var _dmg_mult := 1.0
var _fort_t := 0.0
var _fort_red := 0.0
var _fort_regen := 0.0
var _base := {}
var _mines: Array = []
var _emit_t := 0.0


func _ready() -> void:
    op = Operators.get_by_id(Loadout.operator)
    _base = {"move": 1.0, "jump": 1.0, "air_jumps": 0, "wallrun_speed": 1.0, "wallrun_time": 0.0,
        "slide_boost": 0.0, "regen_delay": 5.0, "reload": 1.0, "ads_time": 1.0, "headshot": 0.0,
        "dmg_reduction": 0.0, "dmg": 1.0}
    var pm: Dictionary = (op["passive"] as Dictionary)["mods"]
    for k in pm.keys():
        if k == "max_health":
            player.max_health += float(pm[k])
            player.health = player.max_health
        else:
            _base[k] = pm[k]
    player.ability_mods = _base.duplicate()
    EventBus.hit_confirmed.connect(_on_hit)


func _exit_tree() -> void:
    if EventBus.hit_confirmed.is_connected(_on_hit):
        EventBus.hit_confirmed.disconnect(_on_hit)


func _on_hit(_is_head: bool, killed: bool) -> void:
    _charge = minf(_charge + (25.0 if killed else 3.0), Operators.ULT_CHARGE_MAX)


func on_respawn() -> void:
    _boost_t = 0.0
    _shield_t = 0.0
    _heal_left = 0.0
    _ov_t = 0.0
    _dmg_t = 0.0
    _fort_t = 0.0


func _physics_process(delta: float) -> void:
    if player == null:
        return
    _cd = maxf(_cd - delta, 0.0)
    if player.alive and player.controls_enabled:
        _charge = minf(_charge + 1.5 * delta, Operators.ULT_CHARGE_MAX)
    _boost_t = maxf(_boost_t - delta, 0.0)
    _shield_t = maxf(_shield_t - delta, 0.0)
    _ov_t = maxf(_ov_t - delta, 0.0)
    _dmg_t = maxf(_dmg_t - delta, 0.0)
    _fort_t = maxf(_fort_t - delta, 0.0)
    if player.alive:
        if _heal_left > 0.0:
            var h := minf(_heal_rate * delta, _heal_left)
            _heal_left -= h
            player.health = minf(player.health + h, player.max_health)
            EventBus.player_health.emit(player.health, player.max_health)
        if _fort_t > 0.0:
            player.health = minf(player.health + _fort_regen * delta, player.max_health)
            EventBus.player_health.emit(player.health, player.max_health)
    _apply_mods()
    _emit_t += delta
    if _emit_t >= 0.1:
        _emit_t = 0.0
        var a := op["active"] as Dictionary
        var u := op["ult"] as Dictionary
        EventBus.ability_state.emit(String(a["name"]), 1.0 - _cd / maxf(_cd_total, 0.01),
            String(u["name"]), _charge / Operators.ULT_CHARGE_MAX)


## 被动 + 临时效果合成最终属性
func _apply_mods() -> void:
    var m := _base.duplicate()
    var move := float(_base["move"])
    var jump := float(_base["jump"])
    var dmg := float(_base["dmg"])
    var reload := float(_base["reload"])
    var red := float(_base["dmg_reduction"])
    if _boost_t > 0.0:
        move *= _boost_mult
    if _ov_t > 0.0:
        move *= float(_ov["move"])
        jump *= float(_ov["jump"])
        dmg *= float(_ov["dmg"])
        reload *= float(_ov["reload"])
    if _dmg_t > 0.0:
        dmg *= _dmg_mult
    if _shield_t > 0.0:
        red = 1.0 - (1.0 - red) * (1.0 - _shield_red)
    if _fort_t > 0.0:
        red = 1.0 - (1.0 - red) * (1.0 - _fort_red)
    m["move"] = move
    m["jump"] = jump
    m["dmg"] = dmg
    m["reload"] = reload
    m["dmg_reduction"] = red
    player.ability_mods = m


# ---------- 主动 ----------
func use_active() -> void:
    if _cd > 0.0 or player == null or not player.alive or not player.controls_enabled:
        return
    var a := op["active"] as Dictionary
    match String(a["type"]):
        "dash":
            var dir := player.wish_direction()
            var dash_speed := maxf(Vector2(player.velocity.x, player.velocity.z).length(), float(a["power"]))
            player.velocity.x = dir.x * dash_speed
            player.velocity.z = dir.z * dash_speed
            player.velocity.y = maxf(player.velocity.y, 3.0)
            player.state = Player.State.AIR
        "boost":
            _boost_t = float(a["dur"])
            _boost_mult = float(a["mult"])
        "scan":
            _scan(float(a["radius"]), float(a["dur"]))
        "shield":
            _shield_t = float(a["dur"])
            _shield_red = float(a["reduction"])
        "heal":
            _heal_left = float(a["amount"])
            _heal_rate = float(a["amount"]) / maxf(float(a["dur"]), 0.1)
        "smoke":
            _spawn_smoke(_aim_point(30.0), float(a["radius"]), float(a["dur"]), 1.0)
        "frag":
            _throw_frag(float(a["damage"]), float(a["radius"]))
        "mine":
            _place_mine(float(a["damage"]), float(a["radius"]))
        "slow":
            var sf := AbilityFx.SlowField.new()
            sf.radius = float(a["radius"])
            sf.life = float(a["dur"])
            sf.factor = float(a["factor"])
            sf.owner_team = player.team
            _spawn(sf, _aim_point(25.0))
        "jumppad":
            var jp := AbilityFx.JumpPad.new()
            jp.power = float(a["power"])
            jp.life = float(a["dur"])
            _spawn(jp, player.global_position + Vector3(0, 0.06, 0))
    _cd_total = float(a["cd"])
    _cd = _cd_total


# ---------- 终极 ----------
func use_ult() -> void:
    if _charge < Operators.ULT_CHARGE_MAX or player == null or not player.alive or not player.controls_enabled:
        return
    var u := op["ult"] as Dictionary
    match String(u["type"]):
        "overdrive":
            _ov_t = float(u["dur"])
            _ov = u
        "scan_all":
            _scan(0.0, float(u["dur"]))
            _dmg_t = float(u["dur"])
            _dmg_mult = float(u["dmg"])
        "barrage":
            var p := _aim_point(30.0)
            for i in int(u["count"]):
                get_tree().create_timer(0.35 * i).timeout.connect(_drop_bomb.bind(p, float(u["damage"]), float(u["radius"])))
        "fortress":
            _fort_t = float(u["dur"])
            _fort_red = float(u["reduction"])
            _fort_regen = float(u["regen"])
        "nova":
            AbilityFx.explode(player.get_parent(), player.global_position + Vector3.UP, float(u["radius"]), float(u["damage"]), player, "NOVA")
            player.health = minf(player.health + float(u["heal"]), player.max_health)
            EventBus.player_health.emit(player.health, player.max_health)
        "blackout":
            _spawn_smoke(_aim_point(28.0), float(u["radius"]), float(u["dur"]), float(u["factor"]))
    _charge = 0.0


# ---------- 工具 ----------
func _aim_point(max_dist: float) -> Vector3:
    var cam := player.camera
    var from := cam.global_position
    var dir := -cam.global_transform.basis.z
    var q := PhysicsRayQueryParameters3D.create(from, from + dir * max_dist)
    q.collision_mask = 1
    var hit := player.get_world_3d().direct_space_state.intersect_ray(q)
    return hit.position if not hit.is_empty() else from + dir * max_dist


func _spawn(n: Node3D, pos: Vector3) -> void:
    player.get_parent().add_child(n)
    n.global_position = pos


func _spawn_smoke(pos: Vector3, radius: float, dur: float, slow: float) -> void:
    var s := AbilityFx.SmokeZone.new()
    s.radius = radius
    s.life = dur
    s.slow_factor = slow
    s.owner_team = player.team
    _spawn(s, pos + Vector3(0, radius * 0.5, 0))


func _throw_frag(damage: float, radius: float) -> void:
    var f := AbilityFx.Frag.new()
    f.damage = damage
    f.radius = radius
    f.attacker = player
    var fwd := -player.camera.global_transform.basis.z
    f.velocity = fwd * 16.0 + Vector3.UP * 4.0
    _spawn(f, player.camera.global_position + fwd * 0.6)


func _drop_bomb(center: Vector3, damage: float, radius: float) -> void:
    if not is_instance_valid(player) or not player.is_inside_tree():
        return
    var f := AbilityFx.Frag.new()
    f.damage = damage
    f.radius = radius
    f.attacker = player
    f.label = "BARRAGE"
    f.fuse = 99.0
    f.velocity = Vector3(0, -12, 0)
    _spawn(f, center + Vector3(randf_range(-radius, radius), 28.0, randf_range(-radius, radius)))


func _place_mine(damage: float, radius: float) -> void:
    var m := AbilityFx.Mine.new()
    m.damage = damage
    m.radius = radius
    m.attacker = player
    m.owner_team = player.team
    _spawn(m, player.global_position + Vector3(0, 0.06, 0))
    _mines.append(m)
    while _mines.size() > 3:          # 最多同时 3 颗
        var old = _mines.pop_front()
        if is_instance_valid(old):
            old.queue_free()


## 透视: radius <= 0 表示全场。烟幕内的敌人扫不到（反制）。
func _scan(radius: float, dur: float) -> void:
    var smokes := get_tree().get_nodes_in_group("smoke_zones")
    for n in get_tree().get_nodes_in_group("combatants"):
        var c := n as Node3D
        if c == null or c == player or not bool(c.get("alive")) or int(c.get("team")) == player.team:
            continue
        if radius > 0.0 and c.global_position.distance_to(player.global_position) > radius:
            continue
        var hidden := false
        for s in smokes:
            if (s as Node3D).global_position.distance_to(c.global_position) < float(s.get("radius")):
                hidden = true
        if hidden:
            continue
        var mk := AbilityFx.ScanMarker.new()
        mk.target = c
        mk.life = dur
        player.get_parent().add_child(mk)
