class_name AbilityFx
extends RefCounted
## 技能的世界实体: 烟幕 / 减速场 / 地雷 / 手雷 / 弹跳垫 / 透视标记，以及统一的爆炸伤害。
## 所有实体都有寿命与数量上限。反制: 烟幕阻挡视线和扫描；地雷可以被射击摧毁；
## 爆炸需要视线（墙后不受伤）；不对队友/自己造成伤害。

static func _glow_mat(color: Color, alpha: float) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m.albedo_color = Color(color, alpha)
    return m


## 爆炸: 范围伤害（带衰减、需要视线）+ 简易特效
static func explode(root: Node, pos: Vector3, radius: float, damage: float, attacker: Node, label: String) -> void:
    var space: PhysicsDirectSpaceState3D = (root as Node3D).get_world_3d().direct_space_state
    if attacker != null and attacker.get("kill_label") != null:
        attacker.set("kill_label", label)
    for n in root.get_tree().get_nodes_in_group("combatants"):
        var c := n as Node3D
        if c == null or not bool(c.get("alive")) or c == attacker:
            continue
        if attacker != null and int(c.get("team")) == int(attacker.get("team")):
            continue
        var chest := c.global_position + Vector3.UP * 1.1
        var d := pos.distance_to(chest)
        if d > radius:
            continue
        var q := PhysicsRayQueryParameters3D.create(pos + Vector3.UP * 0.2, chest)
        q.collision_mask = 1
        if not space.intersect_ray(q).is_empty():
            continue
        if c.has_method("take_damage"):
            c.call("take_damage", damage * (1.0 - 0.6 * d / radius), attacker, false)
    if attacker != null and attacker.get("kill_label") != null:
        attacker.set("kill_label", "")
    _burst(root, pos, radius)


static func _burst(root: Node, pos: Vector3, radius: float) -> void:
    var p := CPUParticles3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = 0.12
    mesh.height = 0.24
    mesh.radial_segments = 6
    mesh.rings = 3
    mesh.material = _glow_mat(Color("ffb060"), 0.9)
    p.mesh = mesh
    p.amount = 24
    p.lifetime = 0.5
    p.one_shot = true
    p.explosiveness = 1.0
    p.direction = Vector3.UP
    p.spread = 180.0
    p.initial_velocity_min = radius * 0.8
    p.initial_velocity_max = radius * 1.6
    p.gravity = Vector3(0, -6, 0)
    root.add_child(p)
    p.global_position = pos
    p.emitting = true
    root.get_tree().create_timer(1.0).timeout.connect(p.queue_free)


# ---------- 烟幕（半透明球，阻挡视线/扫描）----------
class SmokeZone extends Node3D:
    var radius := 6.0
    var life := 8.0
    var slow_factor := 1.0           # < 1: 同时减速范围内的敌人（全面熄灯/暗域）
    var owner_team := 0

    func _ready() -> void:
        add_to_group("smoke_zones")
        var mi := MeshInstance3D.new()
        var sm := SphereMesh.new()
        sm.radius = radius
        sm.height = radius * 2.0
        sm.radial_segments = 16
        sm.rings = 8
        mi.mesh = sm
        mi.material_override = AbilityFx._glow_mat(Color("5c6672"), 0.82)
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(mi)

    func _physics_process(delta: float) -> void:
        life -= delta
        if life <= 0.0:
            queue_free()
            return
        if slow_factor < 1.0:
            var now := Time.get_ticks_msec() / 1000.0
            for n in get_tree().get_nodes_in_group("combatants"):
                var c := n as Node3D
                if c != null and int(c.get("team")) != owner_team and c.global_position.distance_to(global_position) < radius:
                    if c.get("slow_until") != null:
                        c.set("slow_until", now + 0.25)
                        c.set("slow_factor", slow_factor)

    ## 线段 a→b 是否穿过烟幕球
    func blocks(a: Vector3, b: Vector3) -> bool:
        var ab := b - a
        var len2 := ab.length_squared()
        if len2 < 0.0001:
            return false
        var t := clampf((global_position - a).dot(ab) / len2, 0.0, 1.0)
        return (a + ab * t).distance_to(global_position) < radius


# ---------- 减速场 ----------
class SlowField extends Node3D:
    var radius := 8.0
    var life := 6.0
    var factor := 0.5
    var owner_team := 0

    func _ready() -> void:
        var mi := MeshInstance3D.new()
        var cm := CylinderMesh.new()
        cm.top_radius = radius
        cm.bottom_radius = radius
        cm.height = 0.1
        cm.radial_segments = 24
        mi.mesh = cm
        mi.material_override = AbilityFx._glow_mat(Color("7fd3ff"), 0.35)
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(mi)

    func _physics_process(delta: float) -> void:
        life -= delta
        if life <= 0.0:
            queue_free()
            return
        var now := Time.get_ticks_msec() / 1000.0
        for n in get_tree().get_nodes_in_group("combatants"):
            var c := n as Node3D
            if c != null and int(c.get("team")) != owner_team and c.global_position.distance_to(global_position) < radius:
                if c.get("slow_until") != null:
                    c.set("slow_until", now + 0.25)
                    c.set("slow_factor", factor)


# ---------- 地雷（可被射击摧毁）----------
class Mine extends Node3D:
    var damage := 100.0
    var radius := 4.0
    var attacker: Node
    var owner_team := 0
    var life := 60.0
    var _armed := 1.0
    var _zones: Array = []

    func _ready() -> void:
        var mi := MeshInstance3D.new()
        var cm := CylinderMesh.new()
        cm.top_radius = 0.25
        cm.bottom_radius = 0.3
        cm.height = 0.12
        mi.mesh = cm
        mi.material_override = AbilityFx._glow_mat(Color("ff7a1a"), 1.0)
        add_child(mi)
        var z := HitZone.new()          # 命中区域: 被打到就失效（反制）
        z.target = self
        var cs := CollisionShape3D.new()
        var bs := BoxShape3D.new()
        bs.size = Vector3(0.6, 0.3, 0.6)
        cs.shape = bs
        z.add_child(cs)
        z.position = Vector3(0, 0.1, 0)
        add_child(z)
        _zones.append(z)

    ## HitZone 转发: 被任何子弹击中即摧毁（不爆炸）
    func take_damage(_amount: float, _attacker: Node = null, _is_head := false) -> bool:
        queue_free()
        return false

    func _physics_process(delta: float) -> void:
        life -= delta
        if life <= 0.0:
            queue_free()
            return
        _armed -= delta
        if _armed > 0.0:
            return
        for n in get_tree().get_nodes_in_group("combatants"):
            var c := n as Node3D
            if c != null and bool(c.get("alive")) and int(c.get("team")) != owner_team \
                    and c.global_position.distance_to(global_position) < 2.5:
                AbilityFx.explode(get_parent(), global_position, radius, damage, attacker, "MINE")
                queue_free()
                return


# ---------- 手雷 / 炸弹（抛物线 + 定时/落地爆炸）----------
class Frag extends Node3D:
    var velocity := Vector3.ZERO
    var damage := 90.0
    var radius := 5.0
    var attacker: Node
    var fuse := 1.8
    var label := "FRAG"

    func _ready() -> void:
        var mi := MeshInstance3D.new()
        var sm := SphereMesh.new()
        sm.radius = 0.1
        sm.height = 0.2
        mi.mesh = sm
        mi.material_override = AbilityFx._glow_mat(Color("ff7a1a"), 1.0)
        add_child(mi)

    func _physics_process(delta: float) -> void:
        fuse -= delta
        velocity.y -= 18.0 * delta
        var to := global_position + velocity * delta
        var q := PhysicsRayQueryParameters3D.create(global_position, to)
        q.collision_mask = 1
        var hit := get_world_3d().direct_space_state.intersect_ray(q)
        if not hit.is_empty():
            global_position = hit.position + hit.normal * 0.05
            velocity = velocity.bounce(hit.normal) * 0.3
            if fuse > 0.4 and label == "FRAG":
                return
            fuse = 0.0
        else:
            global_position = to
        if fuse <= 0.0:
            AbilityFx.explode(get_parent(), global_position, radius, damage, attacker, label)
            queue_free()


# ---------- 弹跳垫 ----------
class JumpPad extends Node3D:
    var power := 16.0
    var life := 15.0
    var _cool := 0.0

    func _ready() -> void:
        var mi := MeshInstance3D.new()
        var cm := CylinderMesh.new()
        cm.top_radius = 0.9
        cm.bottom_radius = 0.9
        cm.height = 0.12
        mi.mesh = cm
        mi.material_override = AbilityFx._glow_mat(Color("ff7a1a"), 0.85)
        add_child(mi)

    func _physics_process(delta: float) -> void:
        life -= delta
        _cool = maxf(_cool - delta, 0.0)
        if life <= 0.0:
            queue_free()
            return
        if _cool > 0.0:
            return
        for n in get_tree().get_nodes_in_group("combatants"):
            var c := n as CharacterBody3D
            if c != null and c.has_method("net_apply_state"):      # 只对玩家生效
                var d := c.global_position - global_position
                if Vector2(d.x, d.z).length() < 1.0 and absf(d.y) < 0.8:
                    c.velocity.y = power
                    c.set("state", 1)          # Player.State.AIR
                    _cool = 0.6


# ---------- 透视标记（无深度测试，隔墙可见）----------
class ScanMarker extends Node3D:
    var target: Node3D
    var life := 4.0

    func _ready() -> void:
        var mi := MeshInstance3D.new()
        var sm := SphereMesh.new()
        sm.radius = 0.28
        sm.height = 0.56
        sm.radial_segments = 8
        sm.rings = 4
        mi.mesh = sm
        var m := AbilityFx._glow_mat(Color("ff3a3a"), 0.85)
        m.no_depth_test = true
        m.render_priority = 10
        mi.material_override = m
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(mi)

    func _process(delta: float) -> void:
        life -= delta
        if life <= 0.0 or not is_instance_valid(target) or not bool(target.get("alive")):
            queue_free()
            return
        global_position = target.global_position + Vector3(0, 2.1, 0)
