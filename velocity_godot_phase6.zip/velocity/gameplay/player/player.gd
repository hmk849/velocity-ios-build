class_name Player
extends CharacterBody3D
## 第一人称角色（可切第三人称）。状态: GROUND / AIR / SLIDE / WALL_RUN / MANTLE / GRAPPLE / ZIPLINE。
## 已实现: 走、冲刺、跳、二段跳、滑铲、滑铲跳、斜坡滑铲加速、空中动量与转向、
##         蹬墙跑、墙跳、翻越/攀爬(Mantle)、钩爪、滑索、落地缓冲、ADS 灵敏度/移速/FOV、瞄镜晃动、
##         第三人称程序化角色(Puppet，手臂/腿 IK)。
## 未实现: 骨骼蒙皮动画资产。
## 注意: 本地单机逻辑。联网时需改成「输入 → 预测 → 服务器校正」（Phase 5）。

signal died(victim: Node, attacker: Node, is_head: bool)

enum State { GROUND, AIR, SLIDE, WALL_RUN, MANTLE, GRAPPLE, ZIPLINE }
const STATE_NAMES := ["GROUND", "AIR", "SLIDE", "WALL RUN", "MANTLE", "GRAPPLE", "ZIPLINE"]

# 网络输入帧按钮位（边沿位=这一帧按下；电平位=按住）
const B_JUMP := 1
const B_SLIDE := 2
const B_FIRE := 4
const B_ADS := 8
const B_RELOAD := 16
const B_SWAP := 32
const B_GRAPPLE := 64
const B_USE := 128
const B_SCOPE := 256
const B_INSPECT := 512
const B_SPRINT := 1024
const B_SLIDE_HELD := 2048

const MOUSE_RAD := 0.0022
const TOUCH_RAD := 0.0035
const MAX_PITCH := 1.5359   # 88°

@export_group("Movement")
@export var walk_speed := 6.0
@export var sprint_speed := 9.5
@export var ground_accel := 70.0
@export var ground_decel := 50.0
@export var overspeed_decel := 10.0    # 超过目标速度时的缓慢衰减（保留动量）
@export var air_accel := 14.0
@export var gravity := 24.0
@export var jump_velocity := 7.5
@export var max_air_jumps := 1
@export var stand_eye := 1.65
@export var slide_eye := 0.9

@export_group("Slide")
@export var slide_boost := 3.0
@export var slide_max_speed := 13.0
@export var slide_decel := 6.0
@export var slide_steer := 2.0
@export var slide_min_speed := 4.0
@export var slide_max_time := 1.1
@export var slope_gain := 38.0         # 下坡加速（m/s² / 坡度）
@export var slope_max_speed := 18.0

@export_group("Wall run")
@export var wall_run_min_speed := 5.5
@export var wall_run_speed := 10.0
@export var wall_run_max_speed := 16.0
@export var wall_run_max_time := 2.2
@export var wall_gravity_scale := 0.12
@export var wall_check_dist := 0.75
@export var wall_stick := 2.0
@export var wall_jump_push := 6.5
@export var wall_jump_up := 7.0

@export_group("Mantle")
@export var mantle_reach := 0.9
@export var mantle_min_height := 0.55
@export var mantle_max_height := 2.4
@export var mantle_time := 0.3

@export_group("Grapple")
@export var grapple_range := 45.0
@export var grapple_speed := 24.0
@export var grapple_accel := 55.0
@export var grapple_max_time := 2.5
@export var grapple_cooldown := 1.5
@export var grapple_stop_dist := 2.5

@export_group("Zipline")
@export var zipline_reach := 1.7
@export var zipline_hand_height := 1.95
@export var zipline_accel := 14.0

var state := State.GROUND

# ---- 联网（Phase 5，全部用鸭子类型，不静态引用 net 脚本）----
var net_role := "offline"          # offline / server / client
var net_ctl := false               # 服务器上的玩家替身: 输入来自网络帧
var net_frame: Array = []          # [seq, mx, my, yaw, pitch, buttons, render_time]
var net_buttons := 0
var net_render_time := 0.0
var net_notify := Callable()       # 服务器上把"给本人"的事件转发给对应客户端
var lagcomp_begin := Callable()
var lagcomp_end := Callable()
var attach_override: Dictionary = {}   # 服务器: weapon_id -> {slot: path}
var _last_frame: Array = []
var _reload_edge := false
var _replaying := false

# ---- 干员技能 / 辅助瞄准（Phase 6）----
var ability_mods: Dictionary = {}      # 由 AbilityController 每帧写入（被动 + 临时效果）
var ability_ctl: Node = null
var kill_label := ""                   # 技能击杀时在击杀播报里显示的名字
var _assist_slow := false

# ---- 战斗 / 对局 ----
var team := 0
var display_name := "YOU"
var health := 100.0
var max_health := 100.0
var alive := true
var controls_enabled := true      # 倒计时/赛后为 false
var spawn_protect := 0.0
var _since_damage := 99.0
var _zones: Array[HitZone] = []
var _exclude: Array[RID] = []
var touch: TouchControls = null        # 手机上由地图注入
var loadout: Array[WeaponData] = []
var weapon: Weapon
var head: Node3D
var camera: Camera3D

var yaw := 0.0
var pitch := 0.0

var _move_input := Vector2.ZERO        # x=右, y=前
var _wish_dir := Vector3.ZERO
var _wish_mag := 0.0
var _sprinting := false
var _jump_pressed := false
var _slide_pressed := false
var _slide_buffer := 0.0
var _slide_held := false
var _grapple_pressed := false
var _use_pressed := false
var _touch_ads := false

var _slide_t := 0.0
var _slide_cd := 0.0
var _air_jumps := 0
var _slot := 0
var _spawn_pos := Vector3.ZERO
var _base_fov := 90.0

var _wall_normal := Vector3.ZERO
var _wall_side := 0.0                  # +1 墙在右, -1 墙在左
var _wall_run_t := 0.0
var _wall_cd := 0.0

var _mantle_from := Vector3.ZERO
var _mantle_to := Vector3.ZERO
var _mantle_t := 0.0
var _mantle_dur := 0.35
var _mantle_keep := Vector3.ZERO
var _mantle_cd := 0.0

var _grapple_point := Vector3.ZERO
var _grapple_t := 0.0
var _grapple_cd := 0.0
var _rope: MeshInstance3D
var _rope_mesh: ImmediateMesh

var _zip: Zipline
var _zip_t := 0.0
var _zip_dir := 1.0
var _zip_speed := 0.0
var _zip_cd := 0.0
var _zip_age := 0.0

var third_person := false
var puppet: Puppet
var _land_dip := 0.0

var _roll := 0.0
var _sway_t := 0.0
var _dbg_t := 0.0
var _probe_shape: CapsuleShape3D


func _ready() -> void:
    _spawn_pos = position
    _base_fov = Settings.fov

    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.4
    cap.height = 1.8
    cs.shape = cap
    cs.position.y = 0.9
    add_child(cs)

    _probe_shape = CapsuleShape3D.new()
    _probe_shape.radius = 0.38
    _probe_shape.height = 1.7

    # 碰撞层: 本体在第 2 层、只和第 1 层(几何体)碰撞；命中区域在第 3 层
    collision_layer = 2
    collision_mask = 1
    _zones = HitZone.add_humanoid_zones(self, self)
    _exclude = [get_rid()]
    for z in _zones:
        _exclude.append(z.get_rid())
    add_to_group("combatants")

    head = Node3D.new()
    head.position.y = stand_eye
    add_child(head)
    camera = Camera3D.new()
    camera.fov = _base_fov
    camera.near = 0.05
    head.add_child(camera)

    _rope_mesh = ImmediateMesh.new()
    _rope = MeshInstance3D.new()
    _rope.mesh = _rope_mesh
    var rm := StandardMaterial3D.new()
    rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    rm.albedo_color = UITheme.ICE
    _rope.material_override = rm
    _rope.top_level = true
    _rope.visible = false
    add_child(_rope)

    weapon = Weapon.new()
    weapon.player = self
    weapon.camera = camera
    camera.add_child(weapon)
    puppet = Puppet.new()
    puppet.visible = false
    add_child(puppet)
    weapon.gun_rebuilt.connect(_on_gun_rebuilt)
    weapon.reload_started.connect(_on_reload_started)
    weapon.fired.connect(_on_fired)
    if net_role == "offline":          # 技能只在单机/训练场启用；模块缺失或出错不影响其他功能
        var scr: Script = load("res://gameplay/abilities/ability_controller.gd")
        if scr != null:
            ability_ctl = scr.new()
            ability_ctl.set("player", self)
            add_child(ability_ctl)
    if loadout.size() > 0:
        weapon.equip(loadout[0])

    if not Game.is_mobile and net_role != "server":
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _exit_tree() -> void:
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


# ---------- 输入 ----------
func _unhandled_input(event: InputEvent) -> void:
    if Game.is_mobile:
        return
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        var k := MOUSE_RAD * Settings.look_sens * _look_scale()
        add_look(-event.relative.x * k, -event.relative.y * k)
    elif event.is_action_pressed("ui_cancel"):
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    elif event is InputEventMouseButton and event.pressed and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func add_look(d_yaw: float, d_pitch: float) -> void:
    yaw += d_yaw
    pitch = clampf(pitch + d_pitch, -MAX_PITCH, MAX_PITCH)


## 开镜时灵敏度随倍率自动降低
func _look_scale() -> float:
    var k := 1.0
    if weapon != null and weapon.ads_t > 0.0:
        k = lerpf(1.0, Settings.ads_sens * Settings.ads_zoom_mult(weapon.zoom) / pow(weapon.zoom, 0.6), weapon.ads_t)
    if _assist_slow:
        k *= 1.0 - 0.45 * Settings.aim_assist     # 准星扫过敌人时轻微减速（触屏辅助瞄准）
    return k


func is_fire_held() -> bool:
    if net_ctl:
        return (net_buttons & B_FIRE) != 0
    return Input.is_action_pressed("fire") or (touch != null and touch.fire_held)


func wants_ads() -> bool:
    if net_ctl:
        return (net_buttons & B_ADS) != 0
    return Input.is_action_pressed("ads") or _touch_ads


func consume_reload() -> bool:
    var r := _reload_edge
    _reload_edge = false
    return r


func speed_ratio() -> float:
    return clampf(_horizontal_speed() / sprint_speed, 0.0, 1.0)


func _horizontal_speed() -> float:
    return Vector2(velocity.x, velocity.z).length()


func _poll_input() -> void:
    if net_ctl:
        _poll_from_net(true)
        return
    var tv := touch.move_vector if touch != null else Vector2.ZERO
    _move_input = Input.get_vector("move_left", "move_right", "move_back", "move_forward") + tv
    if _move_input.length() > 1.0:
        _move_input = _move_input.normalized()

    var dir := global_transform.basis * Vector3(_move_input.x, 0.0, -_move_input.y)
    dir.y = 0.0
    _wish_dir = dir.normalized()
    _wish_mag = _move_input.length()

    var auto_sprint := Settings.auto_sprint and touch != null \
        and tv.length() > 0.92 and tv.y > 0.3
    _sprinting = Input.is_action_pressed("sprint") or auto_sprint

    _jump_pressed = Input.is_action_just_pressed("jump")
    _slide_pressed = Input.is_action_just_pressed("slide")
    _slide_held = Input.is_action_pressed("slide")
    _grapple_pressed = Input.is_action_just_pressed("grapple")
    _use_pressed = Input.is_action_just_pressed("use")
    var view := Input.is_action_just_pressed("view")
    var inspect := Input.is_action_just_pressed("inspect")
    var swap := Input.is_action_just_pressed("swap")
    var scope := Input.is_action_just_pressed("scope")
    var reload_now := Input.is_action_just_pressed("reload")
    var ab := Input.is_action_just_pressed("ability")
    var ult := Input.is_action_just_pressed("ultimate")
    if touch != null:
        reload_now = reload_now or touch.consume("reload")
        ab = ab or touch.consume("ability")
        ult = ult or touch.consume("ultimate")
        _jump_pressed = _jump_pressed or touch.consume("jump")
        _slide_pressed = _slide_pressed or touch.consume("slide")
        _grapple_pressed = _grapple_pressed or touch.consume("grapple")
        swap = swap or touch.consume("swap")
        scope = scope or touch.consume("scope")
        view = view or touch.consume("view")
        inspect = inspect or touch.consume("inspect")
        if touch.consume("ads"):
            _touch_ads = not _touch_ads
    if swap:
        _cycle_weapon()
    if scope and weapon != null:
        weapon.cycle_sight()
    if inspect and weapon != null:
        weapon.inspect()
    if ability_ctl != null:
        if ab:
            ability_ctl.call("use_active")
        if ult:
            ability_ctl.call("use_ult")
    if view:
        set_third_person(not third_person)
    _reload_edge = _reload_edge or reload_now
    var bits := 0
    if _jump_pressed: bits |= B_JUMP
    if _slide_pressed: bits |= B_SLIDE
    if is_fire_held(): bits |= B_FIRE
    if wants_ads(): bits |= B_ADS
    if reload_now: bits |= B_RELOAD
    if swap: bits |= B_SWAP
    if _grapple_pressed: bits |= B_GRAPPLE
    if _use_pressed: bits |= B_USE
    if scope: bits |= B_SCOPE
    if inspect: bits |= B_INSPECT
    if _sprinting: bits |= B_SPRINT
    if _slide_held: bits |= B_SLIDE_HELD
    _last_frame = [0, _move_input.x, _move_input.y, yaw, pitch, bits, 0.0]


func _cycle_weapon() -> void:
    if loadout.size() < 2:
        return
    _slot = (_slot + 1) % loadout.size()
    weapon.equip(loadout[_slot])


## 训练场武器选择器: 把当前槽位换成指定武器
func equip_weapon_by_id(id: String) -> void:
    var d := WeaponCatalog.load_weapon(id)
    if d == null or weapon == null:
        return
    if loadout.size() == 0:
        loadout.append(d)
    else:
        loadout[_slot] = d
    weapon.equip(d)


func set_third_person(on: bool) -> void:
    third_person = on
    if puppet != null:
        puppet.visible = on
    if weapon != null:
        weapon.set_viewmodel_visible(not on)
    if not on and camera != null:
        camera.position = Vector3.ZERO


func _on_gun_rebuilt() -> void:
    if puppet != null and weapon != null and weapon.data != null:
        puppet.set_weapon(weapon.data, weapon.attachments)


func _on_reload_started(duration: float, _empty: bool) -> void:
    if puppet != null:
        puppet.start_reload(duration)
        if puppet.gun != null:
            puppet.gun.anim_reload(duration, _empty)


func _on_fired() -> void:
    if puppet != null:
        puppet.kick()
        if puppet.gun != null and weapon != null and weapon.data != null:
            puppet.gun.anim_fire(60.0 / weapon.data.fire_rate_rpm)


# ---------- 帧更新（渲染帧: 视角、相机）----------
func _process(delta: float) -> void:
    if touch != null:
        var d := touch.consume_look()
        if d != Vector2.ZERO:
            var k := TOUCH_RAD * Settings.look_sens * _look_scale()
            add_look(-d.x * k, -d.y * k)

    # 手柄右摇杆 / 陀螺仪视角
    var stick := Input.get_vector("look_left", "look_right", "look_up", "look_down")
    if stick.length() > Settings.stick_deadzone:
        var sk := 2.6 * delta * Settings.look_sens * _look_scale()
        add_look(-stick.x * sk, -stick.y * sk)
    if Game.is_mobile and Settings.gyro_enabled:
        var g := Input.get_gyroscope()
        var sgn := -1.0 if DisplayServer.screen_get_orientation() == DisplayServer.SCREEN_REVERSE_LANDSCAPE else 1.0
        var gk := Settings.gyro_sens * 0.6 * delta * _look_scale()
        add_look(g.x * gk * sgn, -g.y * gk * sgn * (-1.0 if Settings.gyro_invert_y else 1.0))

    var ads := weapon.ads_t if weapon != null else 0.0
    var zoom := weapon.zoom if weapon != null else 1.0
    var main_zoom := weapon.main_zoom() if weapon != null else 1.0

    # 高倍镜呼吸晃动：倍率越高、移动越快晃得越大
    _sway_t += delta
    var sway := Vector2.ZERO
    if ads > 0.5 and zoom >= 3.0:
        var amp := 0.0005 * zoom * (1.0 + _horizontal_speed() * 0.3) * ads
        sway = Vector2(sin(_sway_t * 0.9), sin(_sway_t * 1.3 + 1.0)) * amp
    rotation.y = yaw + sway.x
    head.rotation.x = pitch + sway.y

    # 蹬墙跑镜头侧倾（向远离墙的一侧）
    var roll_target := _wall_side * 0.14 if state == State.WALL_RUN else 0.0
    _roll = lerpf(_roll, roll_target, 1.0 - exp(-10.0 * delta))
    head.rotation.z = _roll

    _land_dip = move_toward(_land_dip, 0.0, delta * 0.9)
    var eye := (slide_eye if state == State.SLIDE else stand_eye) - _land_dip
    head.position.y = lerpf(head.position.y, eye, 1.0 - exp(-14.0 * delta))

    var kick := clampf((_horizontal_speed() - walk_speed) * 1.2, 0.0, 8.0)
    var hip_fov := _base_fov + kick
    var ads_fov := rad_to_deg(2.0 * atan(tan(deg_to_rad(_base_fov) * 0.5) / main_zoom))
    camera.fov = lerpf(camera.fov, lerpf(hip_fov, ads_fov, ads), 1.0 - exp(-12.0 * delta))

    _update_rope()
    _update_third_person(delta)


# ---------- 物理帧 ----------
func _physics_process(delta: float) -> void:
    _poll_input()
    _assist_check()
    _sim_step(delta)


## 一个物理帧的模拟。服务器替身与客户端回放复用它（输入已经在 _poll_* 里准备好）
func _sim_step(delta: float) -> void:
    spawn_protect = maxf(spawn_protect - delta, 0.0)
    _since_damage += delta
    if alive and health < max_health and _since_damage > mod("regen_delay", 5.0) and net_role != "client":     # 脱战 5 秒后回血
        health = minf(health + 25.0 * delta, max_health)
        _notify("player_health", [health, max_health])
    if not alive or not controls_enabled:
        _tick_inactive(delta)
        return
    _slide_cd = maxf(_slide_cd - delta, 0.0)
    _slide_buffer = maxf(_slide_buffer - delta, 0.0)
    if _slide_pressed:
        _slide_buffer = 0.3          # 空中提前按滑铲，落地时生效
    _wall_cd = maxf(_wall_cd - delta, 0.0)
    _mantle_cd = maxf(_mantle_cd - delta, 0.0)
    _grapple_cd = maxf(_grapple_cd - delta, 0.0)

    if _grapple_pressed and state != State.GRAPPLE and state != State.MANTLE:
        _try_grapple()

    _zip_cd = maxf(_zip_cd - delta, 0.0)
    if _use_pressed and (state == State.GROUND or state == State.AIR or state == State.SLIDE):
        _try_zipline()

    if state == State.MANTLE:
        _tick_mantle(delta)
        _emit_debug(delta)
        return
    if state == State.ZIPLINE:
        _tick_zipline(delta)
        _emit_debug(delta)
        return

    if not is_on_floor() and state != State.GRAPPLE and state != State.WALL_RUN:
        velocity.y -= gravity * delta

    var vy_before := velocity.y
    var was_on_floor := is_on_floor()

    match state:
        State.GROUND:
            _tick_ground(delta)
        State.AIR:
            _tick_air(delta)
        State.SLIDE:
            _tick_slide(delta)
        State.WALL_RUN:
            _tick_wall_run(delta)
        State.GRAPPLE:
            _tick_grapple(delta)

    move_and_slide()

    # 落地缓冲: 镜头下沉，只做视觉，不扣速度（动量保持）
    if not was_on_floor and is_on_floor() and vy_before < -5.0:
        _land_dip = clampf(-vy_before * 0.012, 0.0, 0.18)

    if global_position.y < -30.0:
        global_position = _spawn_pos
        velocity = Vector3.ZERO
        state = State.AIR

    _emit_debug(delta)


func _emit_debug(delta: float) -> void:
    if _replaying or net_role == "server":
        return
    _dbg_t += delta
    if _dbg_t >= 0.1:
        _dbg_t = 0.0
        EventBus.movement_debug.emit(_horizontal_speed(), STATE_NAMES[state])


func _speed_mult() -> float:
    if weapon == null or weapon.data == null:
        return 1.0
    return weapon.move_multiplier() * lerpf(1.0, weapon.data.ads_move_mult, weapon.ads_t) * mod("move")


# ---------- 射线 / 形状探测 ----------
func _ray(from: Vector3, to: Vector3) -> Dictionary:
    var q := PhysicsRayQueryParameters3D.create(from, to)
    q.exclude = _exclude
    q.collision_mask = 1
    return get_world_3d().direct_space_state.intersect_ray(q)


func _capsule_blocked(feet_pos: Vector3) -> bool:
    var params := PhysicsShapeQueryParameters3D.new()
    params.shape = _probe_shape
    params.transform = Transform3D(Basis.IDENTITY, feet_pos + Vector3.UP * 0.95)
    params.exclude = _exclude
    params.collision_mask = 1
    return not get_world_3d().direct_space_state.intersect_shape(params, 1).is_empty()


# ---------- GROUND ----------
func _tick_ground(delta: float) -> void:
    if not is_on_floor():
        state = State.AIR
        return
    _air_jumps = _max_air()
    if _jump_pressed:
        if _try_mantle():          # 面前有矮墙/平台 → 翻越，而不是普通跳
            return
        velocity.y = jump_velocity * mod("jump")
        state = State.AIR
        return
    if _slide_buffer > 0.0 and _slide_cd <= 0.0:     # 不再要求先冲刺: 站立/行走/冲刺都能滑
        _start_slide()
        return

    var ads_block := weapon != null and weapon.ads_t > 0.3
    var top := sprint_speed if (_sprinting and not ads_block) else walk_speed
    var target := _wish_dir * top * _wish_mag * _speed_mult()
    var h := Vector3(velocity.x, 0.0, velocity.z)
    var rate := ground_accel
    if h.length() > target.length() + 0.01:
        # 无输入 → 快速停下；有输入但超速（例如滑铲落地）→ 缓慢衰减，保留动量
        rate = ground_decel if target.length() < 0.1 else overspeed_decel
    h = h.move_toward(target, rate * delta)
    velocity.x = h.x
    velocity.z = h.z


# ---------- AIR ----------
func _tick_air(delta: float) -> void:
    if is_on_floor() and velocity.y <= 0.0:
        state = State.GROUND
        return

    if _jump_pressed:
        if _try_zipline():
            return
        if _try_mantle():
            return
        if _wall_cd <= 0.0:
            var wj := _find_wall()
            if not wj.is_empty():
                _wall_jump(wj.normal)
                return
        if _air_jumps > 0:
            _air_jumps -= 1
            velocity.y = jump_velocity * 0.9 * mod("jump")
    elif _move_input.y > 0.3 and velocity.y < 3.0 and _try_mantle():
        return    # 空中朝前撞到可攀爬的边缘 → 自动攀上去

    if _wall_cd <= 0.0 and not is_on_floor() and _move_input.y > 0.1 \
            and _horizontal_speed() >= wall_run_min_speed and velocity.y > -9.0:
        var w := _find_wall()
        if not w.is_empty():
            _begin_wall_run(w)
            return

    var h := Vector3(velocity.x, 0.0, velocity.z)
    var cap := maxf(h.length(), walk_speed)    # 空中可转向，但不会凭空加速
    h += _wish_dir * _wish_mag * air_accel * delta
    if h.length() > cap:
        h = h.normalized() * cap
    velocity.x = h.x
    velocity.z = h.z


# ---------- SLIDE ----------
func _start_slide() -> void:
    state = State.SLIDE
    _slide_t = 0.0
    _slide_buffer = 0.0
    var h := Vector3(velocity.x, 0.0, velocity.z)
    var dir := h.normalized()
    if h.length() < 0.5:     # 站着按: 朝输入方向，没有输入就朝面向方向滑
        dir = _wish_dir if _wish_dir.length() > 0.1 else -global_transform.basis.z
        dir.y = 0.0
        dir = dir.normalized()
    var spd := minf(maxf(h.length(), walk_speed) + slide_boost + mod("slide_boost", 0.0), slide_max_speed + mod("slide_boost", 0.0))
    velocity.x = dir.x * spd
    velocity.z = dir.z * spd


func _tick_slide(delta: float) -> void:
    _slide_t += delta
    if not is_on_floor():
        state = State.AIR           # 滑出平台边缘，保留动量
        return
    if _jump_pressed:
        if _try_mantle():
            return
        velocity.y = jump_velocity  # 滑铲跳: 水平速度原样保留
        state = State.AIR
        _slide_cd = 0.3
        return

    var n := get_floor_normal()
    var on_slope := n.y < 0.97
    var h := Vector3(velocity.x, 0.0, velocity.z)
    if on_slope:
        h += Vector3(n.x, 0.0, n.z) * slope_gain * delta    # 下坡加速
    var spd := maxf(h.length() - slide_decel * delta, 0.0)
    if on_slope:
        spd = minf(spd, slope_max_speed)
    if h.length() > 0.01:
        var dir := h.normalized()
        if _wish_dir.length() > 0.1:
            dir = dir.slerp(_wish_dir, clampf(slide_steer * delta, 0.0, 1.0)).normalized()
        h = dir * spd
        velocity.x = h.x
        velocity.z = h.z

    var hold_required := not Game.is_mobile
    if spd < slide_min_speed or (_slide_t > slide_max_time and not on_slope) \
            or (hold_required and not _slide_held):
        state = State.GROUND
        _slide_cd = 0.4


# ---------- WALL RUN / WALL JUMP ----------
## 在左右两侧找一堵近似垂直的墙。返回 {} 或 {normal, side, point}
func _find_wall() -> Dictionary:
    var origin := global_position + Vector3.UP * 1.0
    var right := global_transform.basis.x
    var best := {}
    var best_d := 1e9
    for side: float in [-1.0, 1.0]:
        var hit := _ray(origin, origin + right * side * wall_check_dist)
        if hit.is_empty() or hit.collider is HitZone:
            continue
        var n: Vector3 = hit.normal
        if absf(n.y) > 0.25:
            continue
        var d := origin.distance_to(hit.position)
        if d < best_d:
            best_d = d
            best = {"normal": n, "side": side, "point": hit.position}
    return best


func _begin_wall_run(w: Dictionary) -> void:
    state = State.WALL_RUN
    _wall_normal = w.normal
    _wall_side = w.side
    _wall_run_t = 0.0
    velocity.y = maxf(velocity.y, 0.0) * 0.4


func _end_wall_run(cooldown: float) -> void:
    state = State.AIR
    _wall_cd = cooldown
    _wall_side = 0.0


func _tick_wall_run(delta: float) -> void:
    _wall_run_t += delta
    var origin := global_position + Vector3.UP * 1.0
    var hit := _ray(origin, origin - _wall_normal * (wall_check_dist + 0.35))
    var wall_ok := not hit.is_empty() and not (hit.collider is HitZone) and absf(hit.normal.y) <= 0.25
    if is_on_floor() or not wall_ok or _move_input.y < 0.0:
        _end_wall_run(0.25)
        return
    if _wall_run_t > wall_run_max_time + mod("wallrun_time", 0.0):
        _end_wall_run(0.6)
        return
    _wall_normal = hit.normal
    if _jump_pressed:
        _wall_jump(_wall_normal)
        return

    var flat_n := Vector3(_wall_normal.x, 0.0, _wall_normal.z).normalized()
    var along := flat_n.cross(Vector3.UP).normalized()
    if along.dot(-global_transform.basis.z) < 0.0:
        along = -along
    var spd := minf(maxf(_horizontal_speed(), wall_run_speed * 0.9 * mod("wallrun_speed")), wall_run_max_speed * mod("wallrun_speed"))
    var h := along * spd - flat_n * wall_stick      # 沿墙前进 + 轻微贴墙
    velocity.x = h.x
    velocity.z = h.z
    velocity.y = maxf(velocity.y - gravity * wall_gravity_scale * delta, -3.0)


func _wall_jump(n: Vector3) -> void:
    var flat_n := Vector3(n.x, 0.0, n.z).normalized()
    var fwd := Vector3(velocity.x, 0.0, velocity.z)
    velocity = fwd * 0.85 + flat_n * wall_jump_push
    velocity.y = wall_jump_up
    _wall_cd = 0.35
    _air_jumps = _max_air()
    _wall_side = 0.0
    state = State.AIR


# ---------- MANTLE（翻越 / 攀爬）----------
## 找面前可攀上的边缘。返回 {} 或 {dest, height}
func _find_ledge() -> Dictionary:
    var fwd := -global_transform.basis.z
    fwd.y = 0.0
    if fwd.length() < 0.01:
        return {}
    fwd = fwd.normalized()
    var feet := global_position
    var origin := feet + Vector3.UP * 0.45
    var hit := _ray(origin, origin + fwd * mantle_reach)
    if hit.is_empty() or hit.collider is HitZone:
        return {}
    var n: Vector3 = hit.normal
    if absf(n.y) > 0.3:
        return {}
    var inward := -Vector3(n.x, 0.0, n.z).normalized()
    var probe: Vector3 = hit.position + inward * 0.3
    var top := _ray(
        Vector3(probe.x, feet.y + mantle_max_height + 0.3, probe.z),
        Vector3(probe.x, feet.y + 0.2, probe.z))
    if top.is_empty() or top.normal.y < 0.7:
        return {}
    var tp: Vector3 = top.position
    var h := tp.y - feet.y
    if h < mantle_min_height or h > mantle_max_height:
        return {}
    if not _ray(tp + Vector3.UP * 0.05, tp + Vector3.UP * 1.9).is_empty():
        return {}                                   # 头顶没有净空
    var dest := tp + inward * 0.35 + Vector3.UP * 0.12
    if _capsule_blocked(dest):
        return {}                                   # 落脚点站不下
    return {"dest": dest, "height": h}


func _try_mantle() -> bool:
    if _mantle_cd > 0.0:
        return false
    var l := _find_ledge()
    if l.is_empty():
        return false
    state = State.MANTLE
    _mantle_from = global_position
    _mantle_to = l.dest
    _mantle_t = 0.0
    _mantle_dur = mantle_time + float(l.height) * 0.05
    var h := Vector3(velocity.x, 0.0, velocity.z)
    _mantle_keep = h.limit_length(sprint_speed) * 0.6    # 翻上去后保留部分动量
    velocity = Vector3.ZERO
    return true


func _tick_mantle(delta: float) -> void:
    _mantle_t += delta / _mantle_dur
    var t := clampf(_mantle_t, 0.0, 1.0)
    var up_t := smoothstep(0.0, 0.65, t)       # 先向上
    var fwd_t := smoothstep(0.35, 1.0, t)      # 再向前
    global_position = Vector3(
        lerpf(_mantle_from.x, _mantle_to.x, fwd_t),
        lerpf(_mantle_from.y, _mantle_to.y, up_t),
        lerpf(_mantle_from.z, _mantle_to.z, fwd_t))
    if _mantle_t >= 1.0:
        velocity = Vector3(_mantle_keep.x, 0.0, _mantle_keep.z)
        state = State.AIR
        _mantle_cd = 0.4
        _air_jumps = _max_air()


# ---------- GRAPPLE ----------
func _try_grapple() -> void:
    if _grapple_cd > 0.0:
        return
    var from := camera.global_position
    var dir := -camera.global_transform.basis.z
    var hit := _ray(from, from + dir * grapple_range)
    if hit.is_empty() or hit.collider is HitZone:
        _grapple_cd = 0.3           # 空放，短冷却
        return
    _grapple_point = hit.position
    _grapple_t = 0.0
    state = State.GRAPPLE


func _tick_grapple(delta: float) -> void:
    _grapple_t += delta
    var to_pt := _grapple_point - (global_position + Vector3.UP * 1.0)
    var dist := to_pt.length()
    if _jump_pressed or _grapple_pressed or dist < grapple_stop_dist or _grapple_t > grapple_max_time:
        if _jump_pressed:
            velocity.y = maxf(velocity.y, jump_velocity * 0.6)
        state = State.AIR
        _grapple_cd = grapple_cooldown
        _air_jumps = _max_air()
        return
    var dir := to_pt / dist
    velocity = velocity.move_toward(dir * grapple_speed, grapple_accel * delta)


func _update_rope() -> void:
    if state != State.GRAPPLE:
        if _rope.visible:
            _rope_mesh.clear_surfaces()
            _rope.visible = false
        return
    _rope.visible = true
    _rope_mesh.clear_surfaces()
    var start := camera.global_position + camera.global_transform.basis * Vector3(0.25, -0.25, -0.5)
    _rope_mesh.surface_begin(Mesh.PRIMITIVE_LINES)
    _rope_mesh.surface_add_vertex(start)
    _rope_mesh.surface_add_vertex(_grapple_point)
    _rope_mesh.surface_end()


# ---------- ZIPLINE ----------
func _try_zipline() -> bool:
    if _zip_cd > 0.0:
        return false
    var hand := global_position + Vector3.UP * zipline_hand_height
    var best_zip: Zipline = null
    var best_t := 0.0
    var best_d := zipline_reach
    for n in get_tree().get_nodes_in_group("zipline"):
        var z := n as Zipline
        if z == null:
            continue
        var info := z.nearest_point(hand)
        if float(info.dist) < best_d:
            best_d = float(info.dist)
            best_zip = z
            best_t = float(info.t)
    if best_zip == null:
        return false
    _zip = best_zip
    _zip_t = best_t
    # 方向: 朝下坡；水平缆线则朝面向的方向
    var dn := _zip.direction()
    var downhill := dn if dn.y < 0.0 else -dn
    if absf(dn.y) < 0.02:
        downhill = dn if dn.dot(-global_transform.basis.z) > 0.0 else -dn
    _zip_dir = 1.0 if downhill.dot(dn) > 0.0 else -1.0
    _zip_speed = maxf(_horizontal_speed() * 0.6, 6.0)
    velocity = Vector3.ZERO
    _zip_age = 0.0
    state = State.ZIPLINE
    return true


func _tick_zipline(delta: float) -> void:
    _zip_speed = move_toward(_zip_speed, _zip.speed, zipline_accel * delta)
    _zip_t += _zip_dir * _zip_speed * delta
    _zip_age += delta
    var along := _zip.direction() * _zip_dir
    var release := (_jump_pressed or _use_pressed) and _zip_age > 0.15
    if release or _zip_t <= 0.0 or _zip_t >= _zip.length():
        _zip_t = clampf(_zip_t, 0.0, _zip.length())
        global_position = _zip.point_at(_zip_t) - Vector3.UP * zipline_hand_height
        velocity = along * _zip_speed + Vector3.UP * (jump_velocity * 0.8 if _jump_pressed else 2.0)
        state = State.AIR
        _zip_cd = 0.6
        _air_jumps = _max_air()
        return
    global_position = _zip.point_at(_zip_t) - Vector3.UP * zipline_hand_height
    velocity = along * _zip_speed     # 仅用于 FOV/调试显示；不调用 move_and_slide


# ---------- 第三人称 ----------
func _update_third_person(delta: float) -> void:
    if puppet == null:
        return
    if not third_person:
        return
    # 相机拉到角色右后方，被墙挡住时往前收
    var from := head.global_position
    var want := head.global_transform * Vector3(0.45, 0.15, 2.8)
    var hit := _ray(from, want)
    var cam_pos := want
    if not hit.is_empty():
        cam_pos = hit.position + hit.normal * 0.2
    camera.global_position = camera.global_position.lerp(cam_pos, 1.0 - exp(-20.0 * delta))

    # 同步 Puppet（Puppet 放在脚底，跟随玩家朝向）
    puppet.speed = _horizontal_speed()
    puppet.vel_local = global_transform.basis.inverse() * velocity
    puppet.aim_pitch = pitch
    puppet.ads = weapon.ads_t if weapon != null else 0.0
    puppet.wall_side = _wall_side
    puppet.grapple_dir = global_transform.basis.inverse() * (_grapple_point - head.global_position)
    match state:
        State.SLIDE:
            puppet.pose = "slide"
        State.WALL_RUN:
            puppet.pose = "wall_run"
        State.MANTLE:
            puppet.pose = "mantle"
        State.GRAPPLE:
            puppet.pose = "grapple"
        State.ZIPLINE:
            puppet.pose = "zipline"
        State.AIR:
            puppet.pose = "air"
        _:
            puppet.pose = "move" if _horizontal_speed() > 0.5 else "idle"


# ---------- 战斗 / 生命 ----------
func ray_exclude() -> Array[RID]:
    return _exclude


func current_weapon_name() -> String:
    if kill_label != "":
        return kill_label
    return weapon.data.display_name if weapon != null and weapon.data != null else ""


## 死亡/倒计时/赛后: 不响应输入，只受重力
func _tick_inactive(delta: float) -> void:
    if not is_on_floor():
        velocity.y -= gravity * delta
    velocity.x = move_toward(velocity.x, 0.0, 30.0 * delta)
    velocity.z = move_toward(velocity.z, 0.0, 30.0 * delta)
    move_and_slide()
    _emit_debug(delta)


## 返回是否被这次伤害击杀
func take_damage(amount: float, attacker: Node = null, is_head := false) -> bool:
    if not alive or spawn_protect > 0.0:
        return false
    amount *= 1.0 - clampf(mod("dmg_reduction", 0.0), 0.0, 0.9)
    health -= amount
    _since_damage = 0.0
    _notify("player_health", [maxf(health, 0.0), max_health])
    if attacker is Node3D:
        var to := (attacker as Node3D).global_position - global_position
        var local := global_transform.basis.inverse() * to
        _notify("player_damaged", [atan2(local.x, -local.z)])
    if health <= 0.0:
        _die(attacker, is_head)
        return true
    return false


func _die(attacker: Node, is_head: bool) -> void:
    alive = false
    health = 0.0
    HitZone.set_zones_enabled(_zones, false)
    if state == State.GRAPPLE or state == State.ZIPLINE or state == State.MANTLE:
        state = State.AIR
    _touch_ads = false
    set_third_person(true)           # 死亡视角: 第三人称看着自己倒下
    puppet.pose = "idle"
    puppet.die()
    var an := String(attacker.get("display_name")) if attacker != null else ""
    var wn := String(attacker.call("current_weapon_name")) if attacker != null and attacker.has_method("current_weapon_name") else ""
    _notify("player_died", [an, wn])
    died.emit(self, attacker, is_head)


## 在指定位置朝向重生。protect = 出生保护秒数
func respawn_at(xf: Transform3D, protect := 2.0) -> void:
    global_position = xf.origin
    yaw = xf.basis.get_euler().y
    pitch = 0.0
    rotation.y = yaw
    velocity = Vector3.ZERO
    state = State.AIR
    alive = true
    health = max_health
    spawn_protect = protect
    _since_damage = 99.0
    HitZone.set_zones_enabled(_zones, true)
    puppet.revive()
    set_third_person(false)
    if ability_ctl != null:
        ability_ctl.call("on_respawn")
    if weapon != null:
        weapon.reset_ammo()
    _notify("player_health", [health, max_health])
    _notify("respawn_timer", [0.0])
    _notify("respawn", [global_position, yaw])      # 联网: 通知客户端传送


# ---------- 联网辅助 ----------
func _notify(sig: String, args: Array) -> void:
    if net_notify.is_valid():
        net_notify.call(sig, args)
    elif net_role != "server" and EventBus.has_signal(sig):
        EventBus.callv("emit_signal", [sig] + args)


## 命中确认（Ballistics 调用）: 联网时转发给射手本人的客户端
func notify_hit(is_head: bool, killed: bool) -> void:
    _notify("hit_confirmed", [is_head, killed])


func get_last_frame() -> Array:
    return _last_frame


func apply_net_frame(f: Array) -> void:
    net_frame = f


func _poll_from_net(extras: bool) -> void:
    if net_frame.size() < 7:
        _move_input = Vector2.ZERO
        _wish_dir = Vector3.ZERO
        _wish_mag = 0.0
        _sprinting = false
        _jump_pressed = false
        _slide_pressed = false
        _slide_held = false
        _grapple_pressed = false
        _use_pressed = false
        net_buttons = 0
        return
    var bits := int(net_frame[5])
    net_buttons = bits
    _move_input = Vector2(clampf(float(net_frame[1]), -1.0, 1.0), clampf(float(net_frame[2]), -1.0, 1.0)).limit_length(1.0)
    yaw = float(net_frame[3])
    pitch = clampf(float(net_frame[4]), -MAX_PITCH, MAX_PITCH)
    net_render_time = float(net_frame[6])
    rotation.y = yaw
    if head != null:
        head.rotation.x = pitch
    var dir := global_transform.basis * Vector3(_move_input.x, 0.0, -_move_input.y)
    dir.y = 0.0
    _wish_dir = dir.normalized()
    _wish_mag = _move_input.length()
    _sprinting = (bits & B_SPRINT) != 0
    _jump_pressed = (bits & B_JUMP) != 0
    _slide_pressed = (bits & B_SLIDE) != 0
    _slide_held = (bits & B_SLIDE_HELD) != 0
    _grapple_pressed = (bits & B_GRAPPLE) != 0
    _use_pressed = (bits & B_USE) != 0
    if extras:
        if (bits & B_RELOAD) != 0:
            _reload_edge = true
        if (bits & B_SWAP) != 0:
            _cycle_weapon()
        if (bits & B_SCOPE) != 0 and weapon != null:
            weapon.cycle_sight()


## 客户端预测回放: 用服务器确认后的状态重放尚未确认的输入帧
func net_replay(frame: Array, delta: float) -> void:
    var y0 := yaw
    var p0 := pitch
    var prev := net_ctl
    _replaying = true
    net_ctl = true
    net_frame = frame
    _poll_from_net(false)
    _sim_step(delta)
    net_ctl = prev
    _replaying = false
    yaw = y0
    pitch = p0
    rotation.y = yaw
    if head != null:
        head.rotation.x = pitch


func net_apply_state(pos: Vector3, vel: Vector3) -> void:
    global_position = pos
    velocity = vel


## 客户端: 服务器判定我死了（只改状态，事件由服务器单独转发）
func net_set_dead() -> void:
    if not alive:
        return
    alive = false
    health = 0.0
    HitZone.set_zones_enabled(_zones, false)
    if state == State.GRAPPLE or state == State.ZIPLINE or state == State.MANTLE:
        state = State.AIR
    _touch_ads = false
    set_third_person(true)
    puppet.pose = "idle"
    puppet.die()


# ---------- 干员属性 / 辅助瞄准 ----------
func mod(key: String, default := 1.0) -> float:
    return float(ability_mods.get(key, default))


func _max_air() -> int:
    return max_air_jumps + int(mod("air_jumps", 0.0))


## 移动意图方向（没有输入时取面向方向）
func wish_direction() -> Vector3:
    var d := _wish_dir
    if d.length() < 0.1:
        d = -global_transform.basis.z
        d.y = 0.0
    return d.normalized()


func _assist_check() -> void:
    _assist_slow = false
    if touch == null or Settings.aim_assist <= 0.0 or not alive or camera == null:
        return
    var from := camera.global_position
    var q := PhysicsRayQueryParameters3D.create(from, from + (-camera.global_transform.basis.z) * 70.0)
    q.collision_mask = 5
    q.exclude = _exclude
    var hit := get_world_3d().direct_space_state.intersect_ray(q)
    if not hit.is_empty() and hit.collider is HitZone:
        var tgt: Node = (hit.collider as HitZone).target
        if tgt != null and tgt.get("team") != null and int(tgt.get("team")) != team:
            _assist_slow = true
