class_name ImpactFx
extends RefCounted
## 命中特效（按表面材质区分）、弹孔贴花、抛壳。
## 表面材质来自障碍物上的 meta "surface": concrete / wood / metal；HitZone 视为 flesh。
## 所有实例都有数量上限与寿命，避免移动端内存/Draw call 失控。

const MAX_DECALS := 24
const MAX_SHELLS := 20

static var _decals: Array = []
static var _shells: Array = []
static var _decal_tex: ImageTexture


static func _surface_color(surface: String) -> Color:
    match surface:
        "wood":
            return Color("c9a06a")
        "metal":
            return Color("ffb347")
        "flesh":
            return Color("c4302b")
        _:
            return Color("b8bcc0")


## 命中点: 粒子 + 弹孔（肉体没有弹孔）
static func impact(root: Node, pos: Vector3, normal: Vector3, surface: String) -> void:
    var p := CPUParticles3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = 0.012
    mesh.height = 0.024
    mesh.radial_segments = 4
    mesh.rings = 2
    var m := StandardMaterial3D.new()
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.albedo_color = _surface_color(surface)
    mesh.material = m
    p.mesh = mesh
    p.amount = maxi(2, int((10 if surface != "metal" else 14) * Settings.fx_mult()))
    p.lifetime = 0.35
    p.one_shot = true
    p.explosiveness = 1.0
    p.direction = normal
    p.spread = 40.0
    p.initial_velocity_min = 1.5
    p.initial_velocity_max = 4.0 if surface == "metal" else 3.0
    p.gravity = Vector3(0, -9.0 if surface != "metal" else -3.0, 0)
    root.add_child(p)
    p.global_position = pos + normal * 0.02
    p.emitting = true
    root.get_tree().create_timer(0.8).timeout.connect(p.queue_free)

    if surface != "flesh":
        _spawn_decal(root, pos, normal)


static func _spawn_decal(root: Node, pos: Vector3, normal: Vector3) -> void:
    if _decal_tex == null:
        var img := Image.create(32, 32, false, Image.FORMAT_RGBA8)
        img.fill(Color(0, 0, 0, 0))
        for y in 32:
            for x in 32:
                var d := Vector2(x - 15.5, y - 15.5).length() / 15.5
                if d < 1.0:
                    img.set_pixel(x, y, Color(0.04, 0.04, 0.04, (1.0 - d) * 0.9))
        _decal_tex = ImageTexture.create_from_image(img)
    # 回收最老的
    while _decals.size() >= MAX_DECALS:
        var old = _decals.pop_front()
        if is_instance_valid(old):
            old.queue_free()
    var d := Decal.new()
    d.texture_albedo = _decal_tex
    d.size = Vector3(0.22, 0.4, 0.22)    # y 是投射深度
    root.add_child(d)
    var tangent := normal.cross(Vector3.UP)
    if tangent.length() < 0.05:
        tangent = normal.cross(Vector3.RIGHT)
    tangent = tangent.normalized()
    d.global_transform = Transform3D(Basis(tangent, normal, tangent.cross(normal)), pos + normal * 0.01)
    _decals.append(d)


## 抛壳: 小刚体，不参与射线检测（collision_layer = 0），只与场景碰撞
static func eject_shell(root: Node, from: Transform3D, brass := true) -> void:
    while _shells.size() >= MAX_SHELLS:
        var old = _shells.pop_front()
        if is_instance_valid(old):
            old.queue_free()
    var rb := RigidBody3D.new()
    rb.collision_layer = 0
    rb.collision_mask = 1
    rb.mass = 0.02
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = Vector3(0.012, 0.012, 0.035)
    cs.shape = bs
    rb.add_child(cs)
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = bs.size
    mi.mesh = bm
    var m := StandardMaterial3D.new()
    m.albedo_color = Color("c99a3a") if brass else Color("b03030")
    m.metallic = 0.8
    m.roughness = 0.35
    mi.material_override = m
    rb.add_child(mi)
    root.add_child(rb)
    rb.global_transform = from
    var right := from.basis.x
    var up := from.basis.y
    rb.linear_velocity = right * randf_range(1.8, 2.8) + up * randf_range(1.2, 2.0) + from.basis.z * randf_range(0.0, 0.6)
    rb.angular_velocity = Vector3(randf_range(-20, 20), randf_range(-20, 20), randf_range(-20, 20))
    _shells.append(rb)
    root.get_tree().create_timer(2.0).timeout.connect(rb.queue_free)
