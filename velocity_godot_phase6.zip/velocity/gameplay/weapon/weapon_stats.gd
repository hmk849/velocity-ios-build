class_name WeaponStats
extends RefCounted
## 把武器基础数据 + 配件乘数合成为最终参数。
## Weapon 运行时和改装界面共用，保证"界面上看到的 = 实际生效的"。

static func compute(d: WeaponData, atts: Array[AttachmentData]) -> Dictionary:
    var s := {
        "damage_mult": 1.0, "range_mult": 1.0, "recoil_mult": 1.0,
        "hip_spread_mult": 1.0, "ads_time_mult": 1.0, "reload_mult": 1.0,
        "move_mult": 1.0, "bullet_speed_mult": 1.0, "mag_size": d.magazine_size,
        "zoom": 1.0, "reticle": "iron", "sight_name": "",
    }
    for a in atts:
        s["damage_mult"] = float(s["damage_mult"]) * a.damage_mult
        s["range_mult"] = float(s["range_mult"]) * a.range_mult
        s["recoil_mult"] = float(s["recoil_mult"]) * a.recoil_mult
        s["hip_spread_mult"] = float(s["hip_spread_mult"]) * a.hip_spread_mult
        s["ads_time_mult"] = float(s["ads_time_mult"]) * a.ads_time_mult
        s["reload_mult"] = float(s["reload_mult"]) * a.reload_mult
        s["move_mult"] = float(s["move_mult"]) * a.move_mult
        s["bullet_speed_mult"] = float(s["bullet_speed_mult"]) * a.bullet_speed_mult
        s["mag_size"] = int(s["mag_size"]) + a.mag_bonus
        if a.slot == AttachmentData.Slot.SIGHT:
            s["zoom"] = a.zoom
            s["reticle"] = a.reticle
            s["sight_name"] = a.display_name
    return s


## 该武器当前应装备的配件: 默认配件 → 被 Loadout 覆盖；瞄具取 Loadout 选择，否则第一个可选瞄具。
static func equipped_attachments(d: WeaponData) -> Array[AttachmentData]:
    var chosen: Dictionary = {}
    for p in d.default_attachment_paths:
        var a := load(p) as AttachmentData
        if a != null:
            chosen[a.slot] = a
    if Loadout.has_custom(d.id):
        for slot in range(1, 7):
            var c: Variant = Loadout.get_choice(d.id, slot)
            if c == null:
                continue
            if String(c) == "":
                chosen.erase(slot)
            else:
                var a2 := load(String(c)) as AttachmentData
                if a2 != null:
                    chosen[slot] = a2
    var out: Array[AttachmentData] = []
    for a in chosen.values():
        out.append(a)
    var sight: AttachmentData = null
    var sc: Variant = Loadout.get_choice(d.id, AttachmentData.Slot.SIGHT)
    if sc != null:
        var sp := String(sc) if String(sc) != "" else WeaponCatalog.attachment_path("iron_sight")
        sight = load(sp) as AttachmentData
    elif d.sight_option_paths.size() > 0:
        sight = load(d.sight_option_paths[0]) as AttachmentData
    if sight != null:
        out.append(sight)
    return out


## 不读玩家配置的默认配装（机器人/远端角色用）: 默认配件 + 第一个可选瞄具
static func default_attachments(d: WeaponData) -> Array[AttachmentData]:
    var out: Array[AttachmentData] = []
    for p in d.default_attachment_paths:
        var a := load(p) as AttachmentData
        if a != null:
            out.append(a)
    if d.sight_option_paths.size() > 0:
        var s := load(d.sight_option_paths[0]) as AttachmentData
        if s != null:
            out.append(s)
    return out
