class_name GunModel
extends Node3D
## 程序化(占位)枪模: 用方块拼出机匣/枪管/护木/枪机/弹匣/握把/枪托/瞄具/配件，
## 并提供机械动画: 枪机往复、泵动/拉机柄、弹匣拆装(战术/空仓)、检查弹匣、检视。
## 原点在机匣尾部，枪管朝 -Z。第一人称、第三人称、大厅、改装界面共用。
## 这是占位模型，不是美术成品；换成真实 .glb 时保留同名挂点即可。
##
## 挂点: muzzle / eject_port / grip_point(右手) / fore_point(左手) / mag_point / scope_lens_anchor
## 所有网格放在第 2 渲染层，倍镜 PiP 相机只渲染第 1 层，避免镜内出现自己的枪。

var data: WeaponData
var bolt: Node3D
var mag: Node3D
var muzzle: Marker3D
var eject_port: Marker3D
var grip_point: Marker3D
var fore_point: Marker3D
var mag_point: Marker3D
var scope_lens_anchor: Node3D
var stock: Node3D            # 开镜时隐藏，避免挡住下方视野
var sight_height := 0.08      # 光轴相对枪尾原点的高度（ADS 时对齐到屏幕中心）
var length := 0.7

var _mag_base := Vector3.ZERO
var _bolt_base := Vector3.ZERO
var _bolt_tween: Tween
var _mag_tween: Tween
var _inspect_tween: Tween
var _mats: Dictionary = {}


func build(d: WeaponData, atts: Array[AttachmentData]) -> void:
    cancel_anims()
    for c in get_children():
        remove_child(c)
        c.queue_free()
    _mats.clear()
    bolt = null
    mag = null
    scope_lens_anchor = null
    stock = null
    data = d

    var L := d.viewmodel_size.z
    length = L
    var cat := d.category
    var pistol := cat == "PISTOL"
    var body := d.viewmodel_color
    var dark := body.darkened(0.45)
    var accent := body.lightened(0.12)
    var rl := L * (0.62 if pistol else 0.5)          # 机匣长度
    var rh := 0.05 if pistol else 0.085              # 机匣高度
    var top := 0.055 if pistol else rh * 0.5         # 上表面高度

    # ---- 读取配件 ----
    var barrel_scale := 1.0
    var mag_scale := 1.0
    var muzzle_dev := false
    var vgrip := false
    var laser := false
    var sight: AttachmentData = null
    for a in atts:
        match a.slot:
            AttachmentData.Slot.SIGHT:
                sight = a
            AttachmentData.Slot.MUZZLE:
                muzzle_dev = true
            AttachmentData.Slot.BARREL:
                barrel_scale = 1.18 if a.range_mult >= 1.0 else 0.85
            AttachmentData.Slot.GRIP:
                vgrip = true
            AttachmentData.Slot.MAGAZINE:
                mag_scale = 1.35
            AttachmentData.Slot.LASER:
                laser = true

    # ---- 机匣 / 枪管 / 护木 ----
    _box(self, Vector3(0.05 if pistol else 0.055, rh, rl), Vector3(0, 0, -rl * 0.5), body, "receiver", 0.3)
    var barrel_len := (L - rl) * barrel_scale
    _box(self, Vector3(0.022, 0.022, barrel_len), Vector3(0, 0.012, -rl - barrel_len * 0.5), dark, "barrel", 0.9)
    if not pistol:
        _box(self, Vector3(0.05, 0.05, barrel_len * 0.5), Vector3(0, 0.0, -rl - barrel_len * 0.3), accent, "handguard", 0.2)

    # ---- 枪机 / 套筒 / 泵动护木 ----
    bolt = Node3D.new()
    bolt.name = "bolt"
    add_child(bolt)
    match cat:
        "PISTOL":
            bolt.position = Vector3(0, 0.035, -L * 0.45)
            _box(bolt, Vector3(0.048, 0.04, L * 0.9), Vector3.ZERO, accent, "slide", 0.6)
        "SHOTGUN":
            bolt.position = Vector3(0, -0.04, -rl - barrel_len * 0.35)
            _box(bolt, Vector3(0.05, 0.04, 0.14), Vector3.ZERO, Color("6b4a30"), "pump", 0.0)
            _box(self, Vector3(0.026, 0.026, barrel_len * 0.8), Vector3(0, -0.03, -rl - barrel_len * 0.45), dark, "tube", 0.8)
        "SNIPER":
            bolt.position = Vector3(0, 0.03, -rl * 0.35)
            _box(bolt, Vector3(0.04, 0.03, rl * 0.4), Vector3.ZERO, accent, "bolt", 0.6)
            _box(bolt, Vector3(0.035, 0.012, 0.012), Vector3(0.035, 0, 0.04), dark, "handle", 0.5)
        _:
            bolt.position = Vector3(0, 0.05, -rl * 0.35)
            _box(bolt, Vector3(0.04, 0.026, rl * 0.4), Vector3.ZERO, accent, "bolt", 0.6)
    _bolt_base = bolt.position

    # ---- 弹匣 ----
    var heights := {"AR": 0.13, "SMG": 0.17, "LMG": 0.13, "DMR": 0.12, "SNIPER": 0.06, "PISTOL": 0.1}
    var mag_h: float = float(heights.get(cat, 0.0)) * mag_scale
    if mag_h > 0.0:
        mag = Node3D.new()
        mag.name = "mag"
        mag.position = Vector3(0, -rh * 0.5 - mag_h * 0.5, -rl * 0.6)
        var mw := Vector3(0.06, mag_h, 0.1) if cat == "LMG" else Vector3(0.036, mag_h, 0.055)
        _box(mag, mw, Vector3.ZERO, dark, "mag", 0.3)
        add_child(mag)
        _mag_base = mag.position

    # ---- 握把 / 枪托 ----
    var grip := _box(self, Vector3(0.042, 0.1 if pistol else 0.09, 0.05 if pistol else 0.045),
        Vector3(0, -rh * 0.5 - (0.04 if pistol else 0.035), -0.025), dark, "grip", 0.1)
    grip.rotation_degrees.x = -15.0
    if not pistol:
        var sl := 0.28 if cat == "SNIPER" else (0.14 if cat == "SMG" else 0.2)
        stock = _box(self, Vector3(0.045, 0.075, sl), Vector3(0, -0.01, sl * 0.5), body.darkened(0.2), "stock", 0.1)

    # ---- 瞄具 ----
    var zoom := sight.zoom if sight != null else 1.0
    var reticle := sight.reticle if sight != null else "iron"
    if zoom >= 2.0:
        var tube_len := 0.18 + zoom * 0.02
        var ty := top + 0.055
        var tz := -rl * 0.45
        _box(self, Vector3(0.02, 0.04, 0.06), Vector3(0, top + 0.02, tz), dark, "scope_mount", 0.8)
        _cyl(self, 0.026, tube_len, Vector3(0, ty, tz), dark, "scope_tube")
        _cyl(self, 0.034, 0.05, Vector3(0, ty, tz + tube_len * 0.5 - 0.02), dark, "scope_eye")
        _cyl(self, 0.036, 0.05, Vector3(0, ty, tz - tube_len * 0.5 + 0.02), dark, "scope_obj")
        scope_lens_anchor = Node3D.new()
        scope_lens_anchor.name = "scope_lens_anchor"
        scope_lens_anchor.position = Vector3(0, ty, tz + tube_len * 0.5 + 0.006)
        add_child(scope_lens_anchor)
        sight_height = ty
    elif reticle == "red_dot" or reticle == "holo":
        # 空心镜框: 底座 + 左右上三条细边围出窗口，窗口里只有几乎透明的玻璃，不挡视线
        var hz := -rl * 0.3
        var cy := top + 0.05
        _box(self, Vector3(0.03, 0.012, 0.05), Vector3(0, top + 0.006, hz), dark, "optic_base", 0.6)
        _box(self, Vector3(0.006, 0.05, 0.05), Vector3(-0.022, cy, hz), dark, "optic_l", 0.6)
        _box(self, Vector3(0.006, 0.05, 0.05), Vector3(0.022, cy, hz), dark, "optic_r", 0.6)
        _box(self, Vector3(0.05, 0.006, 0.05), Vector3(0, cy + 0.028, hz), dark, "optic_top", 0.6)
        var glass := _box(self, Vector3(0.038, 0.044, 0.002), Vector3(0, cy, hz - 0.02), Color(0.5, 0.8, 1.0, 0.1), "optic_glass", 0.0)
        var gm := glass.material_override as StandardMaterial3D
        gm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        sight_height = cy
    else:
        _box(self, Vector3(0.01, 0.02, 0.01), Vector3(-0.012, top + 0.01, -rl * 0.15), dark, "rear_l", 0.7)
        _box(self, Vector3(0.01, 0.02, 0.01), Vector3(0.012, top + 0.01, -rl * 0.15), dark, "rear_r", 0.7)
        _box(self, Vector3(0.008, 0.03, 0.008), Vector3(0, top + 0.015, -(rl + barrel_len * 0.9)), dark, "front_post", 0.7)
        sight_height = top + 0.022

    # ---- 其它配件 ----
    var tip := -(rl + barrel_len)
    if muzzle_dev:
        _box(self, Vector3(0.034, 0.034, 0.07), Vector3(0, 0.012, tip - 0.03), dark, "muzzle_dev", 0.9)
        tip -= 0.065
    if vgrip:
        _box(self, Vector3(0.026, 0.075, 0.03), Vector3(0, -0.075, -rl - barrel_len * 0.35), dark, "vgrip", 0.1)
    if laser:
        _box(self, Vector3(0.02, 0.02, 0.045), Vector3(0.03, -0.015, -rl - barrel_len * 0.2), dark, "laser", 0.5)
        var led := _box(self, Vector3(0.006, 0.006, 0.004), Vector3(0.03, -0.015, -rl - barrel_len * 0.2 - 0.025), Color.RED, "laser_led", 0.0)
        var lm := led.material_override as StandardMaterial3D
        lm.emission_enabled = true
        lm.emission = Color.RED

    # ---- 挂点 ----
    muzzle = _marker("muzzle", Vector3(0, 0.012, tip - 0.01))
    eject_port = _marker("eject_port", Vector3(0.03, 0.03, -rl * 0.35))
    grip_point = _marker("grip_point", Vector3(0, -rh * 0.5 - 0.05, -0.02))
    var fz := -0.07 if pistol else (-rl - barrel_len * 0.3)
    fore_point = _marker("fore_point", Vector3(0, -0.045, fz))
    mag_point = _marker("mag_point", Vector3(0, -rh * 0.5 - maxf(mag_h, 0.05), -rl * 0.6))


func _marker(nm: String, pos: Vector3) -> Marker3D:
    var m := Marker3D.new()
    m.name = nm
    m.position = pos
    add_child(m)
    return m


func _mat(color: Color, metallic: float) -> StandardMaterial3D:
    var key := "%s_%.2f" % [color.to_html(), metallic]
    if not _mats.has(key):
        var m := StandardMaterial3D.new()
        m.albedo_color = color
        m.metallic = metallic
        m.roughness = 0.5
        _mats[key] = m
    return _mats[key]


func _box(parent: Node3D, size: Vector3, pos: Vector3, color: Color, nm: String, metallic := 0.2) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.name = nm
    mi.position = pos
    mi.material_override = _mat(color, metallic)
    mi.layers = 2
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(mi)
    return mi


## 沿 Z 轴的圆柱
func _cyl(parent: Node3D, radius: float, h: float, pos: Vector3, color: Color, nm: String) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = radius
    cm.bottom_radius = radius
    cm.height = h
    cm.radial_segments = 12
    cm.rings = 1
    mi.mesh = cm
    mi.name = nm
    mi.position = pos
    mi.rotation_degrees = Vector3(90, 0, 0)
    mi.material_override = _mat(color, 0.7)
    mi.layers = 2
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(mi)
    return mi


# ---------- 机械动画 ----------
func _kill(tw: Tween) -> void:
    if tw != null and tw.is_valid():
        tw.kill()


func cancel_anims() -> void:
    _kill(_bolt_tween)
    _kill(_mag_tween)
    _kill(_inspect_tween)
    rotation = Vector3.ZERO
    if bolt != null:
        bolt.position = _bolt_base
    if mag != null:
        mag.position = _mag_base
        mag.visible = true


func cancel_inspect() -> void:
    _kill(_inspect_tween)
    rotation = Vector3.ZERO


## 开火: 自动/半自动枪的枪机/套筒往复；栓动/泵动走 anim_cycle
func anim_fire(cooldown: float) -> void:
    if bolt == null or data == null:
        return
    if data.bolt_action:
        anim_cycle(0.25, clampf(cooldown - 0.35, 0.3, 0.9))
        return
    if data.category == "SHOTGUN":
        anim_cycle(0.12, 0.35)
        return
    _kill(_bolt_tween)
    bolt.position = _bolt_base + Vector3(0, 0, 0.06 if data.category == "PISTOL" else 0.045)
    _bolt_tween = create_tween()
    _bolt_tween.tween_property(bolt, "position", _bolt_base, minf(cooldown * 0.8, 0.08))


## 拉机柄 / 泵动一次
func anim_cycle(delay: float, dur: float) -> void:
    if bolt == null:
        return
    var back := 0.12 if data.bolt_action else 0.08
    var side := 0.03 if data.bolt_action else 0.0
    _kill(_bolt_tween)
    _bolt_tween = create_tween()
    _bolt_tween.tween_interval(delay)
    _bolt_tween.tween_property(bolt, "position", _bolt_base + Vector3(side, 0, back), dur * 0.45).set_ease(Tween.EASE_OUT)
    _bolt_tween.tween_property(bolt, "position", _bolt_base, dur * 0.55)


## 换弹: 弹匣下掉 → 隐藏 → 新弹匣从下方推入 →（空仓才）拉枪机。
## 泵动霰弹枪没有弹匣，改为反复泵动模拟装填。
func anim_reload(total: float, empty: bool) -> void:
    cancel_inspect()
    _kill(_mag_tween)
    if mag == null:
        if bolt != null:
            _kill(_bolt_tween)
            _bolt_tween = create_tween()
            for i in 3:
                _bolt_tween.tween_property(bolt, "position", _bolt_base + Vector3(0, 0, 0.08), total * 0.12)
                _bolt_tween.tween_property(bolt, "position", _bolt_base, total * 0.12)
        return
    var below := _mag_base + Vector3(0.0, -0.22, 0.02)
    _mag_tween = create_tween()
    _mag_tween.tween_property(mag, "position", below, total * 0.22).set_ease(Tween.EASE_IN)
    _mag_tween.tween_callback(_set_mag_visible.bind(false))
    _mag_tween.tween_interval(total * 0.18)
    _mag_tween.tween_callback(_mag_to_below)
    _mag_tween.tween_property(mag, "position", _mag_base, total * 0.24).set_ease(Tween.EASE_OUT)
    if empty and bolt != null:
        _mag_tween.tween_interval(total * 0.06)
        _mag_tween.tween_property(bolt, "position", _bolt_base + Vector3(0, 0, 0.07), total * 0.07)
        _mag_tween.tween_property(bolt, "position", _bolt_base, total * 0.06)


func _set_mag_visible(v: bool) -> void:
    if mag != null:
        mag.visible = v


func _mag_to_below() -> void:
    if mag != null:
        mag.position = _mag_base + Vector3(0.0, -0.22, 0.02)
        mag.visible = true


## 大厅待机: 弹匣滑出一半再推回
func anim_check_mag() -> void:
    if mag == null:
        return
    _kill(_mag_tween)
    _mag_tween = create_tween()
    _mag_tween.tween_property(mag, "position", _mag_base + Vector3(0, -0.07, 0), 0.5)
    _mag_tween.tween_interval(0.7)
    _mag_tween.tween_property(mag, "position", _mag_base, 0.35)


## 检视: 枪身翻转展示，拉一下枪机，回正
func anim_inspect() -> void:
    _kill(_inspect_tween)
    _inspect_tween = create_tween()
    _inspect_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    _inspect_tween.tween_property(self, "rotation", Vector3(0.25, 0.9, -0.5), 0.6)
    _inspect_tween.tween_property(self, "rotation", Vector3(-0.2, -0.7, 0.5), 0.9)
    _inspect_tween.tween_callback(anim_fire.bind(0.3))
    _inspect_tween.tween_property(self, "rotation", Vector3.ZERO, 0.6)
