class_name Bot
extends CharacterBody3D
## 对局机器人（Phase 4）: 导航网格寻路 + 视野/视线感知 + 反应延迟 + 瞄准误差 + 点射节奏 + 走位。
## 角色外观用 Puppet（带队伍色），命中区域与玩家相同，所以玩家的子弹对它们完全一样。
## 机器人一律走 hitscan（不用弹丸）；难度通过 反应时间/瞄准误差/伤害系数/移速 调节。
## 联网时机器人只在服务器上运行（Phase 5）。

signal died(victim: Node, attacker: Node, is_head: bool)

enum S { ROAM, ENGAGE, SEARCH }

const GRAVITY := 24.0
const EYE_H := 1.6
const VISION_RANGE := 80.0
const PREFERRED_RANGE := {"SMG": 12.0, "AR": 22.0, "LMG": 28.0, "SHOTGUN": 7.0, "DMR": 35.0, "PISTOL": 14.0, "SNIPER": 50.0}

var team := 1
var display_name := "BOT"
var health := 100.0
var max_health := 100.0
var alive := true
var enabled := true
var spawn_protect := 0.0
var data: WeaponData
var skill := {"react": 0.4, "aim": 3.5, "dmg": 0.8, "speed": 5.5}
var pois: Array = []                 # Array[Vector3]
var team_color := Color("ff7a1a")
var slow_until := 0.0          # 被减速场/暗域影响
var slow_factor := 1.0

var puppet: Puppet
var nav: NavigationAgent3D

var _state := S.ROAM
var _target: Node3D = null
var _last_seen := Vector3.ZERO
var _goal := Vector3.ZERO
var _wait_t := 0.0
var _search_t := 0.0
var _lost_t := 0.0
var _alert_t := 0.0
var _scan_t := 0.0
var _repath_t := 0.0
var _react_t := 0.0
var _cooldown := 0.0
var _burst_left := 0
var _pause_t := 0.0
var _ammo := 30
var _reload_t := 0.0
var _strafe_dir := 1.0
var _strafe_t := 0.0
var _yaw := 0.0
var _desired_yaw := 0.0
var _pitch := 0.0
var _stuck_t := 0.0
var _stuck_pos := Vector3.ZERO
var _rng := RandomNumberGenerator.new()
var _zones: Array[HitZone] = []
var _exclude: Array[RID] = []


## 难度: 0 简单 / 1 普通 / 2 困难
static func skill_for(level: int) -> Dictionary:
    match level:
        0:
            return {"react": 0.65, "aim": 6.0, "dmg": 0.6, "speed": 5.0}
        2:
            return {"react": 0.22, "aim": 2.0, "dmg": 1.0, "speed": 6.0}
        _:
            return {"react": 0.4, "aim": 3.5, "dmg": 0.8, "speed": 5.5}


func setup(p_team: int, p_name: String, weapon: WeaponData, p_skill: Dictionary, p_pois: Array, p_color: Color) -> void:
    team = p_team
    display_name = p_name
    data = weapon
    skill = p_skill
    pois = p_pois
    team_color = p_color


func _ready() -> void:
    _rng.randomize()
    collision_layer = 2
    collision_mask = 1
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.4
    cap.height = 1.8
    cs.shape = cap
    cs.position.y = 0.9
    add_child(cs)

    _zones = HitZone.add_humanoid_zones(self, self)
    _exclude = [get_rid()]
    for z in _zones:
        _exclude.append(z.get_rid())
    add_to_group("combatants")

    nav = NavigationAgent3D.new()
    nav.path_desired_distance = 1.2
    nav.target_desired_distance = 1.8
    nav.radius = 0.5
    nav.height = 1.8
    nav.avoidance_enabled = false
    add_child(nav)

    puppet = Puppet.new()
    add_child(puppet)
    puppet.set_team_color(team_color)
    puppet.set_weapon(data, WeaponStats.default_attachments(data))
    _ammo = data.magazine_size
    _stuck_pos = global_position


func net_pitch() -> float:
    return _pitch


func current_weapon_name() -> String:
    return data.display_name if data != null else ""


# ---------- 生命 ----------
func take_damage(amount: float, attacker: Node = null, is_head := false) -> bool:
    if not alive or spawn_protect > 0.0:
        return false
    health -= amount
    _alert_t = 3.0
    puppet.flinch()
    if attacker is Node3D:
        _last_seen = (attacker as Node3D).global_position
        if _state == S.ROAM:
            _state = S.SEARCH
            _search_t = 5.0
    if health <= 0.0:
        _die(attacker, is_head)
        return true
    return false


func _die(attacker: Node, is_head: bool) -> void:
    alive = false
    health = 0.0
    HitZone.set_zones_enabled(_zones, false)
    collision_layer = 0
    velocity = Vector3.ZERO
    puppet.pose = "idle"
    puppet.die()
    died.emit(self, attacker, is_head)


func respawn_at(xf: Transform3D, protect := 2.0) -> void:
    global_position = xf.origin
    _yaw = xf.basis.get_euler().y
    _desired_yaw = _yaw
    rotation.y = _yaw
    velocity = Vector3.ZERO
    alive = true
    health = max_health
    spawn_protect = protect
    collision_layer = 2
    HitZone.set_zones_enabled(_zones, true)
    puppet.revive()
    _ammo = data.magazine_size
    _reload_t = 0.0
    _target = null
    _state = S.ROAM
    _alert_t = 0.0
    _wait_t = _rng.randf_range(0.0, 1.0)
    _pick_goal()


# ---------- 主循环 ----------
func _physics_process(delta: float) -> void:
    if not alive:
        return
    spawn_protect = maxf(spawn_protect - delta, 0.0)
    _cooldown = maxf(_cooldown - delta, 0.0)
    _alert_t = maxf(_alert_t - delta, 0.0)
    if _reload_t > 0.0:
        _reload_t -= delta
        if _reload_t <= 0.0:
            _ammo = data.magazine_size

    var dir := Vector3.ZERO
    if enabled:
        _scan_t -= delta
        if _scan_t <= 0.0:
            _scan_t = 0.15
            _perceive()
        match _state:
            S.ROAM:
                dir = _tick_roam(delta)
            S.ENGAGE:
                dir = _tick_engage(delta)
            S.SEARCH:
                dir = _tick_search(delta)
        _check_stuck(delta, dir)

    var spd := float(skill["speed"])
    if Time.get_ticks_msec() / 1000.0 < slow_until:
        spd *= slow_factor
    velocity.x = move_toward(velocity.x, dir.x * spd, 40.0 * delta)
    velocity.z = move_toward(velocity.z, dir.z * spd, 40.0 * delta)
    if is_on_floor():
        velocity.y = -1.0
    else:
        velocity.y -= GRAVITY * delta
    move_and_slide()

    _yaw = lerp_angle(_yaw, _desired_yaw, minf(1.0, 9.0 * delta))
    rotation.y = _yaw
    puppet.speed = Vector2(velocity.x, velocity.z).length()
    puppet.vel_local = global_transform.basis.inverse() * velocity
    puppet.aim_pitch = _pitch
    puppet.pose = "air" if not is_on_floor() else ("move" if puppet.speed > 0.5 else "idle")


# ---------- 感知 ----------
func _has_los(from: Vector3, to: Vector3) -> bool:
    var q := PhysicsRayQueryParameters3D.create(from, to)
    q.collision_mask = 1
    q.exclude = _exclude
    if not get_world_3d().direct_space_state.intersect_ray(q).is_empty():
        return false
    for z in get_tree().get_nodes_in_group("smoke_zones"):      # 烟幕阻挡视线（反制）
        if bool(z.call("blocks", from, to)):
            return false
    return true


func _perceive() -> void:
    var eye := global_position + Vector3.UP * EYE_H
    var fwd := -global_transform.basis.z
    var best: Node3D = null
    var best_d := 1e9
    for n in get_tree().get_nodes_in_group("combatants"):
        var c := n as Node3D
        if c == null or c == self:
            continue
        if int(c.get("team")) == team or not bool(c.get("alive")):
            continue
        var to := c.global_position + Vector3.UP * 1.2 - eye
        var d := to.length()
        if d > VISION_RANGE or d >= best_d:
            continue
        if _alert_t <= 0.0 and fwd.dot(to.normalized()) < 0.26:     # 约 75° 视野；被打后全向
            continue
        if _has_los(eye, c.global_position + Vector3.UP * 1.3):
            best = c
            best_d = d
    if best != null:
        if _state != S.ENGAGE or _target != best:
            _react_t = float(skill["react"])
        _target = best
        _last_seen = best.global_position
        _lost_t = 0.0
        _state = S.ENGAGE
    elif _state == S.ENGAGE:
        _lost_t += 0.15
        if _lost_t > 0.6:
            _state = S.SEARCH
            _search_t = 4.0
            _target = null


# ---------- 状态 ----------
func _pick_goal() -> void:
    if pois.is_empty():
        _goal = global_position
        return
    _goal = pois[_rng.randi() % pois.size()]
    _repath_t = 0.0


func _nav_dir(goal: Vector3) -> Vector3:
    if _repath_t <= 0.0:
        nav.target_position = goal
        _repath_t = 0.4
    _repath_t -= get_physics_process_delta_time()
    var d := nav.get_next_path_position() - global_position
    d.y = 0.0
    if d.length() < 0.05 and not nav.is_navigation_finished():
        d = goal - global_position       # 导航不可用时的兜底: 直线朝目标
        d.y = 0.0
    return d.normalized() if d.length() > 0.05 else Vector3.ZERO


func _tick_roam(delta: float) -> Vector3:
    if _wait_t > 0.0:
        _wait_t -= delta
        return Vector3.ZERO
    var flat := Vector2(_goal.x - global_position.x, _goal.z - global_position.z)
    if _goal == Vector3.ZERO or flat.length() < 2.5:
        _wait_t = _rng.randf_range(0.3, 1.2)
        _pick_goal()
        return Vector3.ZERO
    var d := _nav_dir(_goal)
    if d != Vector3.ZERO:
        _desired_yaw = atan2(-d.x, -d.z)
        _pitch = 0.0
    return d


func _tick_search(delta: float) -> Vector3:
    _search_t -= delta
    if _search_t <= 0.0:
        _state = S.ROAM
        _pick_goal()
        return Vector3.ZERO
    var flat := Vector2(_last_seen.x - global_position.x, _last_seen.z - global_position.z)
    if flat.length() < 2.5:
        _desired_yaw += 1.5 * delta       # 到达后原地张望
        return Vector3.ZERO
    var d := _nav_dir(_last_seen)
    if d != Vector3.ZERO:
        _desired_yaw = atan2(-d.x, -d.z)
    return d


func _tick_engage(delta: float) -> Vector3:
    if _target == null or not is_instance_valid(_target) or not bool(_target.get("alive")):
        _target = null
        _state = S.ROAM
        _pick_goal()
        return Vector3.ZERO
    var eye := global_position + Vector3.UP * EYE_H
    var to := (_target.global_position + Vector3.UP * 1.3) - eye
    var dist := to.length()
    _desired_yaw = atan2(-to.x, -to.z)
    _pitch = atan2(to.y, Vector2(to.x, to.z).length())

    _react_t = maxf(_react_t - delta, 0.0)
    if _react_t <= 0.0 and _reload_t <= 0.0:
        _try_fire(eye, to / maxf(dist, 0.01), dist, delta)

    var pref: float = float(PREFERRED_RANGE.get(data.category, 20.0))
    var fwd := Vector3(to.x, 0.0, to.z).normalized()
    var right := Vector3(-to.z, 0.0, to.x).normalized()
    _strafe_t -= delta
    if _strafe_t <= 0.0 or (get_slide_collision_count() > 0 and _strafe_t < 1.2):
        if _rng.randf() < 0.6:
            _strafe_dir = -_strafe_dir
        _strafe_t = _rng.randf_range(0.8, 2.0)
    var move := right * _strafe_dir * 0.8
    if dist > pref + 6.0:
        move = _nav_dir(_target.global_position)
    elif dist < pref - 6.0:
        move = -fwd * 0.8 + right * _strafe_dir * 0.4
    return move.limit_length(1.0)


func _try_fire(eye: Vector3, dir: Vector3, dist: float, delta: float) -> void:
    if _ammo <= 0:
        _reload_t = data.reload_time
        return
    if _cooldown > 0.0:
        return
    if data.automatic:                    # 点射节奏: 连发一小段 → 停顿
        if _burst_left <= 0:
            _pause_t -= delta
            if _pause_t > 0.0:
                return
            _burst_left = _rng.randi_range(4, 10)
        _burst_left -= 1
        if _burst_left <= 0:
            _pause_t = _rng.randf_range(0.15, 0.45)
    _ammo -= 1
    _cooldown = 60.0 / data.fire_rate_rpm + (0.0 if data.automatic else _rng.randf_range(0.05, 0.18))

    var space := get_world_3d().direct_space_state
    var spread := float(skill["aim"]) + data.spread_hip_deg * 0.5 + dist * 0.02    # 越远越不准
    var aim_basis := Basis.looking_at(dir, Vector3.UP)
    for i in data.pellets:
        var cone := spread + (data.pellet_spread_deg if data.pellets > 1 else 0.0)
        var ang := _rng.randf() * TAU
        var mag := sqrt(_rng.randf()) * deg_to_rad(cone)
        var local := Vector3(cos(ang) * sin(mag), sin(ang) * sin(mag), -cos(mag))
        var d := (aim_basis * local).normalized()
        var st := {
            "data": data, "origin": eye, "dmg_mult": float(skill["dmg"]), "range_mult": 1.0,
            "penetration": data.penetration, "pen_dmg_mult": data.penetration_damage_mult,
            "pens_left": 1, "dmg_scale": 1.0, "shooter": self, "local": false,
        }
        Ballistics.trace_segment(space, eye, eye + d * data.max_range, _exclude, st)
    puppet.kick()
    if puppet.gun != null:
        puppet.gun.anim_fire(_cooldown)


func _check_stuck(delta: float, dir: Vector3) -> void:
    _stuck_t += delta
    if _stuck_t < 1.2:
        return
    if dir != Vector3.ZERO and global_position.distance_to(_stuck_pos) < 0.4 and _state != S.ENGAGE:
        _wait_t = 0.0
        _pick_goal()
    _stuck_pos = global_position
    _stuck_t = 0.0
