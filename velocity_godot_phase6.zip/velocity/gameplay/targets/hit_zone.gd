class_name HitZone
extends AnimatableBody3D
## 命中区域（头/躯干/四肢）。射线打到它，把伤害转发给所属单位（靶子/玩家/机器人）。
## 放在独立碰撞层（第 3 层，位值 4）；场景几何体在第 1 层，角色本体在第 2 层。
## CharacterBody 只与第 1 层碰撞，所以命中区域不会挡住角色自己的移动；
## Ballistics 的射线掩码是 1|4，打得到几何体和命中区域，打不到角色胶囊。

const LAYER := 4

@export var is_head := false
@export var damage_mult := 1.0
var target: Node


func _init() -> void:
    collision_layer = LAYER
    collision_mask = 0


## 返回是否击杀
func apply_damage(amount: float, attacker: Node = null) -> bool:
    if target != null and target.has_method("take_damage"):
        return target.take_damage(amount * damage_mult, attacker, is_head)
    return false


## 给人形单位（玩家/机器人）加上 头 / 躯干 / 腿 三个命中区
static func add_humanoid_zones(parent: Node3D, owner_unit: Node) -> Array[HitZone]:
    var out: Array[HitZone] = []
    var specs := [
        {"pos": Vector3(0, 1.05, 0), "size": Vector3(0.55, 0.8, 0.35), "r": 0.0, "head": false, "mult": 1.0},
        {"pos": Vector3(0, 1.68, 0), "size": Vector3.ZERO, "r": 0.19, "head": true, "mult": 1.0},
        {"pos": Vector3(0, 0.4, 0), "size": Vector3(0.45, 0.75, 0.3), "r": 0.0, "head": false, "mult": 0.8},
    ]
    for sp in specs:
        var z := HitZone.new()
        z.is_head = sp["head"]
        z.damage_mult = sp["mult"]
        z.target = owner_unit
        z.position = sp["pos"]
        var cs := CollisionShape3D.new()
        if float(sp["r"]) > 0.0:
            var ss := SphereShape3D.new()
            ss.radius = sp["r"]
            cs.shape = ss
        else:
            var bs := BoxShape3D.new()
            bs.size = sp["size"]
            cs.shape = bs
        z.add_child(cs)
        parent.add_child(z)
        out.append(z)
    return out


static func set_zones_enabled(zones: Array, on: bool) -> void:
    for z in zones:
        if is_instance_valid(z):
            (z as HitZone).collision_layer = LAYER if on else 0
