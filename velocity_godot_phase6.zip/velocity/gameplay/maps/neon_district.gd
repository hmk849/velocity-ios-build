extends Node3D
## NEON DISTRICT — 第一张正式地图（未来都市夜战）+ 团队死斗 6V6（人机）。
## 几何体来自 NeonLayout（tools/gen_neon_district.py 生成并校验: 对称、连通、多条侧翼）。
## 渲染预算: 世界按材质合并成 5 个网格 + 2 个霓虹网格；碰撞按表面材质合并成 2 个 StaticBody。
## 导航: 启动时用 NavigationRegion3D 在线程里烘焙导航网格，完成后才开局。
##
## 路线: 主干道(x=0) / 两侧小巷(x=±28) / 外侧街道(x=±68) / 地下通道(y=-5) / 低层屋顶+天桥(y=10)
## 制高点: 西塔楼 34m、东塔楼 26m（高墙面可蹬墙跑；用钩爪/滑索上去）

const KIND_COLORS := [Color("2b3138"), Color("3a424b"), Color("4d5864"), Color("7a8794"), Color("232a31")]
const NEON_COLORS := [Color("7fd3ff"), Color("ff7a1a")]
const TEAM_COLORS := [Color("7fd3ff"), Color("ff7a1a")]
const BOT_NAMES := ["RAVEN", "KITE", "ONYX", "LYNX", "ZEPHYR", "SABLE", "VIPER", "NOVA", "HALO", "DRIFT", "ECHO", "FLUX"]
const BOT_WEAPONS := ["vx1_rifle", "vx2_carbine", "kr4_assault", "arc7_rifle", "helix_a", "fj16_rifle",
    "vp9_smg", "qs3_smg", "mara_smg", "tc20_smg", "lm5_lmg", "hx8_shotgun", "talon14", "px1_pistol"]

var _touch: TouchControls
var _hud: HUD
var _match_hud: MatchHud
var _player: Player
var _mode: TeamDeathmatch
var _region: NavigationRegion3D
var _grid_tex: ImageTexture
var _baked := false
var _role := "offline"
var _nw: Node
var _server_difficulty := 1


func _ready() -> void:
    _role = String(Game.match_config.get("net_role", "offline"))
    Game.is_server = _role == "server"
    _build_environment()
    _build_world()
    _build_decor()
    _build_ziplines()
    if _role != "server":
        _build_ui()
    match _role:
        "server":
            await _bake_navigation()
            _start_server()
        "client":
            _start_client()        # 客户端没有机器人，不需要导航网格
        _:
            await _bake_navigation()
            _spawn_match()


func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        _exit_to_lobby()


func _exit_to_lobby() -> void:
    SceneRouter.goto("res://ui/lobby/lobby.tscn")


func _rematch() -> void:
    SceneRouter.goto("res://gameplay/maps/neon_district.tscn")


# ---------- 环境 ----------
func _build_environment() -> void:
    var we := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("0a0e13")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("56677a")
    env.ambient_light_energy = 0.9
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = true
    env.fog_light_color = Color("141c26")
    env.fog_density = 0.006
    we.environment = env
    add_child(we)
    var moon := DirectionalLight3D.new()
    moon.rotation_degrees = Vector3(-55, 25, 0)
    moon.light_color = Color("b8c8e0")
    moon.light_energy = 0.55
    moon.shadow_enabled = Settings.shadows
    moon.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
    moon.directional_shadow_max_distance = 70.0
    add_child(moon)


# ---------- 世界几何 ----------
func _grid_texture() -> ImageTexture:
    if _grid_tex == null:
        var img := Image.create(64, 64, false, Image.FORMAT_RGB8)
        img.fill(Color("ffffff"))
        for i in 64:
            for k in 2:
                img.set_pixel(i, k, Color("a8b2bc"))
                img.set_pixel(k, i, Color("a8b2bc"))
        img.generate_mipmaps()
        _grid_tex = ImageTexture.create_from_image(img)
    return _grid_tex


func _world_material(kind: int) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = KIND_COLORS[kind]
    m.albedo_texture = _grid_texture()
    m.uv1_triplanar = true
    m.uv1_world_triplanar = true
    m.uv1_scale = Vector3(0.25, 0.25, 0.25)
    m.roughness = 0.85
    m.metallic = 0.5 if kind == 3 else 0.0
    return m


func _box_xf(b: Array) -> Transform3D:
    var rot := Basis.from_euler(Vector3(deg_to_rad(float(b[6])), deg_to_rad(float(b[7])), deg_to_rad(float(b[8]))))
    return Transform3D(rot, Vector3(float(b[0]), float(b[1]), float(b[2])))


func _build_world() -> void:
    _region = NavigationRegion3D.new()
    add_child(_region)
    var batches := {}
    var bodies := {}
    for b: Array in NeonLayout.BOXES:
        var size := Vector3(float(b[3]), float(b[4]), float(b[5]))
        var xf := _box_xf(b)
        var kind := int(b[9])
        if not batches.has(kind):
            var st := SurfaceTool.new()
            st.begin(Mesh.PRIMITIVE_TRIANGLES)
            batches[kind] = st
        var bm := BoxMesh.new()
        bm.size = size
        (batches[kind] as SurfaceTool).append_from(bm, 0, xf)
        var surface := "metal" if kind == 3 else "concrete"
        if not bodies.has(surface):
            var body := StaticBody3D.new()
            body.set_meta("surface", surface)
            _region.add_child(body)
            bodies[surface] = body
        var cs := CollisionShape3D.new()
        var bs := BoxShape3D.new()
        bs.size = size
        cs.shape = bs
        cs.transform = xf
        (bodies[surface] as StaticBody3D).add_child(cs)
    for kind in batches.keys():
        var mi := MeshInstance3D.new()
        mi.mesh = (batches[kind] as SurfaceTool).commit()
        mi.material_override = _world_material(int(kind))
        _region.add_child(mi)


# ---------- 霓虹 / 广告屏 / 灯 ----------
func _build_decor() -> void:
    for c in 2:
        var st := SurfaceTool.new()
        st.begin(Mesh.PRIMITIVE_TRIANGLES)
        var n := 0
        for b: Array in NeonLayout.NEON:
            if int(b[6]) != c:
                continue
            var bm := BoxMesh.new()
            bm.size = Vector3(float(b[3]), float(b[4]), float(b[5]))
            st.append_from(bm, 0, Transform3D(Basis.IDENTITY, Vector3(float(b[0]), float(b[1]), float(b[2]))))
            n += 1
        if n == 0:
            continue
        var mi := MeshInstance3D.new()
        mi.mesh = st.commit()
        var m := StandardMaterial3D.new()
        m.albedo_color = NEON_COLORS[c].darkened(0.6)
        m.emission_enabled = true
        m.emission = NEON_COLORS[c]
        m.emission_energy_multiplier = 2.2
        mi.material_override = m
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(mi)

    for s: Array in NeonLayout.SCREENS:
        var q := MeshInstance3D.new()
        var qm := QuadMesh.new()
        qm.size = Vector2(float(s[3]), float(s[4]))
        q.mesh = qm
        var sm := StandardMaterial3D.new()
        sm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        sm.albedo_texture = _screen_texture(int(s[6]))
        sm.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR
        q.material_override = sm
        q.position = Vector3(float(s[0]), float(s[1]), float(s[2]))
        q.rotation_degrees.y = float(s[5])
        q.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(q)

    if not Game.is_mobile:       # 手机上不加点光源，靠霓虹自发光 + 环境光，省性能
        for i in mini(NeonLayout.LIGHTS.size(), 12):
            var l: Array = NeonLayout.LIGHTS[i]
            var o := OmniLight3D.new()
            o.position = Vector3(float(l[0]), float(l[1]), float(l[2]))
            o.light_color = NEON_COLORS[int(l[3])]
            o.light_energy = 1.2
            o.omni_range = float(l[4])
            add_child(o)


func _screen_texture(style: int) -> ImageTexture:
    var img := Image.create(64, 32, false, Image.FORMAT_RGB8)
    var base := Color("0d1218")
    var a := NEON_COLORS[0] if style != 1 else NEON_COLORS[1]
    img.fill(base)
    for y in 32:
        for x in 64:
            var on := false
            match style:
                0:
                    on = (y % 6) < 2 and x > 4 and x < 60
                1:
                    on = ((x + y) % 10) < 3
                _:
                    on = (x % 8) == 0 or (y % 8) == 0
            if on:
                img.set_pixel(x, y, a.darkened(0.15))
    return ImageTexture.create_from_image(img)


func _build_ziplines() -> void:
    for z: Array in NeonLayout.ZIPLINES:
        var zl := Zipline.new()
        zl.setup(Vector3(float(z[0]), float(z[1]), float(z[2])), Vector3(float(z[3]), float(z[4]), float(z[5])), false, true)
        add_child(zl)


# ---------- 导航烘焙 ----------
func _on_bake_finished() -> void:
    _baked = true


func _bake_navigation() -> void:
    var nm := NavigationMesh.new()
    nm.cell_size = 0.5
    nm.cell_height = 0.25
    nm.agent_height = 1.8
    nm.agent_radius = 0.5
    nm.agent_max_climb = 0.5
    nm.agent_max_slope = 46.0
    nm.geometry_parsed_geometry_type = NavigationMesh.PARSED_GEOMETRY_MESH_INSTANCES
    nm.geometry_source_geometry_mode = NavigationMesh.SOURCE_GEOMETRY_ROOT_NODE_CHILDREN
    _region.navigation_mesh = nm
    var map := get_world_3d().navigation_map
    NavigationServer3D.map_set_cell_size(map, 0.5)
    NavigationServer3D.map_set_cell_height(map, 0.25)
    if _match_hud != null:
        _match_hud.set_status("正在生成导航网格…")
    _region.bake_finished.connect(_on_bake_finished, CONNECT_ONE_SHOT)
    _region.bake_navigation_mesh(true)
    var t0 := Time.get_ticks_msec()
    while not _baked and Time.get_ticks_msec() - t0 < 20000:
        await get_tree().process_frame
    await get_tree().physics_frame
    await get_tree().physics_frame
    if nm.get_polygon_count() == 0:
        push_warning("导航网格为空: 机器人会退化为直线移动")
    if _match_hud != null:
        _match_hud.set_status("")


# ---------- UI ----------
func _build_ui() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 10
    add_child(layer)
    if Game.is_mobile:
        _touch = TouchControls.new()
        layer.add_child(_touch)
    _hud = HUD.new()
    layer.add_child(_hud)
    _hud.set_picker_enabled(false)       # 竞技对局里不能随便换枪；去工坊配置
    _hud.back_requested.connect(_exit_to_lobby)
    _match_hud = MatchHud.new()
    layer.add_child(_match_hud)
    _match_hud.rematch_requested.connect(_rematch)
    _match_hud.exit_requested.connect(_exit_to_lobby)


# ---------- 开局 ----------
func _spawn_match() -> void:
    var level := int(Game.match_config.get("difficulty", 1))
    _mode = TeamDeathmatch.new()
    add_child(_mode)
    for t in 2:
        var src: Array = NeonLayout.SPAWNS_A if t == 0 else NeonLayout.SPAWNS_B
        for s: Array in src:
            _mode.spawns[t].append(Transform3D(Basis(Vector3.UP, float(s[2])), Vector3(float(s[0]), 0.15, float(s[1]))))

    _player = Player.new()
    _player.touch = _touch
    for id in [Loadout.primary, Loadout.secondary]:
        var d := WeaponCatalog.load_weapon(id)
        if d != null:
            _player.loadout.append(d)
    if _player.loadout.is_empty():
        _player.loadout.append(WeaponCatalog.load_weapon("vx1_rifle"))
    add_child(_player)
    _mode.local_player = _player
    _mode.add_combatant(_player, 0, String(AuthService.profile.get("nickname", "YOU")))

    var pois: Array = []
    for p: Array in NeonLayout.POIS:
        pois.append(Vector3(float(p[0]), float(p[1]), float(p[2])))
    var names := BOT_NAMES.duplicate()
    names.shuffle()
    var n := 0
    for team in 2:
        var count := 5 if team == 0 else 6
        for i in count:
            var bot := Bot.new()
            var wid: String = BOT_WEAPONS[randi() % BOT_WEAPONS.size()]
            bot.setup(team, String(names[n % names.size()]), WeaponCatalog.load_weapon(wid), Bot.skill_for(level), pois, TEAM_COLORS[team])
            add_child(bot)
            _mode.add_combatant(bot, team, bot.display_name)
            n += 1
    _mode.start()


# =====================================================================
#  联网（Phase 5）: net 脚本按需加载，加载失败不影响单机模式
# =====================================================================
func _make_networld() -> Node:
    var scr: Script = load("res://net/net_world.gd")
    if scr == null:
        push_error("联网模块加载失败（net/net_world.gd）")
        return null
    var nw: Node = scr.new()
    nw.name = "NetWorld"          # 服务器和客户端的节点路径必须一致，RPC 才能对上
    add_child(nw)
    nw.set("map", self)
    return nw


func _build_spawns() -> void:
    for t in 2:
        var src: Array = NeonLayout.SPAWNS_A if t == 0 else NeonLayout.SPAWNS_B
        for s: Array in src:
            _mode.spawns[t].append(Transform3D(Basis(Vector3.UP, float(s[2])), Vector3(float(s[0]), 0.15, float(s[1]))))


func _poi_list() -> Array:
    var pois: Array = []
    for p: Array in NeonLayout.POIS:
        pois.append(Vector3(float(p[0]), float(p[1]), float(p[2])))
    return pois


func _new_bot(team: int) -> Bot:
    var wid: String = BOT_WEAPONS[randi() % BOT_WEAPONS.size()]
    var bot := Bot.new()
    bot.setup(team, "%s%d" % [BOT_NAMES[randi() % BOT_NAMES.size()], randi() % 90 + 10],
        WeaponCatalog.load_weapon(wid), Bot.skill_for(_server_difficulty), _poi_list(), TEAM_COLORS[team])
    add_child(bot)
    return bot


## 服务器: 空位补机器人（NetWorld 调用）
func net_add_bot(team: int) -> Node:
    var bot := _new_bot(team)
    _mode.call("add_late", bot, team, bot.display_name)
    return bot


## 客户端: 创建本机玩家（NetWorld 在收到 welcome 后调用）
func net_spawn_local(_my_id: int, team: int, pname: String) -> Player:
    _player = Player.new()
    _player.net_role = "client"
    _player.team = team
    _player.display_name = pname
    _player.touch = _touch
    for id in [Loadout.primary, Loadout.secondary]:
        var d := WeaponCatalog.load_weapon(id)
        if d != null:
            _player.loadout.append(d)
    add_child(_player)
    return _player


func _start_server() -> void:
    Engine.max_fps = 60
    _server_difficulty = int(Game.match_config.get("difficulty", 1))
    _mode = TeamDeathmatch.new()
    add_child(_mode)
    _build_spawns()
    _nw = _make_networld()               # 先于所有玩家/机器人加入场景，保证物理帧顺序
    if _nw == null:
        return
    _nw.set("mode", _mode)
    for team in 2:
        for i in 6:
            var bot := _new_bot(team)
            _mode.add_combatant(bot, team, bot.display_name)
            _nw.call("register_entity", bot)
    _nw.call("start_server", int(Game.match_config.get("port", 7777)))
    EventBus.match_ended.connect(_server_restart_later)
    _mode.start()


func _server_restart_later(_winner: int, _rows: Array) -> void:
    await get_tree().create_timer(15.0).timeout
    _mode.call("restart")


func _start_client() -> void:
    _match_hud.set_online(true)
    _hud.set_picker_enabled(false)
    _nw = _make_networld()
    if _nw == null:
        _match_hud.set_status("联网模块不可用")
        return
    _nw.set("player_name", String(AuthService.profile.get("nickname", "PLAYER")))
    _nw.connect("status", _on_net_status)
    _nw.connect("failed", _on_net_failed)
    var addr := String(Game.match_config.get("net_address", "127.0.0.1:7777"))
    var host := addr
    var prt := 7777
    if ":" in addr:
        host = addr.get_slice(":", 0)
        prt = int(addr.get_slice(":", 1))
    _nw.call("connect_to", host, prt)


func _on_net_status(text: String) -> void:
    _match_hud.set_status(text)


func _on_net_failed(reason: String) -> void:
    _match_hud.set_status(reason)
    await get_tree().create_timer(3.0).timeout
    _exit_to_lobby()
