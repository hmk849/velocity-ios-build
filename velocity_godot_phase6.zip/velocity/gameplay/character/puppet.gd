class_name Puppet
extends Node3D
## 程序化第三人称角色（占位，不是骨骼动画资产）。
## 由方块拼出带战术装备的人形: 头盔/护目镜/面罩/防弹背心/护肩/腰带/弹匣袋/手套/护膝/战术靴/通信天线，
## 材质区分金属/织物/橡胶/塑料/玻璃。
## 动画全部由代码生成: 步态(含侧移)、站立呼吸、滑铲、空中、蹬墙跑、翻越、钩爪、滑索、
## 换弹手部动作、受击、死亡；手臂与腿用解析式双骨 IK（手握枪、脚随步态）。
## 局限: 脚没有做地形贴合；没有骨骼蒙皮。正式角色换成带骨架的 .glb 后，这里的 IK 逻辑可迁移。
##
## 约定: 原点在脚底，前方 -Z。由外部每帧设置下面的"输入参数"。

const HIP_H := 0.95
const THIGH := 0.46
const SHIN := 0.46
const UPPER_ARM := 0.30
const FOREARM := 0.30
const SHOULDER_X := 0.22

# ---- 输入参数（外部设置）----
var pose := "idle"          # idle / move / slide / air / wall_run / mantle / grapple / zipline
var speed := 0.0
var vel_local := Vector3.ZERO     # 局部速度（x 右，-z 前）
var aim_pitch := 0.0
var ads := 0.0
var wall_side := 0.0
var grapple_dir := Vector3(0, 0, -1)   # 局部空间
var idle_events := false           # 大厅用: 自动做调整枪械/检查弹匣/环顾

var gun: GunModel

var hips: Node3D
var chest: Node3D
var head: Node3D
var gun_mount: Node3D
var _thigh: Array[Node3D] = []
var _shin: Array[Node3D] = []
var _uarm: Array[Node3D] = []
var _farm: Array[Node3D] = []

var _t := 0.0
var _phase := 0.0
var _foot: Array[Vector3] = [Vector3(-0.11, 0, 0), Vector3(0.11, 0, 0)]
var _hip_h := HIP_H
var _lean := 0.0
var _reload_t := -1.0
var _reload_dur := 1.0
var _flinch := 0.0
var _dead := false
var _team_mat: StandardMaterial3D
var _adjust_t := 0.0
var _check_t := 0.0
var _look_t := 0.0
var _next_idle := 3.0
var _mats: Dictionary = {}


func _ready() -> void:
    _build()


# =============== 构建 ===============
func _m(color: Color, metallic := 0.0, rough := 0.8, alpha := 1.0) -> StandardMaterial3D:
    var key := "%s_%.1f_%.1f_%.1f" % [color.to_html(), metallic, rough, alpha]
    if not _mats.has(key):
        var m := StandardMaterial3D.new()
        m.albedo_color = Color(color, alpha)
        m.metallic = metallic
        m.roughness = rough
        if alpha < 1.0:
            m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        _mats[key] = m
    return _mats[key]


func _part(parent: Node3D, size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.position = pos
    mi.material_override = mat
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(mi)
    return mi


## 沿 -Z 延伸的肢体骨骼节点
func _limb(len_: float, thick: float, mat: Material, tip_mat: Material = null) -> Node3D:
    var b := Node3D.new()
    _part(b, Vector3(thick, thick, len_), Vector3(0, 0, -len_ * 0.5), mat)
    if tip_mat != null:
        _part(b, Vector3(thick * 1.15, thick * 1.15, len_ * 0.28), Vector3(0, 0, -len_ * 0.86), tip_mat)
    add_child(b)
    return b


func _build() -> void:
    var fabric := _m(Color("3b4237"), 0.0, 0.95)       # 织物
    var fabric2 := _m(Color("2c3128"), 0.0, 0.95)
    var plate := _m(Color("565f66"), 0.6, 0.45)          # 金属/陶瓷板
    var rubber := _m(Color("16181a"), 0.0, 0.9)          # 橡胶
    var plastic := _m(Color("4a4f55"), 0.1, 0.6)         # 塑料
    var glass := _m(Color("7fd3ff"), 0.0, 0.1, 0.55)     # 玻璃（护目镜）
    var glove := _m(Color("1d1f21"), 0.0, 0.85)

    hips = Node3D.new()
    hips.position = Vector3(0, HIP_H, 0)
    add_child(hips)
    _part(hips, Vector3(0.34, 0.16, 0.2), Vector3.ZERO, fabric2)                      # 骨盆
    _part(hips, Vector3(0.38, 0.06, 0.22), Vector3(0, 0.08, 0), rubber)               # 腰带
    for sx in [-0.12, 0.12]:
        _part(hips, Vector3(0.07, 0.1, 0.06), Vector3(sx, 0.07, -0.13), fabric)       # 弹匣袋

    chest = Node3D.new()
    chest.position = Vector3(0, 0.15, 0)
    hips.add_child(chest)
    _part(chest, Vector3(0.38, 0.5, 0.22), Vector3(0, 0.27, 0), fabric)               # 躯干
    _part(chest, Vector3(0.36, 0.34, 0.06), Vector3(0, 0.34, -0.14), plate)           # 前胸板
    _part(chest, Vector3(0.34, 0.3, 0.05), Vector3(0, 0.34, 0.14), plate)             # 后背板
    for sx in [-0.26, 0.26]:
        _part(chest, Vector3(0.12, 0.1, 0.18), Vector3(sx, 0.5, 0), plate)            # 护肩（模块化装甲）
    _part(chest, Vector3(0.05, 0.3, 0.04), Vector3(-0.17, 0.62, 0.14), plastic)       # 通信天线
    _part(chest, Vector3(0.08, 0.06, 0.05), Vector3(0.14, 0.52, -0.15), plastic)      # 通信设备

    head = Node3D.new()
    head.position = Vector3(0, 0.62, 0)
    chest.add_child(head)
    _part(head, Vector3(0.22, 0.24, 0.24), Vector3(0, 0.12, 0), _m(Color("c9a98b"), 0.0, 0.8))  # 头
    _part(head, Vector3(0.28, 0.14, 0.3), Vector3(0, 0.25, 0.01), plate)              # 战术头盔
    _part(head, Vector3(0.24, 0.07, 0.04), Vector3(0, 0.15, -0.13), glass)            # 护目镜
    _part(head, Vector3(0.2, 0.09, 0.05), Vector3(0, 0.05, -0.12), fabric2)           # 面罩

    _team_mat = StandardMaterial3D.new()
    _team_mat.albedo_color = Color("7fd3ff")
    _team_mat.emission_enabled = true
    _team_mat.emission = Color("7fd3ff")
    _team_mat.emission_energy_multiplier = 0.8
    _part(head, Vector3(0.3, 0.035, 0.32), Vector3(0, 0.305, 0.01), _team_mat)         # 头盔队伍标识
    for sx in [-0.26, 0.26]:
        _part(chest, Vector3(0.13, 0.03, 0.2), Vector3(sx, 0.56, 0), _team_mat)       # 护肩队伍条
    _part(chest, Vector3(0.22, 0.1, 0.02), Vector3(0, 0.45, 0.17), _team_mat)         # 背部队伍标识

    gun_mount = Node3D.new()
    gun_mount.position = Vector3(0.14, 0.3, -0.28)
    chest.add_child(gun_mount)
    gun = GunModel.new()
    gun_mount.add_child(gun)

    for i in 2:
        _thigh.append(_limb(THIGH, 0.14, fabric))
        _shin.append(_limb(SHIN, 0.12, fabric2, rubber))      # 战术靴
        _part(_shin[i], Vector3(0.14, 0.12, 0.1), Vector3(0, 0, -SHIN * 0.42), plate)  # 护膝
        _uarm.append(_limb(UPPER_ARM, 0.1, fabric))
        _farm.append(_limb(FOREARM, 0.09, fabric2, glove))    # 手套


func set_weapon(d: WeaponData, atts: Array[AttachmentData]) -> void:
    if gun != null and d != null:
        gun.build(d, atts)


# =============== 事件 ===============
func start_reload(duration: float) -> void:
    _reload_t = 0.0
    _reload_dur = maxf(duration, 0.3)


func kick() -> void:
    gun_mount.position.z += 0.03
    if gun != null:
        gun.position.z = 0.04


func flinch() -> void:
    _flinch = 0.3 if randf() > 0.5 else -0.3


## 队伍识别色（头盔、护肩、背部）
func set_team_color(c: Color) -> void:
    if _team_mat != null:
        _team_mat.albedo_color = c
        _team_mat.emission = c


func revive() -> void:
    _dead = false
    rotation = Vector3.ZERO
    position = Vector3.ZERO


func die() -> void:
    _dead = true
    var tw := create_tween()
    tw.tween_property(self, "rotation:x", -PI * 0.5, 0.6).set_ease(Tween.EASE_IN)
    tw.parallel().tween_property(self, "position:y", position.y + 0.12, 0.6)


# =============== 每帧动画 ===============
func _process(delta: float) -> void:
    if _dead or hips == null or not is_visible_in_tree():
        return
    _t += delta
    _update_idle_events(delta)

    # ---- 目标姿态 ----
    var moving := clampf(speed / 3.0, 0.0, 1.0)
    var sprint := clampf((speed - 6.0) / 4.0, 0.0, 1.0)
    var hip_target := HIP_H
    var lean_target := 0.12 * clampf(speed / 9.0, 0.0, 1.0)
    var roll_target := 0.0
    var foot_t: Array[Vector3] = [Vector3(-0.11, 0, 0), Vector3(0.11, 0, 0)]
    var hand_up := false      # 双手上举（翻越 / 滑索）
    var reach_hook := false

    match pose:
        "slide":
            hip_target = 0.5
            lean_target = -0.45
            foot_t = [Vector3(-0.12, 0.08, -0.78), Vector3(0.15, 0.22, -0.12)]
        "air":
            foot_t = [Vector3(-0.11, 0.3, -0.1), Vector3(0.11, 0.12, 0.12)]
            lean_target = 0.05
        "mantle":
            var s := sin(_t * 9.0)
            foot_t = [Vector3(-0.11, 0.45 * maxf(s, 0.0), -0.3), Vector3(0.11, 0.45 * maxf(-s, 0.0), -0.3)]
            hand_up = true
            lean_target = 0.25
        "zipline":
            var sw := sin(_t * 2.0) * 0.08
            foot_t = [Vector3(-0.11, 0.0, sw), Vector3(0.11, 0.0, -sw)]
            hand_up = true
            hip_target = HIP_H + 0.05
        "grapple":
            foot_t = [Vector3(-0.11, 0.2, -0.1), Vector3(0.11, 0.1, 0.1)]
            reach_hook = true
        "wall_run", "move":
            roll_target = wall_side * -0.3 if pose == "wall_run" else 0.0
            var freq := lerpf(5.0, 11.0, clampf(speed / 10.0, 0.0, 1.0)) * (1.2 if pose == "wall_run" else 1.0)
            _phase += delta * freq * moving
            var dir := Vector3(vel_local.x, 0.0, vel_local.z)
            dir = dir.normalized() if dir.length() > 0.01 else Vector3(0, 0, -1)
            var stride := 0.38 * clampf(speed / 6.0, 0.4, 1.3)
            for i in 2:
                var side := -1.0 if i == 0 else 1.0
                var ph := _phase + (0.0 if i == 0 else PI)
                var lift := maxf(cos(ph), 0.0) * 0.16 * clampf(speed / 5.0, 0.3, 1.2)
                foot_t[i] = Vector3(side * 0.11, lift, 0.0) + dir * (sin(ph) * stride)
            hip_target = HIP_H - absf(sin(_phase)) * 0.035 * moving
        _:
            pass     # idle

    var k := 1.0 - exp(-14.0 * delta)
    _hip_h = lerpf(_hip_h, hip_target, k)
    _lean = lerpf(_lean, lean_target, k)
    for i in 2:
        _foot[i] = _foot[i].lerp(foot_t[i], 1.0 - exp(-20.0 * delta))

    # ---- 上身 ----
    var breathe := sin(_t * 1.8) * 0.012
    var adj := _event_curve(_adjust_t, 1.2)
    var chk := _event_curve(_check_t, 2.4)
    var look := sin((1.0 - _look_t / 2.5) * TAU) * 0.7 if _look_t > 0.0 else 0.0

    hips.position = Vector3(sin(_t * 0.7) * 0.008 if pose == "idle" else 0.0, _hip_h, 0.0)
    _flinch = move_toward(_flinch, 0.0, delta * 1.5)
    chest.rotation = Vector3(-_lean + aim_pitch * 0.4, 0.0, roll_target + _flinch)
    chest.scale = Vector3(1, 1.0 + breathe, 1)
    head.rotation = Vector3(aim_pitch * 0.5, look, 0.0)

    # 枪的持姿: 腰际 → 开镜时抬到肩前 → 冲刺时低持 → 检查弹匣时翻向镜头
    var carry := Vector3(0.14, 0.3, -0.28).lerp(Vector3(0.02, 0.44, -0.36), ads)
    carry += Vector3(0.02, 0.04, 0.05) * adj
    var mount_rot := Vector3(aim_pitch * 0.6 - sprint * 0.6, 0.0, 0.9 * chk + 0.2 * adj)
    if reach_hook or hand_up:
        mount_rot.x -= 0.5
    gun_mount.position = gun_mount.position.lerp(carry, 1.0 - exp(-16.0 * delta))
    gun_mount.rotation = gun_mount.rotation.lerp(mount_rot, 1.0 - exp(-12.0 * delta))
    if gun != null:
        gun.position = gun.position.lerp(Vector3.ZERO, 1.0 - exp(-20.0 * delta))

    _solve_legs()
    _solve_arms(hand_up, reach_hook, chk > 0.05)
    if _reload_t >= 0.0:
        _reload_t += delta / _reload_dur
        if _reload_t >= 1.0:
            _reload_t = -1.0


func _event_curve(t: float, dur: float) -> float:
    if t <= 0.0:
        return 0.0
    return sin((1.0 - t / dur) * PI)


func _update_idle_events(delta: float) -> void:
    _adjust_t = maxf(_adjust_t - delta, 0.0)
    _look_t = maxf(_look_t - delta, 0.0)
    if _check_t > 0.0:
        _check_t = maxf(_check_t - delta, 0.0)
    if not idle_events or pose != "idle":
        return
    _next_idle -= delta
    if _next_idle > 0.0:
        return
    _next_idle = randf_range(4.0, 7.0)
    match randi() % 3:
        0:
            _adjust_t = 1.2
        1:
            _check_t = 2.4
            if gun != null:
                gun.anim_check_mag()
        _:
            _look_t = 2.5


# ---------- IK ----------
func _to_root(p: Vector3) -> Vector3:
    return hips.transform * (chest.transform * p)


func _gun_point_in_root(m: Marker3D) -> Vector3:
    if m == null or gun == null:
        return _to_root(Vector3(0, 0.3, -0.5))
    var local_in_chest := gun_mount.transform * (gun.transform * m.position)
    return _to_root(local_in_chest)


func _pose_limb(bone: Node3D, from: Vector3, to: Vector3) -> void:
    var d := to - from
    if d.length() < 0.0001:
        return
    var dn := d.normalized()
    var up := Vector3.UP if absf(dn.dot(Vector3.UP)) < 0.98 else Vector3.RIGHT
    bone.position = from
    bone.basis = Basis.looking_at(dn, up)


func _solve_legs() -> void:
    for i in 2:
        var side := -1.0 if i == 0 else 1.0
        var root := hips.position + Vector3(side * 0.1, -0.05, 0.0)
        var target := Vector3(0, 0.08, 0) + _foot[i]
        var r := IK.solve_two_bone(root, target, THIGH, SHIN, Vector3(0, 0, -1))   # 膝盖朝前
        _pose_limb(_thigh[i], root, r[0])
        _pose_limb(_shin[i], r[0], r[1])


func _solve_arms(hand_up: bool, reach_hook: bool, check_mag: bool) -> void:
    var grip := _gun_point_in_root(gun.grip_point if gun != null else null)
    var fore := _gun_point_in_root(gun.fore_point if gun != null else null)
    var magp := _gun_point_in_root(gun.mag_point if gun != null else null)

    # 换弹: 左手 枪→弹匣井→腰间取新弹匣→弹匣井→回护木
    var left_target := fore
    if _reload_t >= 0.0 or check_mag:
        var belt := _to_root(Vector3(-0.2, -0.05, -0.12))
        var rt := _reload_t if _reload_t >= 0.0 else 0.5
        if rt < 0.25:
            left_target = fore.lerp(magp, rt / 0.25)
        elif rt < 0.5:
            left_target = magp.lerp(belt, (rt - 0.25) / 0.25)
        elif rt < 0.75:
            left_target = belt.lerp(magp, (rt - 0.5) / 0.25)
        else:
            left_target = magp.lerp(fore, (rt - 0.75) / 0.25)
    var right_target := grip

    if hand_up:
        left_target = _to_root(Vector3(-0.2, 1.05, -0.25))
        right_target = _to_root(Vector3(0.2, 1.05, -0.25))
    elif reach_hook:
        right_target = _to_root(Vector3(SHOULDER_X, 0.45, 0.0)) + grapple_dir.normalized() * 0.55

    var arms := [left_target, right_target]
    for i in 2:
        var side := -1.0 if i == 0 else 1.0
        var shoulder := _to_root(Vector3(side * SHOULDER_X, 0.45, 0.0))
        var pole := Vector3(side * 0.6, -1.0, 0.3)
        var r := IK.solve_two_bone(shoulder, arms[i], UPPER_ARM, FOREARM, pole)
        _pose_limb(_uarm[i], shoulder, r[0])
        _pose_limb(_farm[i], r[0], r[1])
