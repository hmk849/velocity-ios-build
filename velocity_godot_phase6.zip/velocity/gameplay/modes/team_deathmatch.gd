class_name TeamDeathmatch
extends Node
## 团队死斗 6V6: 先到击杀数的队伍获胜；时间到比分数；平局进入加时（下一个击杀决胜），
## 加时也没人得分则判平局。阵亡后 3 秒重生，重生点选离敌人最远且近期没用过的点，重生后 2 秒保护。
## 规则逻辑只依赖 Player/Bot 的公共接口（team / alive / died 信号 / respawn_at）。
## 联网时这个节点跑在服务器上（Phase 5）。

enum Phase { COUNTDOWN, LIVE, OVERTIME, ENDED }
const PHASE_NAMES := ["COUNTDOWN", "LIVE", "OVERTIME", "ENDED"]

var kill_limit := 50
var time_limit := 600.0
var countdown_time := 5.0
var respawn_delay := 3.0
var overtime_limit := 60.0
var spawn_protect_time := 2.0

var phase := Phase.COUNTDOWN
var score := [0, 0]
var time_left := 600.0
var spawns: Array = [[], []]       # 每队一组 Transform3D
var players: Array = []
var local_player: Node

var _stats: Dictionary = {}
var _phase_t := 0.0
var _respawn_q: Array = []
var _spawn_used: Dictionary = {}
var _clock := 0.0
var _last_sec := -1
var _multi := 0
var _multi_t := -99.0
var _streak := 0


func add_combatant(node: Node, team: int, display: String) -> void:
    node.set("team", team)
    node.set("display_name", display)
    node.connect("died", _on_died)
    players.append(node)
    _stats[node.get_instance_id()] = {"name": display, "team": team, "kills": 0, "deaths": 0, "is_player": node == local_player}


func start() -> void:
    time_left = time_limit
    phase = Phase.COUNTDOWN
    _phase_t = countdown_time
    for p in players:
        _spawn(p, 0.0)
    _set_enabled(false)
    EventBus.match_score.emit(score[0], score[1], kill_limit)
    EventBus.match_time.emit(time_left)
    EventBus.match_phase.emit("COUNTDOWN", _phase_t)


func _process(delta: float) -> void:
    _clock += delta
    match phase:
        Phase.COUNTDOWN:
            _phase_t -= delta
            EventBus.match_phase.emit("COUNTDOWN", maxf(_phase_t, 0.0))
            if _phase_t <= 0.0:
                _begin_live()
        Phase.LIVE, Phase.OVERTIME:
            time_left -= delta
            var sec := int(ceil(time_left))
            if sec != _last_sec:
                _last_sec = sec
                EventBus.match_time.emit(maxf(time_left, 0.0))
            _process_respawns(delta)
            if time_left <= 0.0:
                _time_up()


func _begin_live() -> void:
    phase = Phase.LIVE
    _set_enabled(true)
    EventBus.match_phase.emit("LIVE", 0.0)


func _set_enabled(on: bool) -> void:
    for p in players:
        if p.get("controls_enabled") != null:
            p.set("controls_enabled", on)
        else:
            p.set("enabled", on)


# ---------- 击杀与得分 ----------
func _on_died(victim: Node, attacker: Node, _is_head: bool) -> void:
    if phase != Phase.LIVE and phase != Phase.OVERTIME:
        return
    var vt := int(victim.get("team"))
    _stats[victim.get_instance_id()]["deaths"] += 1
    var kt := -1
    var kn := "—"
    var wn := ""
    if attacker != null:
        kt = int(attacker.get("team"))
        kn = String(attacker.get("display_name"))
        if attacker.has_method("current_weapon_name"):
            wn = String(attacker.call("current_weapon_name"))
    var valid := attacker != null and attacker != victim and kt != vt
    if valid:
        _stats[attacker.get_instance_id()]["kills"] += 1
        score[kt] += 1
        EventBus.match_score.emit(score[0], score[1], kill_limit)
        if attacker == local_player:
            _player_kill()
    if victim == local_player:
        _streak = 0
        _multi = 0
    EventBus.kill_feed.emit(kn, String(victim.get("display_name")), wn, _is_head, kt, vt)
    _respawn_q.append({"node": victim, "t": respawn_delay})
    if valid and (score[kt] >= kill_limit or phase == Phase.OVERTIME):
        _end(kt)


func _player_kill() -> void:
    _streak += 1
    _multi = _multi + 1 if _clock - _multi_t < 4.0 else 1
    _multi_t = _clock
    var text := ""
    match _multi:
        2:
            text = "DOUBLE KILL"
        3:
            text = "TRIPLE KILL"
        4:
            text = "QUAD KILL"
    if _multi >= 5:
        text = "MULTI KILL  x%d" % _multi
    if text == "":
        match _streak:
            3:
                text = "KILLING SPREE"
            5:
                text = "RAMPAGE"
            7:
                text = "UNSTOPPABLE"
            10:
                text = "LEGENDARY"
    if text != "":
        EventBus.streak_banner.emit(text)


func _time_up() -> void:
    if score[0] != score[1]:
        _end(0 if score[0] > score[1] else 1)
    elif phase == Phase.LIVE:
        phase = Phase.OVERTIME
        time_left = overtime_limit
        EventBus.match_phase.emit("OVERTIME", 0.0)
    else:
        _end(-1)


func _end(winner: int) -> void:
    if phase == Phase.ENDED:
        return
    phase = Phase.ENDED
    _set_enabled(false)
    _respawn_q.clear()
    EventBus.match_phase.emit("ENDED", 0.0)
    var rows: Array = []
    for p in players:
        var s: Dictionary = _stats[p.get_instance_id()]
        rows.append({"name": s["name"], "team": s["team"], "kills": s["kills"], "deaths": s["deaths"], "is_player": p == local_player})
    rows.sort_custom(func(a, b): return int(a["kills"]) > int(b["kills"]))
    EventBus.match_ended.emit(winner, rows)


# ---------- 重生 ----------
func _process_respawns(delta: float) -> void:
    for i in range(_respawn_q.size() - 1, -1, -1):
        var e: Dictionary = _respawn_q[i]
        e["t"] = float(e["t"]) - delta
        if e["node"] == local_player:
            EventBus.respawn_timer.emit(maxf(float(e["t"]), 0.0))
        if float(e["t"]) <= 0.0:
            _spawn(e["node"], spawn_protect_time)
            _respawn_q.remove_at(i)


func _spawn(node: Node, protect: float) -> void:
    var team := int(node.get("team"))
    var xf := _pick_spawn(team)
    node.call("respawn_at", xf, protect)


func _pick_spawn(team: int) -> Transform3D:
    var list: Array = spawns[team]
    var best_i := 0
    var best_s := -1e9
    for i in list.size():
        var xf: Transform3D = list[i]
        var dmin := 60.0
        for p in players:
            if int(p.get("team")) != team and bool(p.get("alive")):
                dmin = minf(dmin, xf.origin.distance_to((p as Node3D).global_position))
        var s := dmin + randf() * 5.0
        if _clock - float(_spawn_used.get(team * 100 + i, -99.0)) < 4.0:
            s -= 30.0
        if s > best_s:
            best_s = s
            best_i = i
    _spawn_used[team * 100 + best_i] = _clock
    return list[best_i]


# ---------- 联网/动态人数 ----------
## 中途加入的参赛者（真人替换机器人）
func add_late(node: Node, team: int, display: String) -> void:
    add_combatant(node, team, display)
    _spawn(node, spawn_protect_time)
    if phase == Phase.LIVE or phase == Phase.OVERTIME:
        if node.get("controls_enabled") != null:
            node.set("controls_enabled", true)
        else:
            node.set("enabled", true)
    else:
        if node.get("controls_enabled") != null:
            node.set("controls_enabled", false)
        else:
            node.set("enabled", false)


func remove_combatant(node: Node) -> void:
    players.erase(node)
    _stats.erase(node.get_instance_id())
    for i in range(_respawn_q.size() - 1, -1, -1):
        if _respawn_q[i]["node"] == node:
            _respawn_q.remove_at(i)


## 比赛结束后原地重开（服务器用，不重载场景）
func restart() -> void:
    score = [0, 0]
    _respawn_q.clear()
    _streak = 0
    _multi = 0
    for p in players:
        var s: Dictionary = _stats[p.get_instance_id()]
        s["kills"] = 0
        s["deaths"] = 0
    start()
