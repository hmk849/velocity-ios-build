extends SceneTree
## 集成测试: godot --headless -s tests/nav_check.gd
## 实例化 NEON DISTRICT，等导航烘焙完成后，检查两队出生区之间存在导航路径。
## 需要先用编辑器打开过一次工程（生成 class_name 缓存）。

func _initialize() -> void:
    var scene := load("res://gameplay/maps/neon_district.tscn") as PackedScene
    root.add_child(scene.instantiate())
    await create_timer(8.0).timeout
    var map := root.get_world_3d().navigation_map
    var path := NavigationServer3D.map_get_path(map, Vector3(0, 0, -70), Vector3(0, 0, 70), true)
    print("path points: ", path.size())
    var ok := path.size() > 2
    print("RESULT: ", "PASS" if ok else "FAIL")
    quit(0 if ok else 1)
