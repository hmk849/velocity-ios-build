extends SceneTree
## 无头测试: godot --headless -s tests/ability_check.gd
## 校验 12 名干员的数据: 数量、id 唯一、五种定位都有、每人 被动/主动/终极 齐全且类型合法。

const ACTIVE_TYPES := ["dash", "boost", "scan", "shield", "heal", "smoke", "frag", "mine", "slow", "jumppad"]
const ULT_TYPES := ["overdrive", "scan_all", "barrage", "fortress", "nova", "blackout"]


func _init() -> void:
    var ok := true
    var ids := {}
    var roles := {}
    if Operators.LIST.size() != 12:
        printerr("FAIL operator count: ", Operators.LIST.size())
        ok = false
    for o: Dictionary in Operators.LIST:
        var id := String(o["id"])
        if ids.has(id):
            printerr("FAIL duplicate id: ", id)
            ok = false
        ids[id] = true
        roles[o["role"]] = true
        if not Operators.ROLES.has(o["role"]):
            printerr("FAIL bad role: ", id)
            ok = false
        for k in ["passive", "active", "ult"]:
            if not o.has(k) or not (o[k] as Dictionary).has("name") or not (o[k] as Dictionary).has("desc"):
                printerr("FAIL missing ", k, " for ", id)
                ok = false
        if not ACTIVE_TYPES.has(String(o["active"]["type"])) or float(o["active"]["cd"]) <= 0.0:
            printerr("FAIL bad active: ", id)
            ok = false
        if not ULT_TYPES.has(String(o["ult"]["type"])):
            printerr("FAIL bad ult: ", id)
            ok = false
        print("%-8s %-4s  主动:%s(%s)  终极:%s(%s)" % [o["name"], o["role"], o["active"]["name"], o["active"]["type"], o["ult"]["name"], o["ult"]["type"]])
    for r in Operators.ROLES:
        if not roles.has(r):
            printerr("FAIL role not covered: ", r)
            ok = false
    print("RESULT: ", "PASS" if ok else "FAIL")
    quit(0 if ok else 1)
