#!/usr/bin/env python3
"""生成 data/weapons/*.tres 与 gameplay/weapon/weapon_catalog.gd。
用法: python3 tools/gen_weapons.py   （在工程根目录运行）
每把枪的数值在 SPECS 里；脚本会按类别校验理论 TTK，超出范围会报错。"""
import math, os, random, hashlib

A = "res://data/attachments"
CAT = {
  "AR":      dict(auto=True,  hs=1.5, fo=(25,70,0.7),   mag=30,  rl=2.2, sp=(0.35,1.0), at=0.20, asm=0.35, am=0.70, mv=0.95, pen=0.5, spd=0,   g=0,   rs=0.55, rr=0.35, view=(0.07,0.11,0.75), sights=["iron_sight","red_dot","holo","scope_3x"]),
  "SMG":     dict(auto=True,  hs=1.4, fo=(12,35,0.55),  mag=32,  rl=1.8, sp=(0.6,0.8),  at=0.15, asm=0.35, am=0.85, mv=1.05, pen=0.3, spd=0,   g=0,   rs=0.50, rr=0.25, view=(0.06,0.10,0.50), sights=["iron_sight","red_dot","holo"]),
  "LMG":     dict(auto=True,  hs=1.5, fo=(30,90,0.7),   mag=100, rl=4.5, sp=(0.6,1.6),  at=0.32, asm=0.35, am=0.60, mv=0.88, pen=0.8, spd=0,   g=0,   rs=0.40, rr=0.35, view=(0.09,0.14,0.95), sights=["iron_sight","holo","scope_2x"]),
  "DMR":     dict(auto=False, hs=1.8, fo=(50,140,0.75), mag=15,  rl=2.6, sp=(0.7,1.6),  at=0.26, asm=0.15, am=0.75, mv=0.92, pen=1.0, spd=800, g=3.0, rs=1.60, rr=0.50, view=(0.07,0.12,0.95), sights=["scope_4x","scope_6x","red_dot"]),
  "SNIPER":  dict(auto=False, hs=2.0, fo=(120,400,0.85),mag=5,   rl=3.2, sp=(2.5,3.0),  at=0.32, asm=0.0,  am=0.55, mv=0.88, pen=2.0, spd=700, g=6.0, rs=3.20, rr=1.00, view=(0.07,0.13,1.15), sights=["scope_8x","scope_6x","scope_4x"], bolt=True),
  "SHOTGUN": dict(auto=False, hs=1.4, fo=(6,18,0.15),   mag=6,   rl=2.8, sp=(0.8,1.0),  at=0.20, asm=0.6,  am=0.80, mv=0.97, pen=0.0, spd=0,   g=0,   rs=3.50, rr=0.80, view=(0.08,0.10,0.80), sights=["iron_sight","red_dot"], pellets=8, ps=3.2),
  "PISTOL":  dict(auto=False, hs=1.5, fo=(15,45,0.5),   mag=12,  rl=1.5, sp=(0.5,0.7),  at=0.12, asm=0.35, am=0.90, mv=1.08, pen=0.3, spd=0,   g=0,   rs=1.10, rr=0.30, view=(0.05,0.10,0.30), sights=["iron_sight","red_dot"]),
}
TTK_RANGE = {"AR":(180,300),"SMG":(200,300),"LMG":(280,420),"DMR":(200,460),"SNIPER":(0,1200),"SHOTGUN":(0,900),"PISTOL":(300,520)}

# (id, 显示名, 类别, 覆盖参数)  dmg=单发伤害 rpm=射速
SPECS = [
 ("vx1_rifle","VX-1 RIFLE","AR",dict(dmg=26,rpm=800,range=250,pen=0.5,view=(0.07,0.11,0.75))),
 ("vx2_carbine","VX-2 CARBINE","AR",dict(dmg=24,rpm=900,rl=2.0,mv=1.0,sp=(0.4,1.1),range=220)),
 ("kr4_assault","KR-4 ASSAULT","AR",dict(dmg=30,rpm=650,mag=25,rl=2.4,rs=0.7,fo=(30,80,0.7),range=260)),
 ("arc7_rifle","ARC-7 RIFLE","AR",dict(dmg=28,rpm=720,mag=28,rl=2.3,at=0.22,range=250)),
 ("helix_a","HELIX-A","AR",dict(dmg=25,rpm=850,mag=32,rl=2.1,sp=(0.38,1.0),range=240)),
 ("strata9","STRATA-9","AR",dict(dmg=34,rpm=560,mag=20,rl=2.5,rs=0.9,fo=(35,90,0.75),pen=0.8,range=280)),
 ("nova_ar","NOVA-AR","AR",dict(dmg=22,rpm=1000,mag=35,rl=2.0,rs=0.45,fo=(20,55,0.6),range=200)),
 ("fj16_rifle","FJ-16 RIFLE","AR",dict(dmg=27,rpm=750,mag=30,rl=2.2,range=250)),
 ("vp9_smg","VP-9 SMG","SMG",dict(dmg=21,rpm=1000,range=120,default=["laser"])),
 ("vp12_pdw","VP-12 PDW","SMG",dict(dmg=19,rpm=1100,mag=40,rl=2.0,fo=(10,30,0.5),range=110)),
 ("qs3_smg","QS-3 SMG","SMG",dict(dmg=23,rpm=950,mag=30,rl=1.7,range=120)),
 ("riptide5","RIPTIDE-5","SMG",dict(dmg=17,rpm=1250,mag=45,rl=2.2,rs=0.45,sp=(0.7,0.8),range=100)),
 ("mara_smg","MARA-SMG","SMG",dict(dmg=25,rpm=850,mag=25,rl=1.6,fo=(14,38,0.55),range=125)),
 ("tc20_smg","TC-20 SMG","SMG",dict(dmg=20,rpm=1050,mag=36,rl=1.9,range=115)),
 ("lm5_lmg","LM-5 LMG","LMG",dict(dmg=22,rpm=650,range=300,default=["grip_vertical"])),
 ("lm8_heavy","LM-8 HEAVY","LMG",dict(dmg=28,rpm=520,mag=75,rl=5.0,mv=0.85,range=320)),
 ("bastion_l","BASTION-L","LMG",dict(dmg=24,rpm=600,mag=120,rl=5.2,mv=0.84,rs=0.35,range=300)),
 ("ox200_lmg","OX-200 LMG","LMG",dict(dmg=20,rpm=750,mag=200,rl=6.0,mv=0.82,fo=(25,75,0.65),range=280)),
 ("vr12_dmr","VR-12 DMR","DMR",dict(dmg=48,rpm=330,range=400,default=["comp_muzzle"])),
 ("vr15_marksman","VR-15 MARKSMAN","DMR",dict(dmg=45,rpm=300,mag=20,rl=2.4,spd=850,range=420)),
 ("hawk_d","HAWK-D","DMR",dict(dmg=50,rpm=260,mag=12,rl=2.8,spd=900,g=2.5,range=450)),
 ("talon14","TALON-14","DMR",dict(dmg=40,rpm=360,mag=18,rl=2.5,spd=780,range=400)),
 ("sera_dmr","SERA-DMR","DMR",dict(dmg=36,rpm=400,mag=20,rl=2.3,spd=760,range=380)),
 ("bl7_sniper","BL-7 SNIPER","SNIPER",dict(dmg=95,rpm=52,range=600)),
 ("bl9_longrifle","BL-9 LONGRIFLE","SNIPER",dict(dmg=90,rpm=60,mag=5,rl=3.4,spd=750,g=5.0,range=650)),
 ("vanta_s","VANTA-S","SNIPER",dict(dmg=80,rpm=70,mag=6,rl=3.0,spd=800,g=5.0,mv=0.9,range=600)),
 ("orion50","ORION-50","SNIPER",dict(dmg=120,rpm=38,mag=3,rl=4.0,spd=650,g=7.0,pen=3.0,mv=0.8,rs=4.5,range=700)),
 ("hx8_shotgun","HX-8 SHOTGUN","SHOTGUN",dict(dmg=11,rpm=80,range=60,default=["barrel_long"])),
 ("hx12_auto","HX-12 AUTO","SHOTGUN",dict(dmg=7,pellets=9,rpm=200,auto=True,mag=8,rl=3.2,ps=3.8,rs=2.0,range=50)),
 ("brute_sg","BRUTE-SG","SHOTGUN",dict(dmg=15,rpm=60,mag=4,rl=3.6,fo=(4,12,0.1),ps=3.0,range=45)),
 ("split6","SPLIT-6","SHOTGUN",dict(dmg=10,pellets=10,rpm=70,mag=6,ps=4.2,range=50)),
 ("drake12","DRAKE-12","SHOTGUN",dict(dmg=9,rpm=150,mag=7,rl=3.0,range=55)),
 ("px1_pistol","PX-1 PISTOL","PISTOL",dict(dmg=30,rpm=420,range=90)),
 ("px3_auto","PX-3 AUTO","PISTOL",dict(dmg=17,rpm=900,auto=True,mag=20,rl=1.6,rs=0.7,range=70)),
 ("sidearm_k","SIDEARM-K","PISTOL",dict(dmg=34,rpm=380,mag=10,rl=1.4,range=90)),
 ("vex9","VEX-9","PISTOL",dict(dmg=24,rpm=600,mag=15,rl=1.5,range=85)),
 ("px7_heavy","PX-7 HEAVY","PISTOL",dict(dmg=45,rpm=300,mag=8,rl=1.8,rs=1.8,range=100)),
 ("echo_p","ECHO-P","PISTOL",dict(dmg=28,rpm=500,mag=14,rl=1.5,range=85)),
 ("lynx45","LYNX-45","PISTOL",dict(dmg=38,rpm=340,mag=9,rl=1.6,range=95)),
 ("razor_p","RAZOR-P","PISTOL",dict(dmg=22,rpm=700,mag=18,rl=1.4,range=80)),
]
DEFAULTS_POOL = ["comp_muzzle","grip_vertical","stock_light","ext_mag"]

def f(x):
    if not isinstance(x, float):
        return str(x)
    t = ("%.4f" % x).rstrip("0")
    return t + "0" if t.endswith(".") else t

def recoil(wid, cat, scale, auto):
    r = random.Random(int(hashlib.md5(wid.encode()).hexdigest()[:8], 16))
    n = 8 if auto else 3
    pts, x = [], 0.0
    for i in range(n):
        v = scale * (1.0 - i * (0.06 if auto else 0.0)) * r.uniform(0.9, 1.1)
        x = max(-0.3, min(0.3, x + r.uniform(-0.15, 0.15))) if auto else r.uniform(-0.2, 0.2)
        pts += [round(x, 3), round(v, 3)]
    return pts

def ttk(dmg, pellets, rpm):
    shots = math.ceil(100.0 / (dmg * pellets))
    return (shots - 1) * 60000.0 / rpm

os.makedirs("data/weapons", exist_ok=True)
ids = []
for idx, (wid, name, cat, ov) in enumerate(SPECS):
    c = dict(CAT[cat]); c.update(ov)
    pellets = c.get("pellets", 1)
    t = ttk(c["dmg"], pellets, c["rpm"]); lo, hi = TTK_RANGE[cat]
    assert lo <= t <= hi, f"{wid} TTK {t:.0f} out of {lo}-{hi} for {cat}"
    h = int(hashlib.md5(wid.encode()).hexdigest()[:6], 16)
    r_, g_, b_ = 0.18 + (h & 0xff) / 255 * 0.14, 0.20 + ((h >> 8) & 0xff) / 255 * 0.12, 0.22 + ((h >> 16) & 0xff) / 255 * 0.12
    vx, vy, vz = c["view"]
    vz = round(vz * (0.9 + ((h >> 4) & 15) / 15 * 0.2), 3)
    defaults = c.get("default", [DEFAULTS_POOL[idx % 4]] if idx % 3 == 0 and cat not in ("PISTOL",) else [])
    L = [
      '[gd_resource type="Resource" script_class="WeaponData" load_steps=2 format=3]','',
      '[ext_resource type="Script" path="res://gameplay/weapon/weapon_data.gd" id="1"]','','[resource]','script = ExtResource("1")',
      f'id = "{wid}"', f'display_name = "{name}"', f'category = "{cat}"', f'automatic = {str(c["auto"]).lower()}',
      f'bolt_action = {str(c.get("bolt", False)).lower()}',
      f'damage = {f(float(c["dmg"]))}', f'pellets = {pellets}', f'pellet_spread_deg = {f(float(c.get("ps",0.0)))}',
      f'headshot_mult = {f(float(c["hs"]))}', f'fire_rate_rpm = {f(float(c["rpm"]))}', f'max_range = {f(float(c.get("range",200)))}',
      f'falloff_start = {f(float(c["fo"][0]))}', f'falloff_end = {f(float(c["fo"][1]))}', f'min_damage_mult = {f(float(c["fo"][2]))}',
      f'bullet_speed = {f(float(c["spd"]))}', f'bullet_gravity = {f(float(c["g"]))}', f'penetration = {f(float(c["pen"]))}',
      f'magazine_size = {c["mag"]}', f'reload_time = {f(float(c["rl"]))}', f'move_speed_mult = {f(float(c["mv"]))}',
      f'spread_hip_deg = {f(float(c["sp"][0]))}', f'spread_move_deg = {f(float(c["sp"][1]))}',
      f'ads_time = {f(float(c["at"]))}', f'ads_spread_mult = {f(float(c["asm"]))}', f'ads_move_mult = {f(float(c["am"]))}',
      'recoil_pattern = PackedVector2Array(' + ", ".join(f(x) for x in recoil(wid, cat, c["rs"], c["auto"])) + ')',
      f'recoil_reset_time = {f(float(c["rr"]))}',
      'default_attachment_paths = PackedStringArray(' + ", ".join(f'"{A}/{d}.tres"' for d in defaults) + ')',
      'sight_option_paths = PackedStringArray(' + ", ".join(f'"{A}/{s}.tres"' for s in c["sights"]) + ')',
      f'viewmodel_size = Vector3({f(vx)}, {f(vy)}, {f(vz)})', f'viewmodel_color = Color({r_:.3f}, {g_:.3f}, {b_:.3f}, 1)',
    ]
    open(f"data/weapons/{wid}.tres", "w").write("\n".join(L) + "\n")
    ids.append(wid)
    print(f"{name:16s} {cat:8s} TTK {t:5.0f} ms")

atts = ["iron_sight","red_dot","holo","scope_2x","scope_3x","scope_4x","scope_6x","scope_8x",
        "comp_muzzle","barrel_long","grip_vertical","stock_light","ext_mag","laser"]
with open("gameplay/weapon/weapon_catalog.gd", "w") as fh:
    fh.write("class_name WeaponCatalog\nextends RefCounted\n## 由 tools/gen_weapons.py 生成，请勿手改。导出后 DirAccess 扫不到 res:// 资源，所以用显式清单。\n\n")
    fh.write("const WEAPON_IDS := [\n" + "".join(f'    "{i}",\n' for i in ids) + "]\n\n")
    fh.write("const ATTACHMENT_IDS := [\n" + "".join(f'    "{i}",\n' for i in atts) + "]\n\n")
    fh.write('const CATEGORIES := ["AR", "SMG", "LMG", "DMR", "SNIPER", "SHOTGUN", "PISTOL"]\n\n\n')
    fh.write('static func weapon_path(id: String) -> String:\n    return "res://data/weapons/%s.tres" % id\n\n\n')
    fh.write('static func attachment_path(id: String) -> String:\n    return "res://data/attachments/%s.tres" % id\n\n\n')
    fh.write('static func load_weapon(id: String) -> WeaponData:\n    return load(weapon_path(id)) as WeaponData\n\n\n')
    fh.write('static func load_attachment(id: String) -> AttachmentData:\n    return load(attachment_path(id)) as AttachmentData\n')
print(len(ids), "weapons")
