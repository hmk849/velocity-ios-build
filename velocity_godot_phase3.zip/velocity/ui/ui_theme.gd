class_name UITheme
extends RefCounted
## 统一设计系统: 颜色 / 按钮样式 / 字体。所有界面从 Game.ui_theme 取主题。
## 中文字体: 把 NotoSansSC-Regular.otf 放到 res://assets/fonts/ 即自动启用。

const BG := Color("0e1114")
const PANEL := Color("171b20")
const GUNMETAL := Color("262c33")
const BORDER := Color("3a434c")
const TITANIUM := Color("b9c2cc")
const ICE := Color("7fd3ff")
const WARN := Color("ff7a1a")
const TEXT_DIM := Color("7b8591")
const FONT_PATH := "res://assets/fonts/NotoSansSC-Regular.otf"


static func box(bg: Color, border: Color, border_w := 1, margin := 16) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = bg
    s.border_color = border
    s.set_border_width_all(border_w)
    s.set_corner_radius_all(2)
    s.set_content_margin_all(margin)
    return s


static func build() -> Theme:
    var t := Theme.new()
    if ResourceLoader.exists(FONT_PATH):
        t.default_font = load(FONT_PATH)
    t.default_font_size = 28
    t.set_stylebox("normal", "Button", box(GUNMETAL, BORDER))
    t.set_stylebox("hover", "Button", box(Color("2f373f"), ICE))
    t.set_stylebox("pressed", "Button", box(Color("1c2228"), ICE, 2))
    t.set_stylebox("disabled", "Button", box(Color("1a1e23"), Color("2a3036")))
    t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
    t.set_color("font_color", "Button", TITANIUM)
    t.set_color("font_hover_color", "Button", Color.WHITE)
    t.set_color("font_pressed_color", "Button", Color.WHITE)
    t.set_color("font_disabled_color", "Button", TEXT_DIM)
    t.set_color("font_color", "Label", TITANIUM)
    return t


static func label(text: String, size: int, color: Color) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    return l


## 主按钮（警示橙，只用于每屏唯一的主操作）
static func style_primary(b: Button) -> void:
    b.add_theme_stylebox_override("normal", box(WARN, WARN))
    b.add_theme_stylebox_override("hover", box(Color("ff9244"), Color("ff9244")))
    b.add_theme_stylebox_override("pressed", box(Color("d96410"), Color("d96410")))
    b.add_theme_color_override("font_color", Color("14110d"))
    b.add_theme_color_override("font_hover_color", Color("14110d"))
    b.add_theme_color_override("font_pressed_color", Color("14110d"))
