extends ScreenBase
## 武器工坊（配件改装）: 左 武器列表(按类别筛选) · 中 可旋转/缩放的 3D 枪模 · 右 配件槽位 + 实时属性。
## 属性由 WeaponStats 合成，和对局里实际生效的数值一致。选择保存到 Loadout。
## 枪模是占位几何体（GunModel），换成美术模型后保持挂点即可。

const SLOT_NAMES := {0: "瞄具", 1: "枪口", 2: "枪管", 3: "握把", 4: "枪托", 5: "弹匣", 6: "激光"}

var _wid := ""
var _data: WeaponData
var _cat := "ALL"
var _cache: Dictionary = {}
var _by_slot: Dictionary = {}          # slot -> Array[AttachmentData]
var _slot_opts: Dictionary = {}        # slot -> OptionButton
var _list: VBoxContainer
var _stats: Label
var _title: Label
var _stand: Node3D
var _gun: GunModel
var _cam: Camera3D
var _zoom_slider: HSlider


func _build(root: MarginContainer) -> void:
    _wid = Loadout.primary
    for id in WeaponCatalog.ATTACHMENT_IDS:
        var a := WeaponCatalog.load_attachment(id)
        if a == null:
            continue
        if not _by_slot.has(a.slot):
            _by_slot[a.slot] = []
        (_by_slot[a.slot] as Array).append(a)

    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 16)
    root.add_child(col)

    var top := HBoxContainer.new()
    _title = UITheme.label("武器工坊", 40, UITheme.TITANIUM)
    _title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(_title)
    var back := make_button("返回大厅", false, Vector2(240, 68))
    back.pressed.connect(_back)
    top.add_child(back)
    col.add_child(top)

    var main := HBoxContainer.new()
    main.size_flags_vertical = Control.SIZE_EXPAND_FILL
    main.add_theme_constant_override("separation", 24)
    col.add_child(main)
    main.add_child(_build_left())
    main.add_child(_build_center())
    main.add_child(_build_right())
    _on_zoom(_zoom_slider.value)
    _select(_wid)


# ---------- 左: 武器列表 ----------
func _build_left() -> Control:
    var v := VBoxContainer.new()
    v.custom_minimum_size = Vector2(400, 0)
    v.add_theme_constant_override("separation", 10)
    var ob := OptionButton.new()
    ob.add_item("ALL")
    for c in WeaponCatalog.CATEGORIES:
        ob.add_item(c)
    ob.custom_minimum_size = Vector2(0, 60)
    ob.item_selected.connect(_on_cat.bind(ob))
    v.add_child(ob)
    var scroll := ScrollContainer.new()
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    v.add_child(scroll)
    _list = VBoxContainer.new()
    _list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _list.add_theme_constant_override("separation", 6)
    scroll.add_child(_list)
    _refill_list()
    return v


func _on_cat(idx: int, ob: OptionButton) -> void:
    _cat = ob.get_item_text(idx)
    _refill_list()


func _weapon(id: String) -> WeaponData:
    if not _cache.has(id):
        _cache[id] = WeaponCatalog.load_weapon(id)
    return _cache[id]


func _refill_list() -> void:
    for c in _list.get_children():
        _list.remove_child(c)
        c.queue_free()
    for id in WeaponCatalog.WEAPON_IDS:
        var d := _weapon(id)
        if d == null or (_cat != "ALL" and d.category != _cat):
            continue
        var b := make_button("%s  [%s]" % [d.display_name, d.category], false, Vector2(0, 60))
        b.alignment = HORIZONTAL_ALIGNMENT_LEFT
        b.pressed.connect(_select.bind(id))
        _list.add_child(b)


# ---------- 中: 3D 展示 ----------
func _build_center() -> Control:
    var holder := VBoxContainer.new()
    holder.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    holder.add_theme_constant_override("separation", 8)

    var stage := Control.new()
    stage.size_flags_vertical = Control.SIZE_EXPAND_FILL
    stage.custom_minimum_size = Vector2(400, 400)
    holder.add_child(stage)

    var svc := SubViewportContainer.new()
    svc.stretch = true
    svc.mouse_filter = Control.MOUSE_FILTER_IGNORE
    svc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    stage.add_child(svc)
    var vp := SubViewport.new()
    vp.transparent_bg = true
    vp.own_world_3d = true
    vp.msaa_3d = Viewport.MSAA_DISABLED
    svc.add_child(vp)

    var we := WorldEnvironment.new()
    var env := Environment.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("a0b0c0")
    env.ambient_light_energy = 0.7
    we.environment = env
    vp.add_child(we)
    var light := DirectionalLight3D.new()
    light.rotation_degrees = Vector3(-40, 30, 0)
    vp.add_child(light)
    _cam = Camera3D.new()
    vp.add_child(_cam)
    _stand = Node3D.new()
    vp.add_child(_stand)
    _gun = GunModel.new()
    _stand.add_child(_gun)

    # 拖动旋转的输入层（鼠标或触摸模拟的鼠标）
    var drag := Control.new()
    drag.mouse_filter = Control.MOUSE_FILTER_STOP
    drag.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    drag.gui_input.connect(_on_drag)
    stage.add_child(drag)

    var zr := HBoxContainer.new()
    zr.add_child(UITheme.label("缩放", 22, UITheme.TEXT_DIM))
    _zoom_slider = HSlider.new()
    _zoom_slider.min_value = 0.5
    _zoom_slider.max_value = 2.4
    _zoom_slider.step = 0.05
    _zoom_slider.value = 1.4
    _zoom_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _zoom_slider.custom_minimum_size = Vector2(0, 48)
    _zoom_slider.value_changed.connect(_on_zoom)
    zr.add_child(_zoom_slider)
    holder.add_child(zr)
    holder.add_child(UITheme.label("拖动旋转 · 滑块缩放", 20, UITheme.TEXT_DIM))
    return holder


func _on_zoom(v: float) -> void:
    if _cam == null or not _cam.is_inside_tree():
        return
    _cam.look_at_from_position(Vector3(0, 0.05, v), Vector3.ZERO)


func _on_drag(event: InputEvent) -> void:
    if event is InputEventMouseMotion and (event.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0:
        _stand.rotation.y += event.relative.x * 0.01
        _stand.rotation.x = clampf(_stand.rotation.x + event.relative.y * 0.01, -1.2, 1.2)
    elif event is InputEventMouseButton and event.pressed:
        if event.button_index == MOUSE_BUTTON_WHEEL_UP:
            _zoom_slider.value -= 0.1
        elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
            _zoom_slider.value += 0.1


# ---------- 右: 配件 + 属性 ----------
func _build_right() -> Control:
    var v := VBoxContainer.new()
    v.custom_minimum_size = Vector2(520, 0)
    v.add_theme_constant_override("separation", 8)

    for slot in SLOT_NAMES.keys():
        var row := HBoxContainer.new()
        var l := UITheme.label(String(SLOT_NAMES[slot]), 24, UITheme.TITANIUM)
        l.custom_minimum_size = Vector2(90, 0)
        row.add_child(l)
        var ob := OptionButton.new()
        ob.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        ob.custom_minimum_size = Vector2(0, 56)
        ob.item_selected.connect(_on_attachment.bind(slot))
        row.add_child(ob)
        v.add_child(row)
        _slot_opts[slot] = ob

    _stats = UITheme.label("", 21, UITheme.ICE)
    v.add_child(_stats)

    var btns := HBoxContainer.new()
    btns.add_theme_constant_override("separation", 8)
    var b1 := make_button("设为主武器", true, Vector2(0, 64))
    b1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b1.pressed.connect(_set_slot.bind(true))
    var b2 := make_button("设为副武器", false, Vector2(0, 64))
    b2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b2.pressed.connect(_set_slot.bind(false))
    var b3 := make_button("重置配件", false, Vector2(0, 64))
    b3.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b3.pressed.connect(_reset)
    btns.add_child(b1)
    btns.add_child(b2)
    btns.add_child(b3)
    v.add_child(btns)
    return v


# ---------- 行为 ----------
func _select(id: String) -> void:
    _wid = id
    _data = _weapon(id)
    if _data == null:
        return
    _title.text = "武器工坊 · %s" % _data.display_name
    _fill_options()
    _refresh()


## 当前每个槽位选了什么（路径）: 已自定义用玩家选择，否则用武器默认
func _current_path(slot: int) -> String:
    var c: Variant = Loadout.get_choice(_wid, slot)
    if c != null:
        return String(c)
    if slot == AttachmentData.Slot.SIGHT:
        return _data.sight_option_paths[0] if _data.sight_option_paths.size() > 0 else ""
    for p in _data.default_attachment_paths:
        var a := load(p) as AttachmentData
        if a != null and a.slot == slot:
            return p
    return ""


func _fill_options() -> void:
    for slot in _slot_opts.keys():
        var ob: OptionButton = _slot_opts[slot]
        ob.clear()
        ob.add_item("机械瞄具" if slot == AttachmentData.Slot.SIGHT else "无")
        var items: Array = _by_slot.get(slot, [])
        var cur := _current_path(slot)
        var sel := 0
        for i in items.size():
            var a: AttachmentData = items[i]
            ob.add_item(a.display_name)
            if a.resource_path == cur:
                sel = i + 1
        ob.select(sel)


func _on_attachment(idx: int, slot: int) -> void:
    var path := ""
    if idx > 0:
        var items: Array = _by_slot.get(slot, [])
        path = (items[idx - 1] as AttachmentData).resource_path
    Loadout.set_choice(_wid, slot, path)
    Loadout.save()
    _refresh()


func _refresh() -> void:
    var atts := _attachments_from_options()
    _gun.build(_data, atts)
    _gun.position = Vector3(0, 0, _gun.length * 0.5)       # 把枪身中点放在原点，方便旋转
    var s := WeaponStats.compute(_data, atts)
    var dm := float(s["damage_mult"])
    var recoil := 0.0
    for v in _data.recoil_pattern:
        recoil += v.y
    recoil = recoil / maxf(float(_data.recoil_pattern.size()), 1.0) * float(s["recoil_mult"])
    var dmg_txt := "%.0f" % (_data.damage * dm)
    if _data.pellets > 1:
        dmg_txt += " ×%d" % _data.pellets
    _stats.text = "\n".join([
        "伤害  %s    射速  %d RPM" % [dmg_txt, int(_data.fire_rate_rpm)],
        "TTK  胸 %d ms / 头 %d ms" % [
            int(_data.theoretical_ttk_ms(100.0, false, 0.0, dm)),
            int(_data.theoretical_ttk_ms(100.0, true, 0.0, dm))],
        "射程  %d–%d m" % [int(_data.falloff_start * float(s["range_mult"])), int(_data.falloff_end * float(s["range_mult"]))],
        "弹匣  %d    换弹  %.1f s" % [int(s["mag_size"]), _data.reload_time * float(s["reload_mult"])],
        "开镜  %.2f s    倍率  %.0fx" % [_data.ads_time * float(s["ads_time_mult"]), float(s["zoom"])],
        "平均后坐  %.2f°    移速  %d%%" % [recoil, int(_data.move_speed_mult * float(s["move_mult"]) * 100.0)],
    ])


func _attachments_from_options() -> Array[AttachmentData]:
    var out: Array[AttachmentData] = []
    for slot in _slot_opts.keys():
        var ob: OptionButton = _slot_opts[slot]
        if ob.selected > 0:
            var items: Array = _by_slot.get(slot, [])
            out.append(items[ob.selected - 1])
    return out


func _set_slot(primary: bool) -> void:
    if primary:
        Loadout.primary = _wid
    else:
        Loadout.secondary = _wid
    Loadout.save()
    show_toast("已设为%s: %s" % ["主武器" if primary else "副武器", _data.display_name])


func _reset() -> void:
    Loadout.reset(_wid)
    Loadout.save()
    _select(_wid)
    show_toast("已恢复默认配件")


func _back() -> void:
    SceneRouter.goto("res://ui/lobby/lobby.tscn")
