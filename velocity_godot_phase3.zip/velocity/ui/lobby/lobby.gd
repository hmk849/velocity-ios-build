extends ScreenBase
## 大厅。中央是程序化角色 Puppet（占位模型，动画由代码生成: 呼吸、调整枪械、检查弹匣、环顾）。
## 持有当前主武器与配件。导航里「开始游戏」「武器」「设置」是真实功能，其余明确提示未实现。

const NAV := [
    ["开始游戏", ""],
    ["干员", "第 6 阶段"],
    ["武器", ""],
    ["仓库", "第 6 阶段"],
    ["战斗通行证", "第 7 阶段之后"],
    ["任务", "第 7 阶段之后"],
    ["排行榜", "第 5 阶段之后"],
]

var _mannequin: Node3D
var _t := 0.0


func _build(root: MarginContainer) -> void:
    _build_preview()

    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 24)
    root.add_child(col)
    col.add_child(_build_top_bar())

    var mid := HBoxContainer.new()
    mid.size_flags_vertical = Control.SIZE_EXPAND_FILL
    col.add_child(mid)
    mid.add_child(_build_nav())
    var sp := Control.new()
    sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    mid.add_child(sp)
    mid.add_child(_build_right_panel())

    col.add_child(_build_bottom_bar())


func _process(delta: float) -> void:
    _t += delta
    if _mannequin:
        _mannequin.rotation.y = PI + sin(_t * 0.4) * 0.28      # 面向镜头，缓慢转动


# ---------- 区块 ----------
func _build_top_bar() -> Control:
    var p: Dictionary = AuthService.profile
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 20)

    var avatar := PanelContainer.new()
    avatar.custom_minimum_size = Vector2(76, 76)
    avatar.add_theme_stylebox_override("panel", UITheme.box(UITheme.GUNMETAL, UITheme.ICE, 1, 8))
    var ini := UITheme.label(String(p.nickname).substr(0, 1), 36, UITheme.ICE)
    ini.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    avatar.add_child(ini)
    row.add_child(avatar)

    var info := VBoxContainer.new()
    info.alignment = BoxContainer.ALIGNMENT_CENTER
    info.add_child(UITheme.label(p.nickname, 30, UITheme.TITANIUM))
    info.add_child(UITheme.label("Lv.%d" % p.level, 22, UITheme.TEXT_DIM))
    row.add_child(info)

    var sp := Control.new()
    sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_child(sp)

    var st := make_button("设置", false, Vector2(180, 76))
    st.pressed.connect(_open_settings)
    row.add_child(st)
    return row


func _build_nav() -> Control:
    var v := VBoxContainer.new()
    v.custom_minimum_size = Vector2(340, 0)
    v.add_theme_constant_override("separation", 12)
    for item in NAV:
        var title: String = item[0]
        var b := make_button(title, false, Vector2(0, 74))
        b.alignment = HORIZONTAL_ALIGNMENT_LEFT
        b.pressed.connect(_on_nav.bind(title, item[1]))
        v.add_child(b)
    return v


func _build_right_panel() -> Control:
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(440, 0)
    panel.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
    panel.add_theme_stylebox_override("panel", UITheme.box(Color(UITheme.PANEL, 0.85), UITheme.BORDER, 1, 24))
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 10)
    panel.add_child(v)
    v.add_child(UITheme.label("DEV BUILD  %s" % Game.VERSION, 26, UITheme.ICE))
    v.add_child(UITheme.label("已实现: 游客登录、加载、武器工坊、训练场", 22, UITheme.TITANIUM))
    v.add_child(UITheme.label("未实现: 联网、匹配、干员技能、地图 2-8", 22, UITheme.TEXT_DIM))
    return panel


func _build_bottom_bar() -> Control:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 48)
    row.add_child(_info_block("模式", "训练场 · 自由射击"))
    row.add_child(_info_block("地图", "TEST RANGE"))
    var sp := Control.new()
    sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_child(sp)
    var go := make_button("进入训练场", true, Vector2(400, 92))
    go.pressed.connect(_start)
    row.add_child(go)
    return row


func _info_block(title: String, value: String) -> Control:
    var v := VBoxContainer.new()
    v.add_child(UITheme.label(title, 20, UITheme.TEXT_DIM))
    v.add_child(UITheme.label(value, 30, UITheme.TITANIUM))
    return v


# ---------- 行为 ----------
func _on_nav(title: String, phase: String) -> void:
    if title == "开始游戏":
        _start()
    elif title == "武器":
        SceneRouter.goto("res://ui/workshop/workshop.tscn")
    else:
        show_toast("「%s」尚未实现（规划：%s）" % [title, phase], true)


func _start() -> void:
    SceneRouter.goto_with_loading(
        "res://gameplay/maps/test_range.tscn",
        {"map_name": "TEST RANGE", "mode": "训练场"}
    )


func _open_settings() -> void:
    add_child(SettingsPanel.new())


# ---------- 占位 3D 预览 ----------
func _build_preview() -> void:
    var svc := SubViewportContainer.new()
    svc.stretch = true
    svc.mouse_filter = Control.MOUSE_FILTER_IGNORE
    svc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(svc)
    move_child(svc, 1)   # 在背景之上、UI 之下

    var vp := SubViewport.new()
    vp.transparent_bg = true
    vp.own_world_3d = true
    vp.msaa_3d = Viewport.MSAA_DISABLED
    svc.add_child(vp)

    var we := WorldEnvironment.new()
    var env := Environment.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("8fa0b2")
    env.ambient_light_energy = 0.6
    we.environment = env
    vp.add_child(we)

    var cam := Camera3D.new()
    vp.add_child(cam)
    cam.look_at_from_position(Vector3(0, 1.25, 3.8), Vector3(0, 1.0, 0))

    var light := DirectionalLight3D.new()
    light.rotation_degrees = Vector3(-35, 35, 0)
    vp.add_child(light)

    var pup := Puppet.new()
    pup.idle_events = true
    vp.add_child(pup)
    var d := WeaponCatalog.load_weapon(Loadout.primary)
    if d != null:
        pup.set_weapon(d, WeaponStats.equipped_attachments(d))
    _mannequin = pup
    _mannequin.rotation.y = PI
