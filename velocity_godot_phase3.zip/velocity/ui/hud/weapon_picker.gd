class_name WeaponPicker
extends Control
## 训练场武器选择器: 按类别筛选的全部武器列表，显示理论 TTK。选中后发出 chosen(id)。
## 打开时释放鼠标（桌面），方便点击。

signal chosen(id: String)

var _list: VBoxContainer
var _cat := "ALL"
var _cache: Dictionary = {}


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.75)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(dim)

    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(1000, 0)
    panel.add_theme_stylebox_override("panel", UITheme.box(UITheme.PANEL, UITheme.BORDER, 1, 28))
    center.add_child(panel)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 14)
    panel.add_child(col)

    var head := HBoxContainer.new()
    head.add_theme_constant_override("separation", 20)
    head.add_child(UITheme.label("选择武器", 36, UITheme.TITANIUM))
    var ob := OptionButton.new()
    ob.add_item("ALL")
    for c in WeaponCatalog.CATEGORIES:
        ob.add_item(c)
    ob.custom_minimum_size = Vector2(220, 60)
    ob.item_selected.connect(_on_cat.bind(ob))
    head.add_child(ob)
    col.add_child(head)

    var scroll := ScrollContainer.new()
    scroll.custom_minimum_size = Vector2(0, 560)
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    col.add_child(scroll)
    _list = VBoxContainer.new()
    _list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _list.add_theme_constant_override("separation", 8)
    scroll.add_child(_list)

    var close := Button.new()
    close.text = "关闭"
    close.custom_minimum_size = Vector2(0, 68)
    close.pressed.connect(queue_free)
    col.add_child(close)
    _refill()


func _on_cat(idx: int, ob: OptionButton) -> void:
    _cat = ob.get_item_text(idx)
    _refill()


func _refill() -> void:
    for c in _list.get_children():
        _list.remove_child(c)
        c.queue_free()
    for id in WeaponCatalog.WEAPON_IDS:
        if not _cache.has(id):
            _cache[id] = WeaponCatalog.load_weapon(id)
        var d: WeaponData = _cache[id]
        if d == null or (_cat != "ALL" and d.category != _cat):
            continue
        var b := Button.new()
        b.text = "%s   [%s]   DMG %d%s   RPM %d   TTK %d ms" % [
            d.display_name, d.category, int(d.damage),
            ("×%d" % d.pellets) if d.pellets > 1 else "", int(d.fire_rate_rpm), int(d.theoretical_ttk_ms())]
        b.alignment = HORIZONTAL_ALIGNMENT_LEFT
        b.custom_minimum_size = Vector2(0, 64)
        b.pressed.connect(_pick.bind(id))
        _list.add_child(b)


func _pick(id: String) -> void:
    chosen.emit(id)
    queue_free()
