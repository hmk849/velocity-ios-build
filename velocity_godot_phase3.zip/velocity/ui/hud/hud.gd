class_name HUD
extends Control
## 对局 HUD: 准星、命中标记、瞄具分划与倍镜遮罩、弹药、武器信息、速度/状态、FPS、返回按钮。
## 只订阅 EventBus，不引用 gameplay 类。
## 倍镜遮罩现在是每帧画 72 个多边形，Phase 8 会换成一次绘制的网格/着色器。
## 未实现: 受击方向、击杀播报、伤害数字、血条（Phase 4）。

signal back_requested
signal weapon_chosen(id: String)

const HIT_TIME := 0.18

var _ammo: Label
var _weapon: Label
var _fps: Label
var _speed: Label
var _hit_t := 0.0
var _hit_color := Color.WHITE
var _hit_kill := false
var _ads := 0.0
var _zoom := 1.0
var _reticle := "iron"
var _pip := false


func _ready() -> void:
    theme = Game.ui_theme
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var m := SafeArea.margins(get_viewport())
    var margin := MarginContainer.new()
    margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    margin.add_theme_constant_override("margin_left", int(m.x) + 32)
    margin.add_theme_constant_override("margin_top", int(m.y) + 24)
    margin.add_theme_constant_override("margin_right", int(m.z) + 32)
    margin.add_theme_constant_override("margin_bottom", int(m.w) + 24)
    add_child(margin)

    var col := VBoxContainer.new()
    col.mouse_filter = Control.MOUSE_FILTER_IGNORE
    margin.add_child(col)

    var top := HBoxContainer.new()
    top.mouse_filter = Control.MOUSE_FILTER_IGNORE
    col.add_child(top)
    var left := VBoxContainer.new()
    left.mouse_filter = Control.MOUSE_FILTER_IGNORE
    left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _fps = UITheme.label("", 22, UITheme.TEXT_DIM)
    _speed = UITheme.label("", 22, UITheme.ICE)
    left.add_child(_fps)
    left.add_child(_speed)
    top.add_child(left)
    var pick := Button.new()
    pick.text = "武器"
    pick.custom_minimum_size = Vector2(140, 64)
    pick.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
    pick.pressed.connect(_open_picker)
    top.add_child(pick)
    var back := Button.new()
    back.text = "返回大厅"
    back.custom_minimum_size = Vector2(200, 64)
    back.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
    back.pressed.connect(back_requested.emit)
    top.add_child(back)

    var sp := Control.new()
    sp.mouse_filter = Control.MOUSE_FILTER_IGNORE
    sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
    col.add_child(sp)

    var bottom := VBoxContainer.new()
    bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
    bottom.alignment = BoxContainer.ALIGNMENT_CENTER
    col.add_child(bottom)
    _weapon = UITheme.label("", 22, UITheme.TEXT_DIM)
    _weapon.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _ammo = UITheme.label("", 52, UITheme.TITANIUM)
    _ammo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    bottom.add_child(_weapon)
    bottom.add_child(_ammo)

    EventBus.ammo_changed.connect(_on_ammo)
    EventBus.weapon_changed.connect(_on_weapon)
    EventBus.hit_confirmed.connect(_on_hit)
    EventBus.sight_state.connect(_on_sight)
    EventBus.movement_debug.connect(_on_move_debug)


func _exit_tree() -> void:
    EventBus.ammo_changed.disconnect(_on_ammo)
    EventBus.weapon_changed.disconnect(_on_weapon)
    EventBus.hit_confirmed.disconnect(_on_hit)
    EventBus.sight_state.disconnect(_on_sight)
    EventBus.movement_debug.disconnect(_on_move_debug)


func _process(delta: float) -> void:
    _hit_t = maxf(_hit_t - delta, 0.0)
    _fps.text = ("%d FPS" % int(Performance.get_monitor(Performance.TIME_FPS))) if Settings.show_fps else ""
    queue_redraw()


func _on_ammo(current: int, magazine: int, reloading: bool) -> void:
    _ammo.text = "换弹中…" if reloading else "%d / %d" % [current, magazine]


func _on_weapon(display_name: String, ttk_ms: float, sight_name: String) -> void:
    _weapon.text = "%s  [%s]  TTK %d ms" % [display_name, sight_name, int(ttk_ms)]


func _on_hit(is_head: bool, killed: bool) -> void:
    _hit_t = HIT_TIME
    _hit_kill = killed
    _hit_color = UITheme.WARN if (is_head or killed) else Color.WHITE


func _on_sight(ads_amount: float, zoom: float, reticle: String, pip: bool) -> void:
    _ads = ads_amount
    _zoom = zoom
    _reticle = reticle
    _pip = pip


func _open_picker() -> void:
    var p := WeaponPicker.new()
    p.chosen.connect(_on_picked)
    add_child(p)


func _on_picked(id: String) -> void:
    weapon_chosen.emit(id)


func _on_move_debug(speed: float, state_name: String) -> void:
    _speed.text = "%.1f m/s  ·  %s" % [speed, state_name]


# ---------- 绘制 ----------
func _draw() -> void:
    var c := size * 0.5

    var xhair_a := clampf(1.0 - _ads * 3.0, 0.0, 1.0)
    if xhair_a > 0.0:
        var col := Color(1, 1, 1, 0.9 * xhair_a)
        for d: Vector2 in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
            draw_line(c + d * 10.0, c + d * 22.0, col, 2.5, true)
        draw_circle(c, 1.5, col)

    if _ads > 0.05:
        var scoped := _zoom >= 2.0 and not _pip     # PiP 模式下镜内成像由 3D 镜片负责，不画黑色遮罩
        if scoped:
            _draw_scope_mask(c, _ads)
        _draw_reticle(c, _reticle, _ads, scoped)

    if _hit_t > 0.0:
        var a := _hit_t / HIT_TIME
        var hc := Color(_hit_color, a)
        var r1 := 14.0 + (1.0 - a) * 4.0
        var r2 := r1 + (16.0 if _hit_kill else 9.0)
        for d: Vector2 in [Vector2(1, 1), Vector2(-1, 1), Vector2(1, -1), Vector2(-1, -1)]:
            var n := d.normalized()
            draw_line(c + n * r1, c + n * r2, hc, 3.0, true)


## 倍镜视野遮罩: 圆形视野以外全黑
func _draw_scope_mask(c: Vector2, a: float) -> void:
    var r := size.y * 0.46
    var far := size.length()
    var col := Color(0, 0, 0, a)
    var n := 72
    for i in n:
        var a0 := TAU * float(i) / float(n)
        var a1 := TAU * float(i + 1) / float(n) + 0.01
        var v0 := Vector2(cos(a0), sin(a0))
        var v1 := Vector2(cos(a1), sin(a1))
        draw_colored_polygon(PackedVector2Array([c + v0 * r, c + v1 * r, c + v1 * far, c + v0 * far]), col)
    draw_arc(c, r, 0.0, TAU, 72, Color(0.08, 0.08, 0.08, a), 4.0, true)


func _draw_reticle(c: Vector2, kind: String, a: float, scoped: bool) -> void:
    var red := Color(1.0, 0.22, 0.2, a)
    var blk := Color(0.0, 0.0, 0.0, a)
    var r := size.y * 0.46 if scoped else 90.0
    match kind:
        "red_dot":
            draw_circle(c, 4.0, red)
        "holo":
            draw_arc(c, 22.0, 0.0, TAU, 40, red, 2.0, true)
            draw_circle(c, 2.5, red)
            for d: Vector2 in [Vector2.UP, Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT]:
                draw_line(c + d * 22.0, c + d * 30.0, red, 2.0, true)
        "cross", "mildot":
            var line_col := blk if scoped else red
            for d: Vector2 in [Vector2.UP, Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT]:
                draw_line(c + d * 10.0, c + d * r, line_col, 1.5, true)
                draw_line(c + d * r * 0.6, c + d * r, line_col, 5.0, true)    # 外侧加粗，便于快速对准
            draw_circle(c, 2.0, red)
            if kind == "mildot":
                for k in range(1, 6):
                    for d: Vector2 in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
                        draw_circle(c + d * 38.0 * k, 2.5, line_col)
        "chevron":
            draw_polyline(PackedVector2Array([c + Vector2(-18, 18), c, c + Vector2(18, 18)]), red, 3.0, true)
            draw_circle(c, 2.0, red)
        _:   # iron: 照门 + 准星
            draw_rect(Rect2(c + Vector2(-60, -3), Vector2(36, 6)), blk)
            draw_rect(Rect2(c + Vector2(24, -3), Vector2(36, 6)), blk)
            draw_rect(Rect2(c + Vector2(-2.5, -26), Vector2(5, 26)), blk)
