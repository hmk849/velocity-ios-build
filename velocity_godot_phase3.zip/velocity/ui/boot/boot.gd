extends Control
## 品牌开场: 黑底 → LOGO 渐显 + 粒子 → 自动进入登录。点击/按键可跳过。
## LOGO 目前是文字占位；金属反射扫光、低频电子音需要美术/音频资产。

var _logo: Control
var _done := false


func _ready() -> void:
    theme = Game.ui_theme
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var bg := ColorRect.new()
    bg.color = Color.BLACK
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg)

    var p := CPUParticles2D.new()
    p.position = get_viewport_rect().size * 0.5 + Vector2(0, 170)
    p.amount = 48
    p.lifetime = 3.0
    p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
    p.emission_rect_extents = Vector2(420, 6)
    p.direction = Vector2.UP
    p.spread = 8.0
    p.gravity = Vector2.ZERO
    p.initial_velocity_min = 30.0
    p.initial_velocity_max = 70.0
    p.scale_amount_min = 1.5
    p.scale_amount_max = 3.0
    p.color = Color(UITheme.ICE, 0.7)
    add_child(p)

    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var box := VBoxContainer.new()
    box.alignment = BoxContainer.ALIGNMENT_CENTER
    box.add_theme_constant_override("separation", 6)
    center.add_child(box)
    var l1 := UITheme.label("PROJECT", 34, UITheme.TEXT_DIM)
    l1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    var l2 := UITheme.label("VELOCITY", 128, UITheme.TITANIUM)
    l2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    box.add_child(l1)
    box.add_child(l2)
    _logo = box
    _logo.modulate.a = 0.0

    var tw := create_tween()
    tw.tween_interval(0.4)
    tw.tween_property(_logo, "modulate:a", 1.0, 1.2).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
    tw.tween_interval(1.0)
    tw.tween_callback(_finish)


func _input(event: InputEvent) -> void:
    if (event is InputEventScreenTouch or event is InputEventMouseButton or event is InputEventKey) and event.is_pressed():
        _finish()


func _finish() -> void:
    if _done:
        return
    _done = true
    SceneRouter.goto("res://ui/login/login.tscn")
