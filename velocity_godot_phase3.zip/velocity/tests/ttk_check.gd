extends SceneTree
## 无头测试: godot --headless -s tests/ttk_check.gd
## 逐把校验 WeaponCatalog 里的全部武器: 能加载、id 匹配、配件路径有效、TTK 落在类别目标区间。
## 注意: 需要先用编辑器打开过一次工程（生成 class_name 缓存）。

const TTK_RANGE := {
    "AR": [180.0, 300.0], "SMG": [200.0, 300.0], "LMG": [280.0, 420.0], "DMR": [200.0, 460.0],
    "SNIPER": [0.0, 1200.0], "SHOTGUN": [0.0, 900.0], "PISTOL": [300.0, 520.0],
}


func _init() -> void:
    var ok := true
    var count := 0
    var seen_ids := {}
    for id in WeaponCatalog.WEAPON_IDS:
        var w := WeaponCatalog.load_weapon(id)
        if w == null:
            printerr("FAIL load ", id)
            ok = false
            continue
        count += 1
        if w.id != id:
            printerr("FAIL id mismatch: ", id, " vs ", w.id)
            ok = false
        if seen_ids.has(w.display_name):
            printerr("FAIL duplicate name: ", w.display_name)
            ok = false
        seen_ids[w.display_name] = true
        var chest := w.theoretical_ttk_ms()
        var head := w.theoretical_ttk_ms(100.0, true)
        var far := w.theoretical_ttk_ms(100.0, false, 60.0)
        print("%-16s %-8s chest %5.0f ms | head %5.0f ms | chest@60m %5.0f ms" % [
            w.display_name, w.category, chest, head, far])
        if w.sight_option_paths.is_empty():
            printerr("FAIL no sight options: ", w.display_name)
            ok = false
        for p in w.sight_option_paths + w.default_attachment_paths:
            if (load(p) as AttachmentData) == null:
                printerr("FAIL bad attachment path: ", p)
                ok = false
        var r: Array = TTK_RANGE.get(w.category, [0.0, 9999.0])
        if chest < float(r[0]) or chest > float(r[1]):
            printerr("FAIL TTK out of range for ", w.category, ": ", chest)
            ok = false
    for aid in WeaponCatalog.ATTACHMENT_IDS:
        if WeaponCatalog.load_attachment(aid) == null:
            printerr("FAIL attachment ", aid)
            ok = false
    print("weapons: %d (spec requires >= 40)" % count)
    if count < 40:
        ok = false
    print("RESULT: ", "PASS" if ok else "FAIL")
    quit(0 if ok else 1)
