class_name AttachmentData
extends Resource
## 配件数据。所有配件都是"乘数"，1.0 = 不改变。每个配件真实影响武器参数。
## 瞄具(SIGHT)额外带倍率和分划样式。

enum Slot { SIGHT, MUZZLE, BARREL, GRIP, STOCK, MAGAZINE, LASER }

@export var display_name := "Attachment"
@export var slot: Slot = Slot.SIGHT

@export_group("Sight")
@export var zoom := 1.0
## iron / red_dot / holo / cross / mildot / chevron
@export var reticle := "iron"

@export_group("Modifiers")
@export var damage_mult := 1.0
@export var range_mult := 1.0
@export var recoil_mult := 1.0
@export var hip_spread_mult := 1.0
@export var ads_time_mult := 1.0
@export var reload_mult := 1.0
@export var move_mult := 1.0
@export var bullet_speed_mult := 1.0
@export var mag_bonus := 0
