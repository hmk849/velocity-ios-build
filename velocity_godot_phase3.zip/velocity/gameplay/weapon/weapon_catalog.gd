class_name WeaponCatalog
extends RefCounted
## 由 tools/gen_weapons.py 生成，请勿手改。导出后 DirAccess 扫不到 res:// 资源，所以用显式清单。

const WEAPON_IDS := [
    "vx1_rifle",
    "vx2_carbine",
    "kr4_assault",
    "arc7_rifle",
    "helix_a",
    "strata9",
    "nova_ar",
    "fj16_rifle",
    "vp9_smg",
    "vp12_pdw",
    "qs3_smg",
    "riptide5",
    "mara_smg",
    "tc20_smg",
    "lm5_lmg",
    "lm8_heavy",
    "bastion_l",
    "ox200_lmg",
    "vr12_dmr",
    "vr15_marksman",
    "hawk_d",
    "talon14",
    "sera_dmr",
    "bl7_sniper",
    "bl9_longrifle",
    "vanta_s",
    "orion50",
    "hx8_shotgun",
    "hx12_auto",
    "brute_sg",
    "split6",
    "drake12",
    "px1_pistol",
    "px3_auto",
    "sidearm_k",
    "vex9",
    "px7_heavy",
    "echo_p",
    "lynx45",
    "razor_p",
]

const ATTACHMENT_IDS := [
    "iron_sight",
    "red_dot",
    "holo",
    "scope_2x",
    "scope_3x",
    "scope_4x",
    "scope_6x",
    "scope_8x",
    "comp_muzzle",
    "barrel_long",
    "grip_vertical",
    "stock_light",
    "ext_mag",
    "laser",
]

const CATEGORIES := ["AR", "SMG", "LMG", "DMR", "SNIPER", "SHOTGUN", "PISTOL"]


static func weapon_path(id: String) -> String:
    return "res://data/weapons/%s.tres" % id


static func attachment_path(id: String) -> String:
    return "res://data/attachments/%s.tres" % id


static func load_weapon(id: String) -> WeaponData:
    return load(weapon_path(id)) as WeaponData


static func load_attachment(id: String) -> AttachmentData:
    return load(attachment_path(id)) as AttachmentData
