class_name Ballistics
extends RefCounted
## 弹道追踪: 沿线段做射线检测，处理命中、伤害衰减、穿透。
## hitscan 一次追踪整条射程；弹丸(Bullet)每个物理帧追踪一小段。
##
## 穿透: 障碍物上设置 meta "pen_cost"（数值）。武器 penetration >= pen_cost
## 才能穿过；没有该 meta 的物体不可穿透。每穿一次伤害 × penetration_damage_mult。
##
## st（Dictionary）字段:
##   data: WeaponData, origin: Vector3, dmg_mult, range_mult,
##   penetration, pen_dmg_mult, pens_left: int, dmg_scale, impact: Callable(pos, normal, surface)
##
## 注意: 现在是本地判定。联网后这段必须在服务器上跑（带延迟补偿回溯）。

## 返回 true 表示子弹已终止（命中并停下，或穿透次数耗尽）
static func trace_segment(space: PhysicsDirectSpaceState3D, from: Vector3, to: Vector3,
        exclude: Array[RID], st: Dictionary) -> bool:
    var dir := (to - from).normalized()
    var seg_from := from
    for i in 4:
        var q := PhysicsRayQueryParameters3D.create(seg_from, to)
        q.exclude = exclude
        var hit := space.intersect_ray(q)
        if hit.is_empty():
            return false
        var pos: Vector3 = hit.position
        var col: Object = hit.collider
        var impact: Callable = st["impact"]
        var surface := "flesh" if col is HitZone else String(col.get_meta("surface", "concrete"))
        impact.call(pos, hit.normal, surface)

        if col is HitZone:
            var zone := col as HitZone
            var data: WeaponData = st["data"]
            var dist := (st["origin"] as Vector3).distance_to(pos) / float(st["range_mult"])
            var dmg := data.damage_at(dist) * float(st["dmg_mult"]) * float(st["dmg_scale"])
            if zone.is_head:
                dmg *= data.headshot_mult
            var killed := zone.apply_damage(dmg)
            EventBus.hit_confirmed.emit(zone.is_head, killed)
            return true

        var cost := float(col.get_meta("pen_cost", 1000.0))
        if cost <= float(st["penetration"]) and int(st["pens_left"]) > 0:
            st["pens_left"] = int(st["pens_left"]) - 1
            st["dmg_scale"] = float(st["dmg_scale"]) * float(st["pen_dmg_mult"])
            seg_from = pos + dir * 0.08
            continue
        return true
    return true
