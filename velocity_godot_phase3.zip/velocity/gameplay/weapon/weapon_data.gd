class_name WeaponData
extends Resource
## 单把武器的全部参数（数据驱动，一把枪一个 .tres）。
## 加新枪 = 复制一个 .tres 改数值，不用改代码。

@export var id := ""
@export var display_name := "Unnamed"
## AR / SMG / LMG / DMR / SNIPER / SHOTGUN / PISTOL
@export var category := "AR"
@export var automatic := true
## 栓动（狙击）: 每发后拉机柄
@export var bolt_action := false

@export_group("Damage")
@export var damage := 25.0              # 单发(单颗弹丸)伤害
@export var pellets := 1                # 霰弹枪 > 1
@export var pellet_spread_deg := 0.0
@export var headshot_mult := 1.5
@export var fire_rate_rpm := 800.0
@export var max_range := 200.0
@export var falloff_start := 20.0
@export var falloff_end := 60.0
@export_range(0.0, 1.0) var min_damage_mult := 0.6

@export_group("Ballistics")
## 0 = 即时命中(hitscan)；> 0 = 弹丸飞行，单位 米/秒
@export var bullet_speed := 0.0
## 弹丸下坠加速度（米/秒²）。游戏化数值，不用真实 9.8
@export var bullet_gravity := 0.0
## 穿透力。能穿过 pen_cost <= 穿透力 的薄障碍
@export var penetration := 0.5
@export_range(0.0, 1.0) var penetration_damage_mult := 0.6

@export_group("Handling")
@export var magazine_size := 30
@export var reload_time := 2.0
## 弹匣未空时的战术换弹时间倍率
@export_range(0.3, 1.0) var tactical_reload_mult := 0.8
@export var move_speed_mult := 1.0
@export var spread_hip_deg := 0.4
@export var spread_move_deg := 1.2
@export var ads_time := 0.2
@export_range(0.0, 1.0) var ads_spread_mult := 0.35
@export_range(0.1, 1.0) var ads_move_mult := 0.7

@export_group("Recoil")
## 每发 (水平°, 垂直°)，按发序循环；停火超过 recoil_reset_time 后从头开始
@export var recoil_pattern: PackedVector2Array = PackedVector2Array([
    Vector2(0.0, 0.55), Vector2(0.05, 0.6), Vector2(-0.08, 0.55), Vector2(0.12, 0.5),
    Vector2(-0.1, 0.45), Vector2(0.15, 0.4), Vector2(-0.12, 0.35), Vector2(0.1, 0.3),
])
@export var recoil_reset_time := 0.35

@export_group("Loadout (资源路径)")
## 默认装上的非瞄具配件
@export var default_attachment_paths := PackedStringArray()
## 可切换的瞄具，第一个是默认瞄具
@export var sight_option_paths := PackedStringArray()

@export_group("Viewmodel (占位)")
@export var viewmodel_size := Vector3(0.07, 0.11, 0.7)
@export var viewmodel_color := Color("39424c")


func damage_at(distance: float) -> float:
    if distance <= falloff_start:
        return damage
    var t := clampf((distance - falloff_start) / maxf(falloff_end - falloff_start, 0.001), 0.0, 1.0)
    return damage * lerpf(1.0, min_damage_mult, t)


## 理论 TTK（毫秒）: 第一发在 t=0，之后每发间隔 60000/rpm。
## 霰弹枪按"全部弹丸命中"计算。
func theoretical_ttk_ms(target_health := 100.0, headshot := false, distance := 0.0, dmg_mult := 1.0) -> float:
    var per_shot := damage_at(distance) * dmg_mult * float(pellets) * (headshot_mult if headshot else 1.0)
    var shots := ceili(target_health / per_shot)
    return float(maxi(shots - 1, 0)) * 60000.0 / fire_rate_rpm
