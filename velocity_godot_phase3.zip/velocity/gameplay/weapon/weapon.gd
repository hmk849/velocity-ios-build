class_name Weapon
extends Node3D
## 武器运行时（挂在相机下）。
## 射击(hitscan / 弹丸) + 穿透 + 后坐力 + 散布 + ADS + 配件乘数 + 瞄具切换 +
## 机械动画(GunModel) + 抛壳/枪口粒子/弹孔 + 倍镜 PiP(可选)。
## 瞄镜方案由 Settings.scope_pip 决定: 关=单画面 FOV 缩放+HUD 遮罩；开=镜内成像。
## 注意: 单机本地判定；联网后命中判定必须搬到服务器（Phase 5）。

signal gun_rebuilt
signal reload_started(duration: float, empty: bool)
signal fired

const HIP_POS := Vector3(0.2, -0.2, -0.3)

var data: WeaponData
var ammo := 0
var ads_t := 0.0                    # 0=腰射 1=完全开镜
var zoom := 1.0
var reticle := "iron"
var player: Player
var camera: Camera3D
var attachments: Array[AttachmentData] = []
var stats: Dictionary = {}

var _sight_options: Array[AttachmentData] = []
var _sight_idx := 0
var _sight_store: Dictionary = {}
var _ammo_store: Dictionary = {}

var _cooldown := 0.0
var _reload_left := 0.0
var _shot_index := 0
var _since_last := 99.0
var _fire_prev := false
var _viewmodel_on := true
var _rng := RandomNumberGenerator.new()

var _pivot: Node3D
var _gun: GunModel
var _flash: OmniLight3D
var _muzzle_fx: CPUParticles3D
var _pip: ScopePip
var _reload_tween: Tween


func _ready() -> void:
    _rng.randomize()
    _pivot = Node3D.new()
    _pivot.position = HIP_POS
    add_child(_pivot)
    _gun = GunModel.new()
    _pivot.add_child(_gun)

    _flash = OmniLight3D.new()
    _flash.omni_range = 4.0
    _flash.light_color = Color("ffcc88")
    _flash.light_energy = 0.0
    _flash.light_cull_mask = 1       # 不照亮第 2 层的枪模自己，避免枪模过曝
    _muzzle_fx = CPUParticles3D.new()
    var pm := SphereMesh.new()
    pm.radius = 0.008
    pm.height = 0.016
    pm.radial_segments = 4
    pm.rings = 2
    var pmat := StandardMaterial3D.new()
    pmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    pmat.albedo_color = Color("ffb060")
    pm.material = pmat
    _muzzle_fx.mesh = pm
    _muzzle_fx.layers = 2
    _muzzle_fx.amount = 8
    _muzzle_fx.lifetime = 0.09
    _muzzle_fx.one_shot = true
    _muzzle_fx.explosiveness = 1.0
    _muzzle_fx.direction = Vector3(0, 0, -1)
    _muzzle_fx.spread = 25.0
    _muzzle_fx.initial_velocity_min = 3.0
    _muzzle_fx.initial_velocity_max = 6.0
    _muzzle_fx.gravity = Vector3.ZERO
    _muzzle_fx.emitting = false

    if Settings.scope_pip:
        _pip = ScopePip.new()
        _pip.main_camera = camera
        add_child(_pip)


func set_viewmodel_visible(v: bool) -> void:
    _viewmodel_on = v


func gun_model() -> GunModel:
    return _gun


# ---------- 装备 / 配件 ----------
func equip(d: WeaponData) -> void:
    if data != null:
        _ammo_store[data.id] = ammo
        _sight_store[data.id] = _sight_idx
    data = d
    _load_attachments()
    _apply_sight()

    ammo = int(_ammo_store.get(d.id, int(stats["mag_size"])))
    _reload_left = 0.0
    _cooldown = 0.2
    _shot_index = 0
    ads_t = 0.0
    if _reload_tween:
        _reload_tween.kill()
    _pivot.rotation = Vector3.ZERO
    _rebuild_gun()
    _emit_status()
    _emit_ammo()


## 默认配件 → 被玩家配置（Loadout）覆盖
func _load_attachments() -> void:
    attachments.clear()
    _sight_options.clear()
    var chosen: Dictionary = {}
    for p in data.default_attachment_paths:
        var a := load(p) as AttachmentData
        if a != null:
            chosen[a.slot] = a
    if Loadout.has_custom(data.id):
        for slot in range(1, 7):
            var c: Variant = Loadout.get_choice(data.id, slot)
            if c == null:
                continue
            if String(c) == "":
                chosen.erase(slot)
            else:
                var a2 := load(String(c)) as AttachmentData
                if a2 != null:
                    chosen[slot] = a2
    for a in chosen.values():
        attachments.append(a)

    for p in data.sight_option_paths:
        var s := load(p) as AttachmentData
        if s != null:
            _sight_options.append(s)
    var idx := 0
    var sc: Variant = Loadout.get_choice(data.id, AttachmentData.Slot.SIGHT)
    if sc != null:
        var sp := String(sc) if String(sc) != "" else WeaponCatalog.attachment_path("iron_sight")
        var found := -1
        for i in _sight_options.size():
            if _sight_options[i].resource_path == sp:
                found = i
        if found < 0:
            var sa := load(sp) as AttachmentData
            if sa != null:
                _sight_options.append(sa)
                found = _sight_options.size() - 1
        if found >= 0:
            idx = found
    _sight_idx = clampi(int(_sight_store.get(data.id, idx)), 0, maxi(_sight_options.size() - 1, 0))


func cycle_sight() -> void:
    if data == null or _sight_options.size() < 2:
        return
    _sight_idx = (_sight_idx + 1) % _sight_options.size()
    _apply_sight()
    _rebuild_gun()
    _emit_status()


func _apply_sight() -> void:
    for i in range(attachments.size() - 1, -1, -1):
        if attachments[i].slot == AttachmentData.Slot.SIGHT:
            attachments.remove_at(i)
    if _sight_options.size() > 0:
        attachments.append(_sight_options[_sight_idx])
    stats = WeaponStats.compute(data, attachments)
    zoom = float(stats["zoom"])
    reticle = String(stats["reticle"])


func _rebuild_gun() -> void:
    if _pip != null:
        _pip.detach()
    for n in [_flash, _muzzle_fx]:
        if n.get_parent() != null:
            n.get_parent().remove_child(n)
    _gun.build(data, attachments)
    _gun.muzzle.add_child(_flash)
    _gun.muzzle.add_child(_muzzle_fx)
    if _pip != null and _gun.scope_lens_anchor != null:
        _pip.attach(_gun.scope_lens_anchor)
    gun_rebuilt.emit()


func move_multiplier() -> float:
    return data.move_speed_mult * float(stats["move_mult"]) if data != null else 1.0


func is_reloading() -> bool:
    return _reload_left > 0.0


func uses_pip() -> bool:
    return Settings.scope_pip and zoom >= 2.0


## 主相机在开镜时使用的倍率（PiP 模式下主视野只轻微收窄）
func main_zoom() -> float:
    return 1.25 if uses_pip() else zoom


func inspect() -> void:
    if data == null or _reload_left > 0.0 or ads_t > 0.1:
        return
    _gun.anim_inspect()


# ---------- 每帧 ----------
func _process(delta: float) -> void:
    if data == null or player == null:
        return
    var want := player.wants_ads() and _reload_left <= 0.0
    var secs := maxf(data.ads_time * float(stats["ads_time_mult"]), 0.05)
    ads_t = move_toward(ads_t, 1.0 if want else 0.0, delta / secs)
    if ads_t > 0.05:
        _gun.cancel_inspect()

    # ADS 位置: 让所选瞄具的光轴对齐屏幕中心
    var ads_pos := Vector3(0.0, -_gun.sight_height, -0.3)
    _pivot.position = HIP_POS.lerp(ads_pos, ads_t)

    var pip := uses_pip()
    if _pip != null:
        _pip.set_active(pip and ads_t > 0.15, zoom, Settings.fov)
    _pivot.visible = _viewmodel_on and not (zoom >= 2.0 and ads_t > 0.6 and not pip)
    EventBus.sight_state.emit(ads_t, zoom, reticle, pip)


func _physics_process(delta: float) -> void:
    if data == null or player == null:
        return
    _cooldown = maxf(_cooldown - delta, 0.0)
    _since_last += delta

    var fire := player.is_fire_held()
    var fire_edge := fire and not _fire_prev
    _fire_prev = fire
    var reload_req := player.consume_reload()

    if _reload_left > 0.0:
        _reload_left -= delta
        if _reload_left <= 0.0:
            _reload_left = 0.0
            ammo = int(stats["mag_size"])
            _emit_ammo()
        return
    if reload_req:
        start_reload()
        return
    if ammo <= 0:
        start_reload()
        return
    if _cooldown > 0.0:
        return
    if (data.automatic and fire) or fire_edge:
        _fire()


func start_reload() -> void:
    var mag := int(stats["mag_size"])
    if _reload_left > 0.0 or ammo >= mag:
        return
    var empty := ammo <= 0
    var dur := data.reload_time * float(stats["reload_mult"])
    if not empty:
        dur *= data.tactical_reload_mult      # 战术换弹更快
    _reload_left = dur
    _emit_ammo()
    _gun.cancel_inspect()
    _gun.anim_reload(dur, empty)
    reload_started.emit(dur, empty)
    if _reload_tween:
        _reload_tween.kill()
    _reload_tween = create_tween()
    _reload_tween.tween_property(_pivot, "rotation:x", -0.5, 0.2)
    _reload_tween.tween_interval(maxf(dur - 0.4, 0.0))
    _reload_tween.tween_property(_pivot, "rotation:x", 0.0, 0.2)


# ---------- 射击 ----------
func _current_spread_deg() -> float:
    var s := data.spread_hip_deg * float(stats["hip_spread_mult"]) + data.spread_move_deg * player.speed_ratio()
    if not player.is_on_floor():
        s += 1.2
    return s * lerpf(1.0, data.ads_spread_mult, ads_t)


func _fire() -> void:
    ammo -= 1
    _cooldown = 60.0 / data.fire_rate_rpm
    if _since_last > data.recoil_reset_time:
        _shot_index = 0
    _since_last = 0.0
    _gun.cancel_inspect()

    var origin := camera.global_position
    var ex: Array[RID] = [player.get_rid()]
    var space := get_world_3d().direct_space_state
    var base_spread := _current_spread_deg()
    var speed := data.bullet_speed * float(stats["bullet_speed_mult"])
    var reach := data.max_range * float(stats["range_mult"])

    for i in data.pellets:
        var cone := base_spread + (data.pellet_spread_deg if data.pellets > 1 else 0.0)
        var dir := _spread_dir(cone)
        var st := {
            "data": data,
            "origin": origin,
            "dmg_mult": float(stats["damage_mult"]),
            "range_mult": float(stats["range_mult"]),
            "penetration": data.penetration,
            "pen_dmg_mult": data.penetration_damage_mult,
            "pens_left": 2,
            "dmg_scale": 1.0,
            "impact": _spawn_impact,
        }
        if speed <= 0.0:
            Ballistics.trace_segment(space, origin, origin + dir * reach, ex, st)
        else:
            var b := Bullet.new()
            b.velocity = dir * speed
            b.gravity = data.bullet_gravity
            b.max_range = reach
            b.state = st
            b.exclude = ex
            get_tree().current_scene.add_child(b)
            b.global_position = origin

    var kick: Vector2 = data.recoil_pattern[_shot_index % data.recoil_pattern.size()]
    var m := float(stats["recoil_mult"]) * lerpf(1.0, 0.8, ads_t)
    player.add_look(deg_to_rad(-kick.x * m), deg_to_rad(kick.y * m))
    _shot_index += 1
    _kick_viewmodel()
    _muzzle_fx.restart()
    _muzzle_fx.emitting = true
    _gun.anim_fire(_cooldown)
    # 抛壳: 栓动/泵动在拉机柄时抛，其余立即抛
    if data.bolt_action or data.category == "SHOTGUN":
        get_tree().create_timer(0.3).timeout.connect(_eject_shell)
    else:
        _eject_shell()
    fired.emit()
    _emit_ammo()


func _eject_shell() -> void:
    if _gun != null and _gun.eject_port != null and is_inside_tree():
        ImpactFx.eject_shell(get_tree().current_scene, _gun.eject_port.global_transform, data.category != "SHOTGUN")


func _spread_dir(deg: float) -> Vector3:
    var cam_basis := camera.global_transform.basis
    var ang := _rng.randf() * TAU
    var mag := sqrt(_rng.randf()) * deg_to_rad(deg)
    var local := Vector3(cos(ang) * sin(mag), sin(ang) * sin(mag), -cos(mag))
    return (cam_basis * local).normalized()


func _kick_viewmodel() -> void:
    _gun.position = Vector3(0.0, 0.012, 0.06 * (1.0 - ads_t * 0.5))
    var tw := create_tween()
    tw.tween_property(_gun, "position", Vector3.ZERO, 0.09)
    _flash.light_energy = 3.0
    var tw2 := create_tween()
    tw2.tween_property(_flash, "light_energy", 0.0, 0.05)


func _spawn_impact(pos: Vector3, normal: Vector3, surface: String) -> void:
    ImpactFx.impact(get_tree().current_scene, pos, normal, surface)


func _emit_ammo() -> void:
    EventBus.ammo_changed.emit(ammo, int(stats["mag_size"]), _reload_left > 0.0)


func _emit_status() -> void:
    EventBus.weapon_changed.emit(
        data.display_name,
        data.theoretical_ttk_ms(100.0, false, 0.0, float(stats["damage_mult"])),
        String(stats["sight_name"]))
