class_name ScopePip
extends Node3D
## 倍镜镜内成像（双画面 PiP）: SubViewport + 同步相机，把放大后的画面贴到镜片上。
## 比单画面 FOV 缩放贵一整次场景渲染，所以只在 Settings.scope_pip 开启、
## 且当前瞄具倍率 >= 2、正在开镜时才渲染；其余时间 SubViewport 不更新。
## 镜片着色器: 圆形裁切 + 染色 + 边缘暗角 + 斜向反光条。视差未实现。
## 如果镜内画面上下颠倒，在着色器里把 UV.y 改成 1.0 - UV.y。

const SHADER_CODE := """
shader_type spatial;
render_mode unshaded, cull_disabled;
uniform sampler2D scope_tex : source_color, filter_linear;
uniform vec4 tint : source_color = vec4(0.88, 1.0, 0.94, 1.0);
uniform float vignette = 0.6;
void fragment() {
    vec2 uv = UV - vec2(0.5);
    float r = length(uv) * 2.0;
    if (r > 1.0) { discard; }
    vec3 c = texture(scope_tex, UV).rgb * tint.rgb;
    c *= 1.0 - vignette * smoothstep(0.6, 1.0, r);
    float streak = smoothstep(0.07, 0.0, abs(uv.x + uv.y * 0.6 - 0.2));
    c += vec3(0.10, 0.12, 0.14) * streak;
    ALBEDO = c;
}
"""

var main_camera: Camera3D

var _vp: SubViewport
var _cam: Camera3D
var _lens: MeshInstance3D
var _active := false
var _fov := 20.0


func _ready() -> void:
    _vp = SubViewport.new()
    _vp.size = Vector2i(512, 512)
    _vp.render_target_update_mode = SubViewport.UPDATE_DISABLED
    _vp.msaa_3d = Viewport.MSAA_DISABLED
    add_child(_vp)

    _cam = Camera3D.new()
    _cam.cull_mask = 1          # 只渲染第 1 层；枪模在第 2 层
    _cam.near = 0.1
    _vp.add_child(_cam)

    _lens = MeshInstance3D.new()
    var q := QuadMesh.new()
    q.size = Vector2(0.15, 0.15)
    _lens.mesh = q
    var sh := Shader.new()
    sh.code = SHADER_CODE
    var mat := ShaderMaterial.new()
    mat.shader = sh
    mat.set_shader_parameter("scope_tex", _vp.get_texture())
    _lens.material_override = mat
    _lens.layers = 2
    _lens.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    _lens.visible = false


func attach(anchor: Node3D) -> void:
    detach()
    anchor.add_child(_lens)


## 枪模重建前必须调用，否则镜片会随旧挂点一起被释放
func detach() -> void:
    if _lens != null and _lens.get_parent() != null:
        _lens.get_parent().remove_child(_lens)


func set_active(on: bool, zoom: float, base_fov: float) -> void:
    if on != _active:
        _active = on
        _vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS if on else SubViewport.UPDATE_DISABLED
        _lens.visible = on
    if on:
        _fov = rad_to_deg(2.0 * atan(tan(deg_to_rad(base_fov) * 0.5) / zoom))


func _process(_delta: float) -> void:
    if _active and main_camera != null:
        _cam.global_transform = main_camera.global_transform
        _cam.fov = _fov
