class_name Bullet
extends Node3D
## 飞行弹丸（狙击/精确射手步枪等）。每个物理帧沿速度方向追踪一小段，
## 带重力下坠。命中/穿透逻辑复用 Ballistics。
## 当前每发实例化一个节点，没有对象池（Phase 8 优化）。

var velocity := Vector3.ZERO
var gravity := 0.0
var max_range := 300.0
var state: Dictionary = {}
var exclude: Array[RID] = []

var _travelled := 0.0


func _ready() -> void:
    var mi := MeshInstance3D.new()
    var s := SphereMesh.new()
    s.radius = 0.035
    s.height = 0.07
    s.radial_segments = 6
    s.rings = 3
    mi.mesh = s
    var m := StandardMaterial3D.new()
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.albedo_color = Color("ffd9a0")
    mi.material_override = m
    add_child(mi)


func _physics_process(delta: float) -> void:
    var from := global_position
    velocity.y -= gravity * delta
    var to := from + velocity * delta
    var space := get_world_3d().direct_space_state
    if Ballistics.trace_segment(space, from, to, exclude, state):
        queue_free()
        return
    global_position = to
    _travelled += velocity.length() * delta
    if _travelled > max_range:
        queue_free()
