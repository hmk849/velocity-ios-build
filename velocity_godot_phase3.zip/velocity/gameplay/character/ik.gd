class_name IK
extends RefCounted
## 解析式双骨 IK（手臂 / 腿）。纯数学，不依赖节点。

## root: 根关节位置；target: 末端目标；l1/l2: 两段骨长；
## pole: 中间关节(肘/膝)朝向的方向提示（方向向量，不是点）。
## 返回 [中间关节位置, 末端位置]；目标超出可达范围时末端被限制在最大伸展处。
static func solve_two_bone(root: Vector3, target: Vector3, l1: float, l2: float, pole: Vector3) -> PackedVector3Array:
    var to := target - root
    var dist := to.length()
    var dir := to / dist if dist > 0.0001 else Vector3.FORWARD
    dist = clampf(dist, absf(l1 - l2) + 0.001, l1 + l2 - 0.001)
    var a := (l1 * l1 - l2 * l2 + dist * dist) / (2.0 * dist)   # 中间关节在 dir 上的投影距离
    var h := sqrt(maxf(l1 * l1 - a * a, 0.0))
    var p := pole - dir * pole.dot(dir)                           # 取垂直于 dir 的分量
    if p.length() < 0.001:
        p = dir.cross(Vector3.RIGHT)
        if p.length() < 0.001:
            p = dir.cross(Vector3.UP)
    p = p.normalized()
    return PackedVector3Array([root + dir * a + p * h, root + dir * dist])
