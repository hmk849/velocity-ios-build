class_name HitZone
extends StaticBody3D
## 命中区域（躯干/头）。射线打到它，把伤害转发给所属目标。

@export var is_head := false
var target: Node


## 返回是否击杀
func apply_damage(amount: float) -> bool:
    if target != null and target.has_method("take_damage"):
        return target.take_damage(amount)
    return false
