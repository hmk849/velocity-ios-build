class_name Player
extends CharacterBody3D
## 第一人称角色（可切第三人称）。状态: GROUND / AIR / SLIDE / WALL_RUN / MANTLE / GRAPPLE / ZIPLINE。
## 已实现: 走、冲刺、跳、二段跳、滑铲、滑铲跳、斜坡滑铲加速、空中动量与转向、
##         蹬墙跑、墙跳、翻越/攀爬(Mantle)、钩爪、滑索、落地缓冲、ADS 灵敏度/移速/FOV、瞄镜晃动、
##         第三人称程序化角色(Puppet，手臂/腿 IK)。
## 未实现: 骨骼蒙皮动画资产。
## 注意: 本地单机逻辑。联网时需改成「输入 → 预测 → 服务器校正」（Phase 5）。

enum State { GROUND, AIR, SLIDE, WALL_RUN, MANTLE, GRAPPLE, ZIPLINE }
const STATE_NAMES := ["GROUND", "AIR", "SLIDE", "WALL RUN", "MANTLE", "GRAPPLE", "ZIPLINE"]

const MOUSE_RAD := 0.0022
const TOUCH_RAD := 0.0035
const MAX_PITCH := 1.5359   # 88°

@export_group("Movement")
@export var walk_speed := 6.0
@export var sprint_speed := 9.5
@export var ground_accel := 70.0
@export var ground_decel := 50.0
@export var overspeed_decel := 10.0    # 超过目标速度时的缓慢衰减（保留动量）
@export var air_accel := 14.0
@export var gravity := 24.0
@export var jump_velocity := 7.5
@export var max_air_jumps := 1
@export var stand_eye := 1.65
@export var slide_eye := 0.9

@export_group("Slide")
@export var slide_boost := 3.0
@export var slide_max_speed := 13.0
@export var slide_decel := 6.0
@export var slide_steer := 2.0
@export var slide_min_speed := 4.0
@export var slide_max_time := 1.1
@export var slope_gain := 38.0         # 下坡加速（m/s² / 坡度）
@export var slope_max_speed := 18.0

@export_group("Wall run")
@export var wall_run_min_speed := 5.5
@export var wall_run_speed := 10.0
@export var wall_run_max_speed := 16.0
@export var wall_run_max_time := 2.2
@export var wall_gravity_scale := 0.12
@export var wall_check_dist := 0.75
@export var wall_stick := 2.0
@export var wall_jump_push := 6.5
@export var wall_jump_up := 7.0

@export_group("Mantle")
@export var mantle_reach := 0.9
@export var mantle_min_height := 0.55
@export var mantle_max_height := 2.4
@export var mantle_time := 0.3

@export_group("Grapple")
@export var grapple_range := 45.0
@export var grapple_speed := 24.0
@export var grapple_accel := 55.0
@export var grapple_max_time := 2.5
@export var grapple_cooldown := 1.5
@export var grapple_stop_dist := 2.5

@export_group("Zipline")
@export var zipline_reach := 1.7
@export var zipline_hand_height := 1.95
@export var zipline_accel := 14.0

var state := State.GROUND
var touch: TouchControls = null        # 手机上由地图注入
var loadout: Array[WeaponData] = []
var weapon: Weapon
var head: Node3D
var camera: Camera3D

var yaw := 0.0
var pitch := 0.0

var _move_input := Vector2.ZERO        # x=右, y=前
var _wish_dir := Vector3.ZERO
var _wish_mag := 0.0
var _sprinting := false
var _jump_pressed := false
var _slide_pressed := false
var _slide_held := false
var _grapple_pressed := false
var _use_pressed := false
var _touch_ads := false

var _slide_t := 0.0
var _slide_cd := 0.0
var _air_jumps := 0
var _slot := 0
var _spawn_pos := Vector3.ZERO
var _base_fov := 90.0

var _wall_normal := Vector3.ZERO
var _wall_side := 0.0                  # +1 墙在右, -1 墙在左
var _wall_run_t := 0.0
var _wall_cd := 0.0

var _mantle_from := Vector3.ZERO
var _mantle_to := Vector3.ZERO
var _mantle_t := 0.0
var _mantle_dur := 0.35
var _mantle_keep := Vector3.ZERO
var _mantle_cd := 0.0

var _grapple_point := Vector3.ZERO
var _grapple_t := 0.0
var _grapple_cd := 0.0
var _rope: MeshInstance3D
var _rope_mesh: ImmediateMesh

var _zip: Zipline
var _zip_t := 0.0
var _zip_dir := 1.0
var _zip_speed := 0.0
var _zip_cd := 0.0
var _zip_age := 0.0

var third_person := false
var puppet: Puppet
var _land_dip := 0.0

var _roll := 0.0
var _sway_t := 0.0
var _dbg_t := 0.0
var _probe_shape: CapsuleShape3D


func _ready() -> void:
    _spawn_pos = position
    _base_fov = Settings.fov

    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.4
    cap.height = 1.8
    cs.shape = cap
    cs.position.y = 0.9
    add_child(cs)

    _probe_shape = CapsuleShape3D.new()
    _probe_shape.radius = 0.38
    _probe_shape.height = 1.7

    head = Node3D.new()
    head.position.y = stand_eye
    add_child(head)
    camera = Camera3D.new()
    camera.fov = _base_fov
    camera.near = 0.05
    head.add_child(camera)

    _rope_mesh = ImmediateMesh.new()
    _rope = MeshInstance3D.new()
    _rope.mesh = _rope_mesh
    var rm := StandardMaterial3D.new()
    rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    rm.albedo_color = UITheme.ICE
    _rope.material_override = rm
    _rope.top_level = true
    _rope.visible = false
    add_child(_rope)

    weapon = Weapon.new()
    weapon.player = self
    weapon.camera = camera
    camera.add_child(weapon)
    puppet = Puppet.new()
    puppet.visible = false
    add_child(puppet)
    weapon.gun_rebuilt.connect(_on_gun_rebuilt)
    weapon.reload_started.connect(_on_reload_started)
    weapon.fired.connect(_on_fired)
    if loadout.size() > 0:
        weapon.equip(loadout[0])

    if not Game.is_mobile:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _exit_tree() -> void:
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


# ---------- 输入 ----------
func _unhandled_input(event: InputEvent) -> void:
    if Game.is_mobile:
        return
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        var k := MOUSE_RAD * Settings.look_sens * _look_scale()
        add_look(-event.relative.x * k, -event.relative.y * k)
    elif event.is_action_pressed("ui_cancel"):
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    elif event is InputEventMouseButton and event.pressed and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func add_look(d_yaw: float, d_pitch: float) -> void:
    yaw += d_yaw
    pitch = clampf(pitch + d_pitch, -MAX_PITCH, MAX_PITCH)


## 开镜时灵敏度随倍率自动降低
func _look_scale() -> float:
    if weapon == null or weapon.ads_t <= 0.0:
        return 1.0
    return lerpf(1.0, Settings.ads_sens / pow(weapon.zoom, 0.6), weapon.ads_t)


func is_fire_held() -> bool:
    return Input.is_action_pressed("fire") or (touch != null and touch.fire_held)


func wants_ads() -> bool:
    return Input.is_action_pressed("ads") or _touch_ads


func consume_reload() -> bool:
    var r := Input.is_action_just_pressed("reload")
    if touch != null and touch.consume("reload"):
        r = true
    return r


func speed_ratio() -> float:
    return clampf(_horizontal_speed() / sprint_speed, 0.0, 1.0)


func _horizontal_speed() -> float:
    return Vector2(velocity.x, velocity.z).length()


func _poll_input() -> void:
    var tv := touch.move_vector if touch != null else Vector2.ZERO
    _move_input = Input.get_vector("move_left", "move_right", "move_back", "move_forward") + tv
    if _move_input.length() > 1.0:
        _move_input = _move_input.normalized()

    var dir := global_transform.basis * Vector3(_move_input.x, 0.0, -_move_input.y)
    dir.y = 0.0
    _wish_dir = dir.normalized()
    _wish_mag = _move_input.length()

    var auto_sprint := Settings.auto_sprint and touch != null \
        and tv.length() > 0.92 and tv.y > 0.3
    _sprinting = Input.is_action_pressed("sprint") or auto_sprint

    _jump_pressed = Input.is_action_just_pressed("jump")
    _slide_pressed = Input.is_action_just_pressed("slide")
    _slide_held = Input.is_action_pressed("slide")
    _grapple_pressed = Input.is_action_just_pressed("grapple")
    _use_pressed = Input.is_action_just_pressed("use")
    var view := Input.is_action_just_pressed("view")
    var inspect := Input.is_action_just_pressed("inspect")
    var swap := Input.is_action_just_pressed("swap")
    var scope := Input.is_action_just_pressed("scope")
    if touch != null:
        _jump_pressed = _jump_pressed or touch.consume("jump")
        _slide_pressed = _slide_pressed or touch.consume("slide")
        _grapple_pressed = _grapple_pressed or touch.consume("grapple")
        swap = swap or touch.consume("swap")
        scope = scope or touch.consume("scope")
        view = view or touch.consume("view")
        inspect = inspect or touch.consume("inspect")
        if touch.consume("ads"):
            _touch_ads = not _touch_ads
    if swap:
        _cycle_weapon()
    if scope and weapon != null:
        weapon.cycle_sight()
    if inspect and weapon != null:
        weapon.inspect()
    if view:
        set_third_person(not third_person)


func _cycle_weapon() -> void:
    if loadout.size() < 2:
        return
    _slot = (_slot + 1) % loadout.size()
    weapon.equip(loadout[_slot])


## 训练场武器选择器: 把当前槽位换成指定武器
func equip_weapon_by_id(id: String) -> void:
    var d := WeaponCatalog.load_weapon(id)
    if d == null or weapon == null:
        return
    if loadout.size() == 0:
        loadout.append(d)
    else:
        loadout[_slot] = d
    weapon.equip(d)


func set_third_person(on: bool) -> void:
    third_person = on
    if puppet != null:
        puppet.visible = on
    if weapon != null:
        weapon.set_viewmodel_visible(not on)
    if not on and camera != null:
        camera.position = Vector3.ZERO


func _on_gun_rebuilt() -> void:
    if puppet != null and weapon != null and weapon.data != null:
        puppet.set_weapon(weapon.data, weapon.attachments)


func _on_reload_started(duration: float, _empty: bool) -> void:
    if puppet != null:
        puppet.start_reload(duration)
        if puppet.gun != null:
            puppet.gun.anim_reload(duration, _empty)


func _on_fired() -> void:
    if puppet != null:
        puppet.kick()
        if puppet.gun != null and weapon != null and weapon.data != null:
            puppet.gun.anim_fire(60.0 / weapon.data.fire_rate_rpm)


# ---------- 帧更新（渲染帧: 视角、相机）----------
func _process(delta: float) -> void:
    if touch != null:
        var d := touch.consume_look()
        if d != Vector2.ZERO:
            var k := TOUCH_RAD * Settings.look_sens * _look_scale()
            add_look(-d.x * k, -d.y * k)

    var ads := weapon.ads_t if weapon != null else 0.0
    var zoom := weapon.zoom if weapon != null else 1.0
    var main_zoom := weapon.main_zoom() if weapon != null else 1.0

    # 高倍镜呼吸晃动：倍率越高、移动越快晃得越大
    _sway_t += delta
    var sway := Vector2.ZERO
    if ads > 0.5 and zoom >= 3.0:
        var amp := 0.0005 * zoom * (1.0 + _horizontal_speed() * 0.3) * ads
        sway = Vector2(sin(_sway_t * 0.9), sin(_sway_t * 1.3 + 1.0)) * amp
    rotation.y = yaw + sway.x
    head.rotation.x = pitch + sway.y

    # 蹬墙跑镜头侧倾（向远离墙的一侧）
    var roll_target := _wall_side * 0.14 if state == State.WALL_RUN else 0.0
    _roll = lerpf(_roll, roll_target, 1.0 - exp(-10.0 * delta))
    head.rotation.z = _roll

    _land_dip = move_toward(_land_dip, 0.0, delta * 0.9)
    var eye := (slide_eye if state == State.SLIDE else stand_eye) - _land_dip
    head.position.y = lerpf(head.position.y, eye, 1.0 - exp(-14.0 * delta))

    var kick := clampf((_horizontal_speed() - walk_speed) * 1.2, 0.0, 8.0)
    var hip_fov := _base_fov + kick
    var ads_fov := rad_to_deg(2.0 * atan(tan(deg_to_rad(_base_fov) * 0.5) / main_zoom))
    camera.fov = lerpf(camera.fov, lerpf(hip_fov, ads_fov, ads), 1.0 - exp(-12.0 * delta))

    _update_rope()
    _update_third_person(delta)


# ---------- 物理帧 ----------
func _physics_process(delta: float) -> void:
    _poll_input()
    _slide_cd = maxf(_slide_cd - delta, 0.0)
    _wall_cd = maxf(_wall_cd - delta, 0.0)
    _mantle_cd = maxf(_mantle_cd - delta, 0.0)
    _grapple_cd = maxf(_grapple_cd - delta, 0.0)

    if _grapple_pressed and state != State.GRAPPLE and state != State.MANTLE:
        _try_grapple()

    _zip_cd = maxf(_zip_cd - delta, 0.0)
    if _use_pressed and (state == State.GROUND or state == State.AIR or state == State.SLIDE):
        _try_zipline()

    if state == State.MANTLE:
        _tick_mantle(delta)
        _emit_debug(delta)
        return
    if state == State.ZIPLINE:
        _tick_zipline(delta)
        _emit_debug(delta)
        return

    if not is_on_floor() and state != State.GRAPPLE and state != State.WALL_RUN:
        velocity.y -= gravity * delta

    var vy_before := velocity.y
    var was_on_floor := is_on_floor()

    match state:
        State.GROUND:
            _tick_ground(delta)
        State.AIR:
            _tick_air(delta)
        State.SLIDE:
            _tick_slide(delta)
        State.WALL_RUN:
            _tick_wall_run(delta)
        State.GRAPPLE:
            _tick_grapple(delta)

    move_and_slide()

    # 落地缓冲: 镜头下沉，只做视觉，不扣速度（动量保持）
    if not was_on_floor and is_on_floor() and vy_before < -5.0:
        _land_dip = clampf(-vy_before * 0.012, 0.0, 0.18)

    if global_position.y < -30.0:
        global_position = _spawn_pos
        velocity = Vector3.ZERO
        state = State.AIR

    _emit_debug(delta)


func _emit_debug(delta: float) -> void:
    _dbg_t += delta
    if _dbg_t >= 0.1:
        _dbg_t = 0.0
        EventBus.movement_debug.emit(_horizontal_speed(), STATE_NAMES[state])


func _speed_mult() -> float:
    if weapon == null or weapon.data == null:
        return 1.0
    return weapon.move_multiplier() * lerpf(1.0, weapon.data.ads_move_mult, weapon.ads_t)


# ---------- 射线 / 形状探测 ----------
func _ray(from: Vector3, to: Vector3) -> Dictionary:
    var q := PhysicsRayQueryParameters3D.create(from, to)
    q.exclude = [get_rid()]
    return get_world_3d().direct_space_state.intersect_ray(q)


func _capsule_blocked(feet_pos: Vector3) -> bool:
    var params := PhysicsShapeQueryParameters3D.new()
    params.shape = _probe_shape
    params.transform = Transform3D(Basis.IDENTITY, feet_pos + Vector3.UP * 0.95)
    params.exclude = [get_rid()]
    return not get_world_3d().direct_space_state.intersect_shape(params, 1).is_empty()


# ---------- GROUND ----------
func _tick_ground(delta: float) -> void:
    if not is_on_floor():
        state = State.AIR
        return
    _air_jumps = max_air_jumps
    if _jump_pressed:
        if _try_mantle():          # 面前有矮墙/平台 → 翻越，而不是普通跳
            return
        velocity.y = jump_velocity
        state = State.AIR
        return
    if _slide_pressed and _slide_cd <= 0.0 and _horizontal_speed() >= walk_speed * 1.1:
        _start_slide()
        return

    var ads_block := weapon != null and weapon.ads_t > 0.3
    var top := sprint_speed if (_sprinting and not ads_block) else walk_speed
    var target := _wish_dir * top * _wish_mag * _speed_mult()
    var h := Vector3(velocity.x, 0.0, velocity.z)
    var rate := ground_accel
    if h.length() > target.length() + 0.01:
        # 无输入 → 快速停下；有输入但超速（例如滑铲落地）→ 缓慢衰减，保留动量
        rate = ground_decel if target.length() < 0.1 else overspeed_decel
    h = h.move_toward(target, rate * delta)
    velocity.x = h.x
    velocity.z = h.z


# ---------- AIR ----------
func _tick_air(delta: float) -> void:
    if is_on_floor() and velocity.y <= 0.0:
        state = State.GROUND
        return

    if _jump_pressed:
        if _try_zipline():
            return
        if _try_mantle():
            return
        if _wall_cd <= 0.0:
            var wj := _find_wall()
            if not wj.is_empty():
                _wall_jump(wj.normal)
                return
        if _air_jumps > 0:
            _air_jumps -= 1
            velocity.y = jump_velocity * 0.9
    elif _move_input.y > 0.3 and velocity.y < 3.0 and _try_mantle():
        return    # 空中朝前撞到可攀爬的边缘 → 自动攀上去

    if _wall_cd <= 0.0 and not is_on_floor() and _move_input.y > 0.1 \
            and _horizontal_speed() >= wall_run_min_speed and velocity.y > -9.0:
        var w := _find_wall()
        if not w.is_empty():
            _begin_wall_run(w)
            return

    var h := Vector3(velocity.x, 0.0, velocity.z)
    var cap := maxf(h.length(), walk_speed)    # 空中可转向，但不会凭空加速
    h += _wish_dir * _wish_mag * air_accel * delta
    if h.length() > cap:
        h = h.normalized() * cap
    velocity.x = h.x
    velocity.z = h.z


# ---------- SLIDE ----------
func _start_slide() -> void:
    state = State.SLIDE
    _slide_t = 0.0
    var h := Vector3(velocity.x, 0.0, velocity.z)
    var spd := minf(maxf(h.length(), sprint_speed) + slide_boost, slide_max_speed)
    var dir := h.normalized()
    velocity.x = dir.x * spd
    velocity.z = dir.z * spd


func _tick_slide(delta: float) -> void:
    _slide_t += delta
    if not is_on_floor():
        state = State.AIR           # 滑出平台边缘，保留动量
        return
    if _jump_pressed:
        if _try_mantle():
            return
        velocity.y = jump_velocity  # 滑铲跳: 水平速度原样保留
        state = State.AIR
        _slide_cd = 0.3
        return

    var n := get_floor_normal()
    var on_slope := n.y < 0.97
    var h := Vector3(velocity.x, 0.0, velocity.z)
    if on_slope:
        h += Vector3(n.x, 0.0, n.z) * slope_gain * delta    # 下坡加速
    var spd := maxf(h.length() - slide_decel * delta, 0.0)
    if on_slope:
        spd = minf(spd, slope_max_speed)
    if h.length() > 0.01:
        var dir := h.normalized()
        if _wish_dir.length() > 0.1:
            dir = dir.slerp(_wish_dir, clampf(slide_steer * delta, 0.0, 1.0)).normalized()
        h = dir * spd
        velocity.x = h.x
        velocity.z = h.z

    var hold_required := not Game.is_mobile
    if spd < slide_min_speed or (_slide_t > slide_max_time and not on_slope) \
            or (hold_required and not _slide_held):
        state = State.GROUND
        _slide_cd = 0.4


# ---------- WALL RUN / WALL JUMP ----------
## 在左右两侧找一堵近似垂直的墙。返回 {} 或 {normal, side, point}
func _find_wall() -> Dictionary:
    var origin := global_position + Vector3.UP * 1.0
    var right := global_transform.basis.x
    var best := {}
    var best_d := 1e9
    for side: float in [-1.0, 1.0]:
        var hit := _ray(origin, origin + right * side * wall_check_dist)
        if hit.is_empty() or hit.collider is HitZone:
            continue
        var n: Vector3 = hit.normal
        if absf(n.y) > 0.25:
            continue
        var d := origin.distance_to(hit.position)
        if d < best_d:
            best_d = d
            best = {"normal": n, "side": side, "point": hit.position}
    return best


func _begin_wall_run(w: Dictionary) -> void:
    state = State.WALL_RUN
    _wall_normal = w.normal
    _wall_side = w.side
    _wall_run_t = 0.0
    velocity.y = maxf(velocity.y, 0.0) * 0.4


func _end_wall_run(cooldown: float) -> void:
    state = State.AIR
    _wall_cd = cooldown
    _wall_side = 0.0


func _tick_wall_run(delta: float) -> void:
    _wall_run_t += delta
    var origin := global_position + Vector3.UP * 1.0
    var hit := _ray(origin, origin - _wall_normal * (wall_check_dist + 0.35))
    var wall_ok := not hit.is_empty() and not (hit.collider is HitZone) and absf(hit.normal.y) <= 0.25
    if is_on_floor() or not wall_ok or _move_input.y < 0.0:
        _end_wall_run(0.25)
        return
    if _wall_run_t > wall_run_max_time:
        _end_wall_run(0.6)
        return
    _wall_normal = hit.normal
    if _jump_pressed:
        _wall_jump(_wall_normal)
        return

    var flat_n := Vector3(_wall_normal.x, 0.0, _wall_normal.z).normalized()
    var along := flat_n.cross(Vector3.UP).normalized()
    if along.dot(-global_transform.basis.z) < 0.0:
        along = -along
    var spd := minf(maxf(_horizontal_speed(), wall_run_speed * 0.9), wall_run_max_speed)
    var h := along * spd - flat_n * wall_stick      # 沿墙前进 + 轻微贴墙
    velocity.x = h.x
    velocity.z = h.z
    velocity.y = maxf(velocity.y - gravity * wall_gravity_scale * delta, -3.0)


func _wall_jump(n: Vector3) -> void:
    var flat_n := Vector3(n.x, 0.0, n.z).normalized()
    var fwd := Vector3(velocity.x, 0.0, velocity.z)
    velocity = fwd * 0.85 + flat_n * wall_jump_push
    velocity.y = wall_jump_up
    _wall_cd = 0.35
    _air_jumps = max_air_jumps
    _wall_side = 0.0
    state = State.AIR


# ---------- MANTLE（翻越 / 攀爬）----------
## 找面前可攀上的边缘。返回 {} 或 {dest, height}
func _find_ledge() -> Dictionary:
    var fwd := -global_transform.basis.z
    fwd.y = 0.0
    if fwd.length() < 0.01:
        return {}
    fwd = fwd.normalized()
    var feet := global_position
    var origin := feet + Vector3.UP * 0.45
    var hit := _ray(origin, origin + fwd * mantle_reach)
    if hit.is_empty() or hit.collider is HitZone:
        return {}
    var n: Vector3 = hit.normal
    if absf(n.y) > 0.3:
        return {}
    var inward := -Vector3(n.x, 0.0, n.z).normalized()
    var probe: Vector3 = hit.position + inward * 0.3
    var top := _ray(
        Vector3(probe.x, feet.y + mantle_max_height + 0.3, probe.z),
        Vector3(probe.x, feet.y + 0.2, probe.z))
    if top.is_empty() or top.normal.y < 0.7:
        return {}
    var tp: Vector3 = top.position
    var h := tp.y - feet.y
    if h < mantle_min_height or h > mantle_max_height:
        return {}
    if not _ray(tp + Vector3.UP * 0.05, tp + Vector3.UP * 1.9).is_empty():
        return {}                                   # 头顶没有净空
    var dest := tp + inward * 0.35 + Vector3.UP * 0.12
    if _capsule_blocked(dest):
        return {}                                   # 落脚点站不下
    return {"dest": dest, "height": h}


func _try_mantle() -> bool:
    if _mantle_cd > 0.0:
        return false
    var l := _find_ledge()
    if l.is_empty():
        return false
    state = State.MANTLE
    _mantle_from = global_position
    _mantle_to = l.dest
    _mantle_t = 0.0
    _mantle_dur = mantle_time + float(l.height) * 0.05
    var h := Vector3(velocity.x, 0.0, velocity.z)
    _mantle_keep = h.limit_length(sprint_speed) * 0.6    # 翻上去后保留部分动量
    velocity = Vector3.ZERO
    return true


func _tick_mantle(delta: float) -> void:
    _mantle_t += delta / _mantle_dur
    var t := clampf(_mantle_t, 0.0, 1.0)
    var up_t := smoothstep(0.0, 0.65, t)       # 先向上
    var fwd_t := smoothstep(0.35, 1.0, t)      # 再向前
    global_position = Vector3(
        lerpf(_mantle_from.x, _mantle_to.x, fwd_t),
        lerpf(_mantle_from.y, _mantle_to.y, up_t),
        lerpf(_mantle_from.z, _mantle_to.z, fwd_t))
    if _mantle_t >= 1.0:
        velocity = Vector3(_mantle_keep.x, 0.0, _mantle_keep.z)
        state = State.AIR
        _mantle_cd = 0.4
        _air_jumps = max_air_jumps


# ---------- GRAPPLE ----------
func _try_grapple() -> void:
    if _grapple_cd > 0.0:
        return
    var from := camera.global_position
    var dir := -camera.global_transform.basis.z
    var hit := _ray(from, from + dir * grapple_range)
    if hit.is_empty() or hit.collider is HitZone:
        _grapple_cd = 0.3           # 空放，短冷却
        return
    _grapple_point = hit.position
    _grapple_t = 0.0
    state = State.GRAPPLE


func _tick_grapple(delta: float) -> void:
    _grapple_t += delta
    var to_pt := _grapple_point - (global_position + Vector3.UP * 1.0)
    var dist := to_pt.length()
    if _jump_pressed or _grapple_pressed or dist < grapple_stop_dist or _grapple_t > grapple_max_time:
        if _jump_pressed:
            velocity.y = maxf(velocity.y, jump_velocity * 0.6)
        state = State.AIR
        _grapple_cd = grapple_cooldown
        _air_jumps = max_air_jumps
        return
    var dir := to_pt / dist
    velocity = velocity.move_toward(dir * grapple_speed, grapple_accel * delta)


func _update_rope() -> void:
    if state != State.GRAPPLE:
        if _rope.visible:
            _rope_mesh.clear_surfaces()
            _rope.visible = false
        return
    _rope.visible = true
    _rope_mesh.clear_surfaces()
    var start := camera.global_position + camera.global_transform.basis * Vector3(0.25, -0.25, -0.5)
    _rope_mesh.surface_begin(Mesh.PRIMITIVE_LINES)
    _rope_mesh.surface_add_vertex(start)
    _rope_mesh.surface_add_vertex(_grapple_point)
    _rope_mesh.surface_end()


# ---------- ZIPLINE ----------
func _try_zipline() -> bool:
    if _zip_cd > 0.0:
        return false
    var hand := global_position + Vector3.UP * zipline_hand_height
    var best_zip: Zipline = null
    var best_t := 0.0
    var best_d := zipline_reach
    for n in get_tree().get_nodes_in_group("zipline"):
        var z := n as Zipline
        if z == null:
            continue
        var info := z.nearest_point(hand)
        if float(info.dist) < best_d:
            best_d = float(info.dist)
            best_zip = z
            best_t = float(info.t)
    if best_zip == null:
        return false
    _zip = best_zip
    _zip_t = best_t
    # 方向: 朝下坡；水平缆线则朝面向的方向
    var dn := _zip.direction()
    var downhill := dn if dn.y < 0.0 else -dn
    if absf(dn.y) < 0.02:
        downhill = dn if dn.dot(-global_transform.basis.z) > 0.0 else -dn
    _zip_dir = 1.0 if downhill.dot(dn) > 0.0 else -1.0
    _zip_speed = maxf(_horizontal_speed() * 0.6, 6.0)
    velocity = Vector3.ZERO
    _zip_age = 0.0
    state = State.ZIPLINE
    return true


func _tick_zipline(delta: float) -> void:
    _zip_speed = move_toward(_zip_speed, _zip.speed, zipline_accel * delta)
    _zip_t += _zip_dir * _zip_speed * delta
    _zip_age += delta
    var along := _zip.direction() * _zip_dir
    var release := (_jump_pressed or _use_pressed) and _zip_age > 0.15
    if release or _zip_t <= 0.0 or _zip_t >= _zip.length():
        _zip_t = clampf(_zip_t, 0.0, _zip.length())
        global_position = _zip.point_at(_zip_t) - Vector3.UP * zipline_hand_height
        velocity = along * _zip_speed + Vector3.UP * (jump_velocity * 0.8 if _jump_pressed else 2.0)
        state = State.AIR
        _zip_cd = 0.6
        _air_jumps = max_air_jumps
        return
    global_position = _zip.point_at(_zip_t) - Vector3.UP * zipline_hand_height
    velocity = along * _zip_speed     # 仅用于 FOV/调试显示；不调用 move_and_slide


# ---------- 第三人称 ----------
func _update_third_person(delta: float) -> void:
    if puppet == null:
        return
    if not third_person:
        return
    # 相机拉到角色右后方，被墙挡住时往前收
    var from := head.global_position
    var want := head.global_transform * Vector3(0.45, 0.15, 2.8)
    var hit := _ray(from, want)
    var cam_pos := want
    if not hit.is_empty():
        cam_pos = hit.position + hit.normal * 0.2
    camera.global_position = camera.global_position.lerp(cam_pos, 1.0 - exp(-20.0 * delta))

    # 同步 Puppet（Puppet 放在脚底，跟随玩家朝向）
    puppet.speed = _horizontal_speed()
    puppet.vel_local = global_transform.basis.inverse() * velocity
    puppet.aim_pitch = pitch
    puppet.ads = weapon.ads_t if weapon != null else 0.0
    puppet.wall_side = _wall_side
    puppet.grapple_dir = global_transform.basis.inverse() * (_grapple_point - head.global_position)
    match state:
        State.SLIDE:
            puppet.pose = "slide"
        State.WALL_RUN:
            puppet.pose = "wall_run"
        State.MANTLE:
            puppet.pose = "mantle"
        State.GRAPPLE:
            puppet.pose = "grapple"
        State.ZIPLINE:
            puppet.pose = "zipline"
        State.AIR:
            puppet.pose = "air"
        _:
            puppet.pose = "move" if _horizontal_speed() > 0.5 else "idle"
