extends Node3D
## 训练场（临时测试地图，代码生成几何体）。
## 用途: 验证移动手感、射击、TTK、弹道、穿透、瞄镜、触屏操作。
## 正式地图（NEON DISTRICT 等）将用编辑器制作 .tscn 并替换本场景。
##
## 区域速览（从出生点 (0,0,8) 面朝 -Z 看）:
##   正前方: 4 排靶子，最远 56m（测狙击/下坠）
##   左前:   木板墙(可穿透) + 靶；右前: 薄铁板(只有狙击能穿) + 靶
##   右侧:   平行高墙走廊 x=30 / x=36（蹬墙跑、墙跳）
##   左侧:   坡道（滑铲加速）；更远 x=-40..-52 三个递增矮台（翻越）；塔 (-30,*,30)（钩爪+攀爬）
##   滑索:   塔顶 (-30,12,30)→(-30,3.5,-5)；中央塔顶 (0,14,50)→(-6,4,14)。空中跳跃或按 F 挂上，再跳脱离
##   HUD「武器」按钮可从 40 把枪里任选；P 切第三人称，T 检视；工坊里的配件选择会带进来

var _touch: TouchControls
var _hud: HUD
var _player: Player
var _materials: Dictionary = {}
var _grid_tex: ImageTexture


func _ready() -> void:
    _build_environment()
    _build_arena()
    _build_targets()
    _build_ui()
    _spawn_player()


func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:    # Android 返回键
        _back_to_lobby()


func _back_to_lobby() -> void:
    SceneRouter.goto("res://ui/lobby/lobby.tscn")


# ---------- 环境 / 光照（移动端预算: 1 盏带阴影的平行光，无天空盒）----------
func _build_environment() -> void:
    var we := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("1b232b")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("8895a3")
    env.ambient_light_energy = 0.8
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    we.environment = env
    add_child(we)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50, -30, 0)
    sun.shadow_enabled = true
    sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
    sun.directional_shadow_max_distance = 60.0
    add_child(sun)


# ---------- 几何体 ----------
func _grid_texture() -> ImageTexture:
    if _grid_tex == null:
        var img := Image.create(64, 64, false, Image.FORMAT_RGB8)
        img.fill(Color("ffffff"))
        for i in 64:
            for k in 2:
                img.set_pixel(i, k, Color("b0b8c0"))
                img.set_pixel(k, i, Color("b0b8c0"))
        img.generate_mipmaps()
        _grid_tex = ImageTexture.create_from_image(img)
    return _grid_tex


func _material(color: Color) -> StandardMaterial3D:
    var key := color.to_html()
    if not _materials.has(key):
        var m := StandardMaterial3D.new()
        m.albedo_color = color
        m.albedo_texture = _grid_texture()
        m.uv1_triplanar = true
        m.uv1_world_triplanar = true
        m.uv1_scale = Vector3(0.25, 0.25, 0.25)
        m.roughness = 0.9
        _materials[key] = m
    return _materials[key]


## pen_cost >= 0 时，该障碍可被穿透力足够的子弹穿过
func _add_box(pos: Vector3, size: Vector3, color: Color, rot_deg := Vector3.ZERO, pen_cost := -1.0, surface := "concrete") -> void:
    var body := StaticBody3D.new()
    body.position = pos
    body.rotation_degrees = rot_deg
    body.set_meta("surface", surface)
    if pen_cost >= 0.0:
        body.set_meta("pen_cost", pen_cost)
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = size
    cs.shape = bs
    body.add_child(cs)
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = _material(color)
    body.add_child(mi)
    add_child(body)


func _build_arena() -> void:
    var floor_c := Color("5a6672")
    var wall_c := Color("7a8794")
    var prop_c := Color("a4b0bc")
    var wood_c := Color("a8845a")
    var metal_c := Color("6f8aa0")

    _add_box(Vector3(0, -0.5, 0), Vector3(120, 1, 120), floor_c)
    # 围墙（8 米高）
    _add_box(Vector3(0, 4, -60), Vector3(120, 8, 1), wall_c)
    _add_box(Vector3(0, 4, 60), Vector3(120, 8, 1), wall_c)
    _add_box(Vector3(-60, 4, 0), Vector3(1, 8, 120), wall_c)
    _add_box(Vector3(60, 4, 0), Vector3(1, 8, 120), wall_c)

    # 滑铲坡道: 高端在 +Z，朝 -Z 冲下去是下坡
    _add_box(Vector3(-14, 1.2, 10), Vector3(6, 0.5, 16), prop_c, Vector3(-15, 0, 0))

    # 台阶 / 平台（跳跃、二段跳、翻越）
    _add_box(Vector3(14, 0.5, 14), Vector3(6, 1, 6), prop_c)
    _add_box(Vector3(14, 1.5, 22), Vector3(6, 3, 6), prop_c)
    _add_box(Vector3(14, 2.5, 30), Vector3(6, 5, 6), prop_c)

    # 翻越练习: 1.0 / 1.6 / 2.2 米递增
    _add_box(Vector3(-40, 0.5, 0), Vector3(4, 1.0, 4), prop_c)
    _add_box(Vector3(-46, 0.8, 0), Vector3(4, 1.6, 4), prop_c)
    _add_box(Vector3(-52, 1.1, 0), Vector3(4, 2.2, 4), prop_c)

    # 钩爪塔（10 米高）
    _add_box(Vector3(-30, 5, 30), Vector3(3, 10, 3), wall_c)
    _add_box(Vector3(0, 6, 50), Vector3(3, 12, 3), wall_c)

    # 掩体
    for i in 5:
        _add_box(Vector3(-8 + i * 4.0, 0.75, -6.0), Vector3(2.0, 1.5, 0.6), prop_c)

    # 蹬墙跑走廊 + 单面长墙
    _add_box(Vector3(30, 3, -30), Vector3(0.6, 6, 40), wall_c)
    _add_box(Vector3(36, 3, -30), Vector3(0.6, 6, 40), wall_c)
    _add_box(Vector3(-30, 4, -30), Vector3(0.6, 8, 40), wall_c)

    # 穿透测试: 木板(pen 0.5) 和 薄铁板(pen 1.5)
    _add_box(Vector3(-20, 1.25, -18), Vector3(6, 2.5, 0.3), wood_c, Vector3.ZERO, 0.5, "wood")
    _add_box(Vector3(20, 1.25, -18), Vector3(6, 2.5, 0.3), metal_c, Vector3.ZERO, 1.5, "metal")

    # 滑索: 钩爪塔顶 → 场地中部；中央高塔 → 靠近出生点
    _add_zipline(Vector3(-30, 12.0, 30), Vector3(-30, 3.5, -5), false, true)
    _add_zipline(Vector3(0, 14.0, 50), Vector3(-6, 4.0, 14), false, true)


func _add_zipline(a: Vector3, b: Vector3, pole_a: bool, pole_b: bool) -> void:
    var z := Zipline.new()
    z.setup(a, b, pole_a, pole_b)
    add_child(z)


func _build_targets() -> void:
    for z in [-14.0, -24.0, -36.0, -50.0]:
        for x in [-4.0, 4.0]:
            _add_target(Vector3(x, 0, z))
    # 远距离（狙击 / 下坠）
    _add_target(Vector3(0, 0, -56))
    _add_target(Vector3(-10, 0, -56))
    _add_target(Vector3(10, 0, -56))
    # 板后目标
    _add_target(Vector3(-20, 0, -21))
    _add_target(Vector3(20, 0, -21))


func _add_target(pos: Vector3) -> void:
    var t := TargetDummy.new()
    t.position = pos
    add_child(t)


# ---------- UI / 玩家 ----------
func _build_ui() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 10
    add_child(layer)
    if Game.is_mobile:
        _touch = TouchControls.new()
        layer.add_child(_touch)
    _hud = HUD.new()
    layer.add_child(_hud)
    _hud.back_requested.connect(_back_to_lobby)


func _spawn_player() -> void:
    var p := Player.new()
    p.position = Vector3(0, 0.2, 8)
    p.touch = _touch
    for id in [Loadout.primary, Loadout.secondary]:
        var d := WeaponCatalog.load_weapon(id)
        if d != null:
            p.loadout.append(d)
    if p.loadout.is_empty():
        p.loadout.append(WeaponCatalog.load_weapon("vx1_rifle"))
    _player = p
    add_child(p)
    _hud.weapon_chosen.connect(p.equip_weapon_by_id)
