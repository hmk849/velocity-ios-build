class_name Zipline
extends Node3D
## 滑索: 两个端点之间的直线缆线。玩家在缆线附近按跳跃(空中)或使用键(F)挂上去，
## 沿缆线向下坡方向加速滑行；跳跃可中途脱离并保留动量。
## 用法: var z := Zipline.new(); z.setup(a, b); add_child(z)  （节点放在世界原点，a/b 为世界坐标）

@export var a := Vector3.ZERO
@export var b := Vector3.ZERO
@export var speed := 17.0
@export var pole_a := true     # 是否在端点下方画支柱到地面
@export var pole_b := true

var _dir := Vector3.FORWARD
var _len := 1.0


func setup(p_a: Vector3, p_b: Vector3, p_pole_a := true, p_pole_b := true) -> void:
    a = p_a
    b = p_b
    pole_a = p_pole_a
    pole_b = p_pole_b


func _ready() -> void:
    add_to_group("zipline")
    var d := b - a
    _len = maxf(d.length(), 0.01)
    _dir = d / _len
    _build_visual()


func length() -> float:
    return _len


## 从 a 指向 b 的单位方向
func direction() -> Vector3:
    return _dir


func point_at(t: float) -> Vector3:
    return a + _dir * clampf(t, 0.0, _len)


## 离给定点最近的缆线位置。返回 { "t": 沿缆线距离, "point": 最近点, "dist": 距离 }
func nearest_point(p: Vector3) -> Dictionary:
    var t := clampf((p - a).dot(_dir), 0.0, _len)
    var q := a + _dir * t
    return {"t": t, "point": q, "dist": p.distance_to(q)}


func _build_visual() -> void:
    var metal := StandardMaterial3D.new()
    metal.albedo_color = Color("8a96a3")
    metal.metallic = 0.7
    metal.roughness = 0.4
    var cable := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 0.025
    cm.bottom_radius = 0.025
    cm.height = _len
    cm.radial_segments = 6
    cm.rings = 1
    cable.mesh = cm
    cable.material_override = metal
    add_child(cable)
    cable.global_position = (a + b) * 0.5
    # 圆柱的轴向是 Y；让 Y 轴对齐缆线方向
    var y_axis := _dir
    var x_axis := y_axis.cross(Vector3.UP)
    if x_axis.length() < 0.01:
        x_axis = y_axis.cross(Vector3.RIGHT)
    x_axis = x_axis.normalized()
    cable.global_transform.basis = Basis(x_axis, y_axis, x_axis.cross(y_axis))

    for i in 2:
        var p := a if i == 0 else b
        var has_pole := pole_a if i == 0 else pole_b
        var bracket := MeshInstance3D.new()
        var bm := BoxMesh.new()
        bm.size = Vector3(0.3, 0.3, 0.3)
        bracket.mesh = bm
        bracket.material_override = metal
        add_child(bracket)
        bracket.global_position = p
        if has_pole and p.y > 0.5:
            _add_pole(Vector3(p.x, 0.0, p.z), p.y, metal)


func _add_pole(base: Vector3, height: float, mat: Material) -> void:
    var body := StaticBody3D.new()
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = Vector3(0.25, height, 0.25)
    cs.shape = bs
    body.add_child(cs)
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = bs.size
    mi.mesh = bm
    mi.material_override = mat
    body.add_child(mi)
    body.set_meta("surface", "metal")
    add_child(body)
    body.global_position = base + Vector3(0, height * 0.5, 0)
