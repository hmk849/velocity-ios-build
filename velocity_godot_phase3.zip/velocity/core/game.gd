extends Node
## Autoload: Game
## 职责: 版本号、平台判断、UI 主题、跨场景传参。不放具体玩法逻辑。

const GAME_NAME := "PROJECT VELOCITY"
const VERSION := "0.1.0-phase1"

var is_mobile := false
var ui_theme: Theme
## 传给 loading 场景的参数: { "path": String, "info": Dictionary }
var pending_load: Dictionary = {}


func _ready() -> void:
    is_mobile = OS.has_feature("mobile")
    InputSetup.register_actions()
    ui_theme = UITheme.build()
