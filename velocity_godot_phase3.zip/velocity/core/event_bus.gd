extends Node
## Autoload: EventBus
## 全局信号总线。规则: gameplay 层只发信号，不引用 ui；ui 订阅信号。

signal ammo_changed(current: int, magazine: int, reloading: bool)
signal weapon_changed(display_name: String, ttk_ms: float, sight_name: String)
signal hit_confirmed(is_head: bool, killed: bool)
## 开镜状态，每帧发出: ads_amount 0~1，倍率，分划样式
signal sight_state(ads_amount: float, zoom: float, reticle: String, pip: bool)
## 移动调试信息（约 10Hz）
signal movement_debug(speed: float, state_name: String)
