extends Node
## Autoload: Loadout
## 玩家武器配置: 主/副武器 + 每把枪的配件选择，存 user://loadout.cfg。
## 配件按槽位(AttachmentData.Slot 的整数)存路径；空字符串 = 卸下。

const PATH := "user://loadout.cfg"

var primary := "vx1_rifle"
var secondary := "px1_pistol"
var _atts: Dictionary = {}    # weapon_id -> { slot(int) -> path(String) }


func _ready() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(PATH) != OK:
        return
    primary = cfg.get_value("main", "primary", primary)
    secondary = cfg.get_value("main", "secondary", secondary)
    _atts = cfg.get_value("main", "attachments", {})


func save() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("main", "primary", primary)
    cfg.set_value("main", "secondary", secondary)
    cfg.set_value("main", "attachments", _atts)
    cfg.save(PATH)


func has_custom(weapon_id: String) -> bool:
    return _atts.has(weapon_id)


## 返回该槽位的选择: 路径，或 ""（已卸下）。未自定义返回 null。
func get_choice(weapon_id: String, slot: int) -> Variant:
    if not _atts.has(weapon_id):
        return null
    var m: Dictionary = _atts[weapon_id]
    return m.get(slot, null)


func set_choice(weapon_id: String, slot: int, path: String) -> void:
    var m: Dictionary = _atts.get(weapon_id, {})
    m[slot] = path
    _atts[weapon_id] = m


func reset(weapon_id: String) -> void:
    _atts.erase(weapon_id)
